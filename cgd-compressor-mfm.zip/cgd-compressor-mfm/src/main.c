#include "board_config.h"
#include "storage.h"
#include "device_config.h"
#include "wifi_manager.h"
#include "time_utils.h"
#include "file_sync.h"
#include "w5500_eth.h"
#include "modbus_adapter.h"
#include "iot_hub.h"
#include "ota_update.h"
#include "project_config.h"

#include "esp_log.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "esp_task_wdt.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define WDT_TIMEOUT_S  30

static const char *TAG = "main";

/* ── Core affinity & task priorities ───────────────────────────────────── */
#define CORE_PRO  0
#define CORE_APP  1

#define PRIO_POLLER      5
#define PRIO_BACKGROUND  3

/* ── State ─────────────────────────────────────────────────────────────── */
static _Atomic int s_mqtt_fail_count = 0;
static _Atomic bool s_sd_retry_needed = false;
static TaskHandle_t s_poller_handle = NULL;

/* ── Poller helpers ───────────────────────────────────────────────────── */

static void poller_free_bufs(uint8_t **raw_bufs, size_t *lens, int count)
{
    if (raw_bufs) {
        for (int i = 0; i < count; i++) free(raw_bufs[i]);
        free(raw_bufs);
    }
    free(lens);
}

static bool poller_alloc_bufs(const device_config_t *cfg,
                               uint8_t ***out_bufs, size_t **out_lens)
{
    int n = cfg->reg_count;
    uint8_t **bufs = calloc(n, sizeof(uint8_t *));
    size_t *lens = calloc(n, sizeof(size_t));
    if (!bufs || !lens) {
        free(bufs); free(lens);
        return false;
    }
    for (int i = 0; i < n; i++) {
        size_t max_bytes = (cfg->regs[i].func_code <= 2)
                            ? (cfg->regs[i].length + 7) / 8
                            : cfg->regs[i].length * 2;
        bufs[i] = calloc(1, max_bytes);
        if (!bufs[i]) {
            for (int j = 0; j < i; j++) free(bufs[j]);
            free(bufs); free(lens);
            return false;
        }
    }
    *out_bufs = bufs;
    *out_lens = lens;
    return true;
}

/* ── Poller task ───────────────────────────────────────────────────────── */

static void poller_task(void *arg)
{
    const board_config_t *board = (const board_config_t *)arg;
    uint8_t **raw_bufs = NULL;
    size_t *lens = NULL;
    int cur_count = 0;
    reg_entry_t *local_regs = NULL;
    device_config_t local_cfg;

    esp_task_wdt_add(NULL);

    while (1) {
        esp_task_wdt_reset();
        /* Brief lock: snapshot config, release immediately */
        device_config_lock();
        const device_config_t *cfg = device_config_get();

        if (!cfg || cfg->reg_count == 0) {
            device_config_unlock();
            xTaskNotifyWait(0, ULONG_MAX, NULL, pdMS_TO_TICKS(5000));
            continue;
        }

        /* Allocate buffers (first run or after config change notification) */
        if (!raw_bufs) {
            cur_count = cfg->reg_count;
            free(local_regs);
            local_regs = malloc(cur_count * sizeof(reg_entry_t));
            if (!local_regs || !poller_alloc_bufs(cfg, &raw_bufs, &lens)) {
                ESP_LOGE(TAG, "Poller: alloc failed");
                free(local_regs); local_regs = NULL;
                cur_count = 0;
                device_config_unlock();
                vTaskDelay(pdMS_TO_TICKS(5000));
                continue;
            }

            /* Ensure modbus adapter is initialized (handles the case where
               device booted with no config and twin pushed one later) */
            modbus_config_t mcfg = {
                .is_rtu      = cfg->is_rtu,
                .slave_addr  = cfg->slave_addr,
                .baud        = cfg->baud,
                .data_bits   = cfg->data_bits,
                .parity      = cfg->parity,
                .stop_bits   = cfg->stop_bits,
                .server_ip   = cfg->server_ip,
                .server_port = cfg->server_port,
            };
            device_config_unlock();
            modbus_adapter_deinit();
            modbus_adapter_init(board, &mcfg);
            device_config_lock();
            cfg = device_config_get();
            if (!cfg || cfg->reg_count == 0 || cfg->reg_count != cur_count) {
                device_config_unlock();
                poller_free_bufs(raw_bufs, lens, cur_count);
                raw_bufs = NULL; lens = NULL; cur_count = 0;
                continue;
            }

            ESP_LOGI(TAG, "Poller: %d entries, interval=%lus",
                     cfg->reg_count, cfg->post_interval);
        }

        /* Snapshot config struct + regs array, then release lock */
        memcpy(&local_cfg, cfg, sizeof(device_config_t));
        memcpy(local_regs, cfg->regs, cur_count * sizeof(reg_entry_t));
        local_cfg.regs = local_regs;
        device_config_unlock();

        /* ── Lock released — config can update freely now ────────────── */

        /* Read all registers using local snapshot */
        for (int i = 0; i < cur_count; i++) {
            lens[i] = 0;
            size_t max_bytes = (local_regs[i].func_code <= 2)
                                ? (local_regs[i].length + 7) / 8
                                : local_regs[i].length * 2;

            esp_err_t ret = modbus_adapter_read(&local_regs[i], raw_bufs[i], &lens[i]);
            if (ret != ESP_OK) {
                ESP_LOGW(TAG, "Poll[%d] addr=%u failed: %s",
                         i, local_regs[i].raw_addr, esp_err_to_name(ret));
                memset(raw_bufs[i], 0, max_bytes);
                lens[i] = 0;
            }
        }

        /* Build and send telemetry using local snapshot */
        esp_err_t ret = iot_hub_send_reg_telemetry(&local_cfg, raw_bufs, lens);
        if (ret == ESP_OK) {
            s_mqtt_fail_count = 0;
        } else {
            s_mqtt_fail_count++;
            ESP_LOGW(TAG, "MQTT publish failed (%d/%d)",
                     s_mqtt_fail_count, MQTT_FAIL_REBOOT_COUNT);

            if (s_mqtt_fail_count >= MQTT_FAIL_REBOOT_COUNT) {
                ESP_LOGE(TAG, "Too many MQTT failures, rebooting...");
                vTaskDelay(pdMS_TO_TICKS(3000));
                esp_restart();
            }
        }

        /* Wait for next interval, or wake immediately on config change */
        BaseType_t notified = xTaskNotifyWait(0, ULONG_MAX, NULL,
                                               pdMS_TO_TICKS(local_cfg.post_interval * 1000));
        if (notified == pdTRUE) {
            ESP_LOGI(TAG, "Poller: config changed, reinitializing");
            poller_free_bufs(raw_bufs, lens, cur_count);
            raw_bufs = NULL;
            lens = NULL;
            cur_count = 0;
            /* Modbus adapter will be (re)initialized in the allocation branch */
        }
    }
}

/* ── Background task (SD retry, periodic reboot, online status) ────────── */

static void background_task(void *arg)
{
    esp_task_wdt_add(NULL);

    /* Boot status: retry for up to 30s waiting for MQTT connection */
    bool boot_status_sent = false;
    for (int i = 0; i < 30 && !boot_status_sent; i++) {
        esp_task_wdt_reset();
        if (iot_hub_is_connected()) {
            if (iot_hub_send_online_status(true) == ESP_OK)
                boot_status_sent = true;
        }
        if (!boot_status_sent)
            vTaskDelay(pdMS_TO_TICKS(1000));
    }
    if (!boot_status_sent) {
        ESP_LOGW(TAG, "Boot status not sent (MQTT not connected within 30s)");
    }

    TickType_t boot_tick = xTaskGetTickCount();
    TickType_t last_status = boot_tick;
    uint32_t sd_retry_delay_ms = 5000;
    TickType_t last_sd_retry = 0;

    while (1) {
        esp_task_wdt_reset();
        TickType_t now_tick = xTaskGetTickCount();

        /* SD card retry with exponential backoff */
        if (s_sd_retry_needed &&
            (now_tick - last_sd_retry) >= pdMS_TO_TICKS(sd_retry_delay_ms))
        {
            if (storage_init_sd(board_config_get()) == ESP_OK) {
                s_sd_retry_needed = false;
                ESP_LOGI(TAG, "SD card recovered");
            } else {
                last_sd_retry = now_tick;
                if (sd_retry_delay_ms < 300000)
                    sd_retry_delay_ms *= 2;
            }
        }

        /* Online status telemetry */
        device_config_lock();
        const device_config_t *bg_cfg = device_config_get();
        uint32_t status_iv = bg_cfg ? bg_cfg->status_interval : DEFAULT_STATUS_INTERVAL;
        device_config_unlock();

        if ((now_tick - last_status) >= pdMS_TO_TICKS(status_iv * 1000)) {
            if (iot_hub_is_connected()) {
                iot_hub_send_online_status(false);
            }
            last_status = now_tick;
        }

        /* Periodic reboot check (use 64-bit to avoid overflow) */
        uint64_t uptime_ms = (uint64_t)(now_tick - boot_tick) * portTICK_PERIOD_MS;
        if (uptime_ms >= (uint64_t)PERIODIC_REBOOT_HOURS * 3600ULL * 1000ULL) {
            ESP_LOGI(TAG, "Periodic reboot (every %dh)", PERIODIC_REBOOT_HOURS);
            esp_restart();
        }

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

/* ── App entry point ───────────────────────────────────────────────────── */

void app_main(void)
{
    /* 1. NVS + LittleFS */
    storage_init_nvs();
    if (storage_init_lfs() != ESP_OK) {
        ESP_LOGE(TAG, "LittleFS mount failed! Halting.");
        return;
    }

    /* 2. Board detection */
    if (board_config_init() != ESP_OK) {
        ESP_LOGE(TAG, "Board detection failed! Halting.");
        return;
    }
    const board_config_t *board = board_config_get();
    ESP_LOGI(TAG, "Board: %s  Chip-ID: %s", board->name, board_config_get_chip_id());

    /* 3. SD card */
    if (storage_init_sd(board) != ESP_OK) {
        ESP_LOGW(TAG, "SD card not available - will retry in background");
        s_sd_retry_needed = true;
    }

    /* 4. Boot-time file sync (SD <-> LFS) */
    if (storage_sd_is_mounted()) {
        file_sync(CONFIG_FILENAME);
        file_sync(MQTT_CONFIG_FILENAME);
        file_sync(WIFI_FILENAME);
    }

    /* 5. Network init (must be before WiFi and Ethernet) */
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    /* 6. WiFi */
    wifi_creds_t wifi = {0};
    if (wifi_creds_load(&wifi, board) == ESP_OK) {
        wifi_manager_init(wifi.ssid, wifi.password);
    } else {
        ESP_LOGW(TAG, "No WiFi credentials found");
    }

    /* 7. RTC + SNTP */
    time_utils_init(board);
    time_utils_start_sntp();

    /* 8. Load device config: SD -> LittleFS */
    esp_err_t ret = device_config_load();
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "No config loaded - waiting for twin from Azure IoT Hub");
    }

    /* 9. Azure IoT Hub MQTT */
    mqtt_config_t mqtt_cfg;
    ret = mqtt_config_load(&mqtt_cfg);
    if (ret == ESP_OK) {
        ret = iot_hub_init(&mqtt_cfg);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "IoT Hub init failed: %s", esp_err_to_name(ret));
        }
    } else {
        ESP_LOGE(TAG, "No MQTT config found, IoT Hub disabled");
    }

    /* 10. Always init W5500 Ethernet (needed for runtime RTU->TCP switching) */
    {
        esp_ip4_addr_t eth_ip, eth_gw, eth_mask;
        device_config_lock();
        const device_config_t *cfg = device_config_get();
        if (cfg && !cfg->is_rtu) {
            eth_ip   = cfg->eth_ip;
            eth_gw   = cfg->eth_gw;
            eth_mask = cfg->eth_mask;
        } else {
            esp_netif_str_to_ip4(ETH_DEFAULT_IP, &eth_ip);
            esp_netif_str_to_ip4(ETH_DEFAULT_GATEWAY, &eth_gw);
            esp_netif_str_to_ip4(ETH_DEFAULT_SUBNET, &eth_mask);
        }
        device_config_unlock();

        ESP_LOGI(TAG, "Initializing W5500 Ethernet");
        if (w5500_eth_init(board, eth_ip, eth_gw, eth_mask) != ESP_OK) {
            ESP_LOGW(TAG, "W5500 init failed (TCP mode will be unavailable)");
        }
    }

    /* 11. Init Modbus adapter */
    {
        device_config_lock();
        const device_config_t *cfg = device_config_get();
        if (cfg) {
            modbus_config_t mcfg = {
                .is_rtu      = cfg->is_rtu,
                .slave_addr  = cfg->slave_addr,
                .baud        = cfg->baud,
                .data_bits   = cfg->data_bits,
                .parity      = cfg->parity,
                .stop_bits   = cfg->stop_bits,
                .server_ip   = cfg->server_ip,
                .server_port = cfg->server_port,
            };
            device_config_unlock();
            if (modbus_adapter_init(board, &mcfg) != ESP_OK) {
                ESP_LOGE(TAG, "Modbus adapter init failed!");
            }
        } else {
            device_config_unlock();
        }
    }

    /* 12. Wait for MQTT (up to 15s for Azure IoT Hub TLS handshake) */
    for (int i = 0; i < 150 && !iot_hub_is_connected(); i++)
        vTaskDelay(pdMS_TO_TICKS(100));

    if (iot_hub_is_connected()) {
        iot_hub_report_device_properties();
    }

    /* 13. Check OTA on boot (non-blocking) */
    {
        device_config_lock();
        const device_config_t *cfg = device_config_get();
        if (cfg) {
            ota_start(cfg->main_url, cfg->checksum_url, cfg->next_ota_ver);
        }
        device_config_unlock();
    }

    /* 14. Init Task Watchdog Timer */
    esp_task_wdt_config_t wdt_cfg = {
        .timeout_ms = WDT_TIMEOUT_S * 1000,
        .idle_core_mask = 0,
        .trigger_panic = true,
    };
    esp_task_wdt_reconfigure(&wdt_cfg);

    /* 15. Start poller task on Core 1 (always — handles reg_count==0 with wait loop,
           so a twin push can start polling without reboot) */
    xTaskCreatePinnedToCore(poller_task, "poller", 12288, (void *)board,
                            PRIO_POLLER, &s_poller_handle, CORE_APP);
    device_config_set_modbus_notify_task(s_poller_handle);

    /* 16. Start background task on Core 0 (SD retry, reboot, online status) */
    xTaskCreatePinnedToCore(background_task, "background", 4096, NULL,
                            PRIO_BACKGROUND, NULL, CORE_PRO);

    ESP_LOGI(TAG, "Initialization complete (FW v%s)", FW_VERSION);
}
