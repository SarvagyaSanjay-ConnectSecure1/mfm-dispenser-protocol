#!/usr/bin/env python3
"""Compare two sdkconfig files and output an sdkconfig.defaults with the differences."""

import argparse
import sys


def parse_sdkconfig(filepath):
    """Parse an sdkconfig file into a dict of key=value and a set of commented-out keys."""
    config = {}
    commented = set()
    with open(filepath, "r") as f:
        for line in f:
            line = line.strip()
            if line.startswith("# CONFIG_") and line.endswith(" is not set"):
                key = line[2:].replace(" is not set", "")
                commented.add(key)
            elif "=" in line and not line.startswith("#"):
                key, value = line.split("=", 1)
                config[key] = value
    return config, commented


def diff_sdkconfig(old_path, new_path):
    """Return lines that differ between old and new sdkconfig."""
    old_cfg, old_commented = parse_sdkconfig(old_path)
    new_cfg, new_commented = parse_sdkconfig(new_path)

    diff_lines = []

    # Find changed or added config values
    for key in sorted(new_cfg):
        if key in old_cfg:
            if new_cfg[key] != old_cfg[key]:
                diff_lines.append(f"# was: {key}={old_cfg[key]}")
                diff_lines.append(f"{key}={new_cfg[key]}")
        else:
            # New key not in old (was either commented out or didn't exist)
            diff_lines.append(f"{key}={new_cfg[key]}")

    # Find keys that were set in old but are now commented out (unset) in new
    for key in sorted(old_cfg):
        if key not in new_cfg and key in new_commented:
            diff_lines.append(f"# was: {key}={old_cfg[key]}")
            diff_lines.append(f"# {key} is not set")

    return diff_lines


def main():
    parser = argparse.ArgumentParser(
        description="Generate sdkconfig.defaults from the diff of two sdkconfig files"
    )
    parser.add_argument("old", help="Path to the old/default sdkconfig")
    parser.add_argument("new", help="Path to the new/modified sdkconfig")
    parser.add_argument(
        "-o", "--output",
        default="sdkconfig.defaults",
        help="Output file (default: sdkconfig.defaults)",
    )
    parser.add_argument(
        "--no-comments",
        action="store_true",
        help="Omit '# was:' comments showing old values",
    )
    args = parser.parse_args()

    diff_lines = diff_sdkconfig(args.old, args.new)

    if not diff_lines:
        print("No differences found.")
        sys.exit(0)

    output_lines = []
    for line in diff_lines:
        if args.no_comments and line.startswith("# was:"):
            continue
        output_lines.append(line)

    with open(args.output, "w") as f:
        f.write("\n".join(output_lines) + "\n")

    actual_settings = [l for l in output_lines if not l.startswith("# was:")]
    print(f"Found {len(actual_settings)} differences, written to {args.output}")


if __name__ == "__main__":
    main()
