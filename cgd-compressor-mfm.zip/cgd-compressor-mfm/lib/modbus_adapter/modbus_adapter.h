#pragma once
#ifndef __MODBUS_ADAPTER_H__
#define __MODBUS_ADAPTER_H__

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"
#include "esp_netif.h"
#include "board_config.h"
#include "device_config.h"

typedef struct {
    bool           is_rtu;
    uint8_t        slave_addr;
    uint32_t       baud;
    uint8_t        data_bits;
    uint8_t        parity;
    uint8_t        stop_bits;
    esp_ip4_addr_t server_ip;
    uint16_t       server_port;
} modbus_config_t;

esp_err_t modbus_adapter_init(const board_config_t *board, const modbus_config_t *cfg);
esp_err_t modbus_adapter_read(const reg_entry_t *entry, uint8_t *raw_bytes, size_t *out_len);
esp_err_t modbus_adapter_write(uint16_t offset, uint16_t value);
void      modbus_adapter_deinit(void);

#endif
