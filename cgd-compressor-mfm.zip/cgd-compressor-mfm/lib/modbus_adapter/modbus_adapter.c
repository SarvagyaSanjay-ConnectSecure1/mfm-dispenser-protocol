#include "modbus_adapter.h"
#include "rs485.h"
#include "w5500_eth.h"
#include "project_config.h"
#include "esp_log.h"
#include "lwip/sockets.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <string.h>

static const char *TAG = "modbus";

#define RTU_MAX_FRAME   256
#define TCP_MAX_FRAME   260
#define MODBUS_MAX_BYTE_COUNT 250  /* max PDU data per spec */

static bool s_is_rtu = true;
static uint8_t s_slave_addr = 1;
static SemaphoreHandle_t s_mutex = NULL;

/* TCP state */
static int s_tcp_sock = -1;
static esp_ip4_addr_t s_tcp_ip;
static uint16_t s_tcp_port = 502;
static uint16_t s_tcp_tid = 0;

/* ── CRC-16 (Modbus RTU) ──────────────────────────────────────────────── */

static uint16_t crc16(const uint8_t *data, size_t len)
{
    uint16_t crc = 0xFFFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 1)
                crc = (crc >> 1) ^ 0xA001;
            else
                crc >>= 1;
        }
    }
    return crc;
}

/* ── TCP transport ─────────────────────────────────────────────────────── */

static esp_err_t tcp_connect(void)
{
    if (s_tcp_sock >= 0) return ESP_OK;

    if (!w5500_eth_is_connected()) {
        ESP_LOGW(TAG, "Ethernet link down, cannot connect TCP");
        return ESP_ERR_INVALID_STATE;
    }

    s_tcp_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s_tcp_sock < 0) {
        ESP_LOGE(TAG, "TCP socket create failed");
        return ESP_FAIL;
    }

    /* Set TCP_NODELAY for lower latency */
    int flag = 1;
    setsockopt(s_tcp_sock, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(s_tcp_port),
        .sin_addr.s_addr = s_tcp_ip.addr,
    };

    struct timeval tv = { .tv_sec = 3, .tv_usec = 0 };
    setsockopt(s_tcp_sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(s_tcp_sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    int ret = connect(s_tcp_sock, (struct sockaddr *)&addr, sizeof(addr));
    if (ret != 0) {
        ESP_LOGW(TAG, "TCP connect to " IPSTR ":%d failed",
                 IP2STR(&s_tcp_ip), s_tcp_port);
        close(s_tcp_sock);
        s_tcp_sock = -1;
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "TCP connected to " IPSTR ":%d", IP2STR(&s_tcp_ip), s_tcp_port);
    return ESP_OK;
}

static void tcp_disconnect(void)
{
    if (s_tcp_sock >= 0) {
        close(s_tcp_sock);
        s_tcp_sock = -1;
    }
}

static esp_err_t tcp_transact(const uint8_t *pdu, size_t pdu_len,
                               uint8_t *response, size_t *resp_len)
{
    esp_err_t ret = tcp_connect();
    if (ret != ESP_OK) return ret;

    uint8_t frame[TCP_MAX_FRAME];
    uint16_t tid = s_tcp_tid++;
    size_t mbap_pdu_len = pdu_len + 1;

    frame[0] = tid >> 8;
    frame[1] = tid & 0xFF;
    frame[2] = 0; frame[3] = 0;
    frame[4] = mbap_pdu_len >> 8;
    frame[5] = mbap_pdu_len & 0xFF;
    frame[6] = s_slave_addr;
    memcpy(&frame[7], pdu, pdu_len);

    size_t total = 7 + pdu_len;
    int sent = send(s_tcp_sock, frame, total, 0);
    if (sent != (int)total) {
        ESP_LOGW(TAG, "TCP send failed");
        tcp_disconnect();
        return ESP_FAIL;
    }

    int rxd = recv(s_tcp_sock, frame, 7, MSG_WAITALL);
    if (rxd != 7) {
        ESP_LOGW(TAG, "TCP MBAP header read failed (%d)", rxd);
        tcp_disconnect();
        return ESP_ERR_TIMEOUT;
    }

    uint16_t resp_tid = (frame[0] << 8) | frame[1];
    if (resp_tid != tid) {
        ESP_LOGW(TAG, "TCP TID mismatch (sent=%u recv=%u)", tid, resp_tid);
        tcp_disconnect();
        return ESP_ERR_INVALID_RESPONSE;
    }

    uint16_t data_len = (frame[4] << 8) | frame[5];
    if (data_len < 1 || data_len > TCP_MAX_FRAME - 7) {
        ESP_LOGW(TAG, "TCP invalid length: %d", data_len);
        tcp_disconnect();
        return ESP_ERR_INVALID_RESPONSE;
    }

    size_t pdu_resp_len = data_len - 1;
    rxd = recv(s_tcp_sock, response, pdu_resp_len, MSG_WAITALL);
    if (rxd != (int)pdu_resp_len) {
        ESP_LOGW(TAG, "TCP PDU read failed (%d / %zu)", rxd, pdu_resp_len);
        tcp_disconnect();
        return ESP_ERR_TIMEOUT;
    }

    if (response[0] & 0x80) {
        ESP_LOGW(TAG, "Modbus TCP exception: FC=0x%02X code=%d", response[0], response[1]);
        return ESP_ERR_INVALID_RESPONSE;
    }

    *resp_len = (size_t)rxd;
    return ESP_OK;
}

/* ── Public API ────────────────────────────────────────────────────────── */

esp_err_t modbus_adapter_init(const board_config_t *board, const modbus_config_t *cfg)
{
    if (!board || !cfg) return ESP_ERR_INVALID_ARG;

    /* Clean up previous init if any — take mutex first to wait for in-flight ops */
    if (s_mutex) {
        xSemaphoreTake(s_mutex, portMAX_DELAY);
        if (!s_is_rtu) tcp_disconnect();
        SemaphoreHandle_t old = s_mutex;
        s_mutex = NULL;   /* prevent new callers from acquiring */
        xSemaphoreGive(old);
        vSemaphoreDelete(old);
    }

    s_is_rtu = cfg->is_rtu;
    s_slave_addr = cfg->slave_addr;
    s_mutex = xSemaphoreCreateMutex();
    if (!s_mutex) {
        ESP_LOGE(TAG, "Mutex creation failed");
        return ESP_ERR_NO_MEM;
    }

    if (s_is_rtu) {
        return rs485_init(board, board->rs485_uart_port,
                          cfg->baud, cfg->data_bits, cfg->parity, cfg->stop_bits);
    } else {
        s_tcp_ip = cfg->server_ip;
        s_tcp_port = cfg->server_port;
        ESP_LOGI(TAG, "TCP mode: target " IPSTR ":%d unit=%d",
                 IP2STR(&s_tcp_ip), s_tcp_port, s_slave_addr);
        return ESP_OK;
    }
}

esp_err_t modbus_adapter_read(const reg_entry_t *entry, uint8_t *raw_bytes, size_t *out_len)
{
    if (!entry || !raw_bytes || !out_len) return ESP_ERR_INVALID_ARG;
    if (!s_mutex) return ESP_ERR_INVALID_STATE;

    xSemaphoreTake(s_mutex, portMAX_DELAY);

    esp_err_t ret;

    if (s_is_rtu) {
        uint8_t req[8];
        req[0] = s_slave_addr;
        req[1] = entry->func_code;
        req[2] = entry->offset >> 8;
        req[3] = entry->offset & 0xFF;
        req[4] = entry->length >> 8;
        req[5] = entry->length & 0xFF;
        uint16_t crc = crc16(req, 6);
        req[6] = crc & 0xFF;
        req[7] = crc >> 8;

        uint8_t resp[RTU_MAX_FRAME];
        size_t resp_len = 0;
        ret = rs485_transact(req, 8, resp, sizeof(resp), &resp_len, MODBUS_RTU_TIMEOUT_MS);
        if (ret == ESP_OK) {
            if (resp_len < 4) {
                ESP_LOGW(TAG, "RTU response too short (%zu bytes)", resp_len);
                ret = ESP_ERR_INVALID_RESPONSE;
            } else {
                uint16_t rx_crc = (resp[resp_len - 1] << 8) | resp[resp_len - 2];
                uint16_t calc_crc = crc16(resp, resp_len - 2);
                if (rx_crc != calc_crc) {
                    ESP_LOGW(TAG, "RTU CRC mismatch (rx=0x%04X calc=0x%04X)", rx_crc, calc_crc);
                    ret = ESP_ERR_INVALID_CRC;
                } else if (resp[1] & 0x80) {
                    ESP_LOGW(TAG, "Modbus exception: FC=0x%02X code=%d", resp[1], resp[2]);
                    ret = ESP_ERR_INVALID_RESPONSE;
                } else if (resp_len >= 5) {
                    uint8_t byte_count = resp[2];
                    if (byte_count > MODBUS_MAX_BYTE_COUNT) {
                        ESP_LOGW(TAG, "RTU byte_count too large: %d", byte_count);
                        ret = ESP_ERR_INVALID_RESPONSE;
                    } else if (byte_count > 0 && (3 + byte_count + 2) <= resp_len) {
                        memcpy(raw_bytes, &resp[3], byte_count);
                        *out_len = byte_count;
                    } else {
                        ret = ESP_ERR_INVALID_RESPONSE;
                    }
                } else {
                    ret = ESP_ERR_INVALID_RESPONSE;
                }
            }
        }
    } else {
        uint8_t pdu[5];
        pdu[0] = entry->func_code;
        pdu[1] = entry->offset >> 8;
        pdu[2] = entry->offset & 0xFF;
        pdu[3] = entry->length >> 8;
        pdu[4] = entry->length & 0xFF;

        uint8_t resp[TCP_MAX_FRAME];
        size_t resp_len = 0;
        ret = tcp_transact(pdu, 5, resp, &resp_len);
        if (ret == ESP_OK && resp_len >= 2) {
            uint8_t byte_count = resp[1];
            if (byte_count > MODBUS_MAX_BYTE_COUNT) {
                ESP_LOGW(TAG, "TCP byte_count too large: %d", byte_count);
                ret = ESP_ERR_INVALID_RESPONSE;
            } else if (byte_count > 0 && (2 + byte_count) <= resp_len) {
                memcpy(raw_bytes, &resp[2], byte_count);
                *out_len = byte_count;
            } else {
                ret = ESP_ERR_INVALID_RESPONSE;
            }
        }
    }

    xSemaphoreGive(s_mutex);
    return ret;
}

esp_err_t modbus_adapter_write(uint16_t offset, uint16_t value)
{
    if (!s_mutex) return ESP_ERR_INVALID_STATE;

    xSemaphoreTake(s_mutex, portMAX_DELAY);

    esp_err_t ret;

    if (s_is_rtu) {
        uint8_t req[8];
        req[0] = s_slave_addr;
        req[1] = 0x06;
        req[2] = offset >> 8;
        req[3] = offset & 0xFF;
        req[4] = value >> 8;
        req[5] = value & 0xFF;
        uint16_t crc = crc16(req, 6);
        req[6] = crc & 0xFF;
        req[7] = crc >> 8;

        uint8_t resp[RTU_MAX_FRAME];
        size_t resp_len = 0;
        ret = rs485_transact(req, 8, resp, sizeof(resp), &resp_len, MODBUS_RTU_TIMEOUT_MS);
        /* Validate write response echo */
        if (ret == ESP_OK && resp_len >= 6) {
            uint16_t rx_crc = (resp[resp_len - 1] << 8) | resp[resp_len - 2];
            uint16_t calc_crc = crc16(resp, resp_len - 2);
            if (rx_crc != calc_crc) {
                ESP_LOGW(TAG, "Write RTU CRC mismatch");
                ret = ESP_ERR_INVALID_CRC;
            } else if (resp[1] & 0x80) {
                ESP_LOGW(TAG, "Write exception: code=%d", resp[2]);
                ret = ESP_ERR_INVALID_RESPONSE;
            }
        }
    } else {
        uint8_t pdu[5];
        pdu[0] = 0x06;
        pdu[1] = offset >> 8;
        pdu[2] = offset & 0xFF;
        pdu[3] = value >> 8;
        pdu[4] = value & 0xFF;

        uint8_t resp[TCP_MAX_FRAME];
        size_t resp_len = 0;
        ret = tcp_transact(pdu, 5, resp, &resp_len);
    }

    xSemaphoreGive(s_mutex);
    return ret;
}

void modbus_adapter_deinit(void)
{
    /* Take mutex before deinit to prevent concurrent access */
    if (s_mutex) {
        xSemaphoreTake(s_mutex, portMAX_DELAY);
    }

    if (s_is_rtu) {
        rs485_deinit();
    } else {
        tcp_disconnect();
    }

    if (s_mutex) {
        SemaphoreHandle_t old = s_mutex;
        s_mutex = NULL;   /* prevent new callers from acquiring */
        xSemaphoreGive(old);
        vSemaphoreDelete(old);
    }
}
