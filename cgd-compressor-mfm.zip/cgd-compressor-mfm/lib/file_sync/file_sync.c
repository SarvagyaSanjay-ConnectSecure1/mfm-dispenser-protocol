#include "file_sync.h"
#include "project_config.h"
#include "esp_log.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <utime.h>

static const char *TAG = "file_sync";

#define MTIME_TOLERANCE  2  /* FAT32 has 2-second mtime granularity */

static esp_err_t copy_file(const char *src, const char *dst)
{
    FILE *fin = fopen(src, "rb");
    if (!fin) return ESP_FAIL;

    FILE *fout = fopen(dst, "wb");
    if (!fout) { fclose(fin); return ESP_FAIL; }

    char buf[256];
    size_t n;
    esp_err_t ret = ESP_OK;
    while ((n = fread(buf, 1, sizeof(buf), fin)) > 0) {
        if (fwrite(buf, 1, n, fout) != n) {
            ESP_LOGE(TAG, "Write failed: %s", dst);
            ret = ESP_FAIL;
            break;
        }
    }

    fclose(fin);
    fclose(fout);

    if (ret != ESP_OK) return ret;

    /* Match mtime on destination */
    struct stat st;
    if (stat(src, &st) == 0) {
        struct utimbuf ut = {
            .actime  = st.st_mtime,
            .modtime = st.st_mtime,
        };
        if (utime(dst, &ut) != 0) {
            ESP_LOGW(TAG, "utime failed for %s (may cause re-sync)", dst);
        }
    }

    return ESP_OK;
}

esp_err_t file_sync(const char *relative_path)
{
    if (!relative_path || !relative_path[0]) return ESP_ERR_INVALID_ARG;

    char sd_path[128];
    char lfs_path[128];
    snprintf(sd_path,  sizeof(sd_path),  SD_MOUNT_POINT "/%s", relative_path);
    snprintf(lfs_path, sizeof(lfs_path), LFS_BASE_PATH  "/%s", relative_path);

    struct stat sd_st, lfs_st;
    bool sd_exists  = (stat(sd_path, &sd_st) == 0);
    bool lfs_exists = (stat(lfs_path, &lfs_st) == 0);

    if (!sd_exists && !lfs_exists) {
        return ESP_OK; /* nothing to sync */
    }

    if (sd_exists && !lfs_exists) {
        ESP_LOGI(TAG, "SD -> LFS: %s", relative_path);
        return copy_file(sd_path, lfs_path);
    }

    if (!sd_exists && lfs_exists) {
        ESP_LOGI(TAG, "LFS -> SD: %s", relative_path);
        return copy_file(lfs_path, sd_path);
    }

    /* Both exist — compare mtime */
    long diff = (long)sd_st.st_mtime - (long)lfs_st.st_mtime;

    if (diff > MTIME_TOLERANCE) {
        ESP_LOGI(TAG, "SD newer -> LFS: %s", relative_path);
        return copy_file(sd_path, lfs_path);
    } else if (diff < -MTIME_TOLERANCE) {
        ESP_LOGI(TAG, "LFS newer -> SD: %s", relative_path);
        return copy_file(lfs_path, sd_path);
    }

    /* Files in sync */
    return ESP_OK;
}
