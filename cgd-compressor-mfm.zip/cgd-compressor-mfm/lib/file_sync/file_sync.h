#pragma once
#ifndef __FILE_SYNC_H__
#define __FILE_SYNC_H__

#include "esp_err.h"

/**
 * Synchronize a file between SD card and LittleFS.
 *
 * @param relative_path  File name relative to the mountpoints,
 *                       e.g. "iot_config.json".  The function internally
 *                       prepends SD_MOUNT_POINT and LFS_BASE_PATH.
 *
 * Compares modification times (st_mtime) with 2-second tolerance (FAT32):
 * - If SD is newer: copies SD → LFS
 * - If LFS is newer: copies LFS → SD
 * - If only one exists: copies to the other
 * - If neither exists: no-op
 *
 * After copy, sets mtime on destination to match source via utime().
 */
esp_err_t file_sync(const char *relative_path);

#endif
