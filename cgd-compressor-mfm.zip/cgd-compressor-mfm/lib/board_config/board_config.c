#include "board_config.h"
#include "project_config.h"

#include <string.h>
#include "esp_log.h"
#include "esp_mac.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "driver/i2c_master.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "driver/temperature_sensor.h"
#include "mbedtls/base64.h"

static const char *TAG = "board_config";

// I2C detection config
#define DETECT_I2C_PORT     I2C_NUM_0
#define DETECT_I2C_FREQ_HZ  100000
#define DETECT_I2C_TIMEOUT_MS 50

// W5500 version register
#define W5500_VERSION_REG   0x0039
#define W5500_EXPECTED_VER  0x04

// ---------------------------------------------------------------------------
// Static board config tables
// ---------------------------------------------------------------------------

static const board_config_t board_configs[] = {
    [BOARD_UNKNOWN] = {
        .name = "Unknown",
    },
    [BOARD_EVIDEN_V1] = {
        .name        = "Eviden IoT Device",
        .sda_pin     = 16,
        .scl_pin     = 15,
        .rtc_addr    = 0x68,
        .rs485_tx_pin = 17,
        .rs485_rx_pin = 18,
        .rs485_en_pin = 38,
        .rs485_uart_port = UART_NUM_1,
        .lora_tx_pin = 36,
        .lora_rx_pin = 37,
        .lora_m0     = -1,
        .lora_m1     = -1,
        .sd_spi_host = SPI3_HOST,
        .sd_miso_pin = 5,
        .sd_mosi_pin = 6,
        .sd_sclk_pin = 7,
        .sd_cs_pin   = 42,
        .w5500_spi_host = SPI2_HOST,
        .w5500_miso  = 11,
        .w5500_mosi  = 12,
        .w5500_sck   = 10,
        .w5500_cs    = 9,
        .w5500_rst   = 14,
        .default_wifi_ssid = "4G MIFI_C338",
        .default_wifi_pass = "12345678",
    },
    [BOARD_DIGITALPETRO_V1] = {
        .name        = "DigitalPetro IoT Device",
        .sda_pin     = 8,
        .scl_pin     = 9,
        .rtc_addr    = 0x68,
        .rs485_tx_pin = 17,
        .rs485_rx_pin = 18,
        .rs485_en_pin = -1,
        .rs485_uart_port = UART_NUM_1,
        .lora_tx_pin = 5,
        .lora_rx_pin = 6,
        .lora_m0     = 42,
        .lora_m1     = 38,
        .sd_spi_host = SPI3_HOST,
        .sd_miso_pin = 13,
        .sd_mosi_pin = 11,
        .sd_sclk_pin = 12,
        .sd_cs_pin   = 10,
        .w5500_spi_host = SPI2_HOST,
        .w5500_miso  = 4,
        .w5500_mosi  = 7,
        .w5500_sck   = 14,
        .w5500_cs    = 47,
        .w5500_rst   = 2,
        .default_wifi_ssid = "DigitalPetro",
        .default_wifi_pass = "D1g1t@lPetro",
    },
};

static const board_config_t *active_config = NULL;
static char s_chip_id[32] = {0};
static temperature_sensor_handle_t s_temp_sensor = NULL;

// ---------------------------------------------------------------------------
// Layer 1: I2C RTC probe
// ---------------------------------------------------------------------------

static bool i2c_probe_rtc(int sda_pin, int scl_pin, uint8_t rtc_addr)
{
    i2c_master_bus_config_t bus_cfg = {
        .i2c_port = DETECT_I2C_PORT,
        .sda_io_num = sda_pin,
        .scl_io_num = scl_pin,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };

    i2c_master_bus_handle_t bus = NULL;
    esp_err_t err = i2c_new_master_bus(&bus_cfg, &bus);
    if (err != ESP_OK) return false;

    err = i2c_master_probe(bus, rtc_addr, DETECT_I2C_TIMEOUT_MS);

    i2c_del_master_bus(bus);

    gpio_reset_pin(sda_pin);
    gpio_reset_pin(scl_pin);

    return (err == ESP_OK);
}

// ---------------------------------------------------------------------------
// Layer 2: W5500 SPI chip version probe
// ---------------------------------------------------------------------------

static bool spi_probe_w5500(const board_config_t *board)
{
    spi_bus_config_t bus_cfg = {
        .miso_io_num   = board->w5500_miso,
        .mosi_io_num   = board->w5500_mosi,
        .sclk_io_num   = board->w5500_sck,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
    };

    int spi_host = board->w5500_spi_host;

    esp_err_t err = spi_bus_initialize(spi_host, &bus_cfg, SPI_DMA_CH_AUTO);
    if (err != ESP_OK) return false;

    spi_device_handle_t dev;
    spi_device_interface_config_t dev_cfg = {
        .clock_speed_hz = 1 * 1000 * 1000,
        .mode           = 0,
        .spics_io_num   = board->w5500_cs,
        .queue_size     = 1,
    };

    err = spi_bus_add_device(spi_host, &dev_cfg, &dev);
    if (err != ESP_OK) {
        spi_bus_free(spi_host);
        return false;
    }

    uint8_t tx_buf[4] = {
        (W5500_VERSION_REG >> 8) & 0xFF,
        W5500_VERSION_REG & 0xFF,
        0x01,
        0x00,
    };
    uint8_t rx_buf[4] = {0};

    spi_transaction_t txn = {
        .length    = 32,
        .tx_buffer = tx_buf,
        .rx_buffer = rx_buf,
    };

    err = spi_device_transmit(dev, &txn);
    bool found = (err == ESP_OK && rx_buf[3] == W5500_EXPECTED_VER);

    spi_bus_remove_device(dev);
    spi_bus_free(spi_host);

    gpio_reset_pin(board->w5500_miso);
    gpio_reset_pin(board->w5500_mosi);
    gpio_reset_pin(board->w5500_sck);
    gpio_reset_pin(board->w5500_cs);

    return found;
}

// ---------------------------------------------------------------------------
// Layer 3: WiFi SSID-based detection (fallback)
// ---------------------------------------------------------------------------

static board_type_t detect_by_wifi_ssid(void)
{
    nvs_handle_t handle;
    if (nvs_open(NVS_NAMESPACE, NVS_READONLY, &handle) != ESP_OK)
        return BOARD_UNKNOWN;

    char ssid[64] = {0};
    size_t ssid_len = sizeof(ssid);
    esp_err_t err = nvs_get_str(handle, NVS_KEY_WIFI_SSID, ssid, &ssid_len);
    nvs_close(handle);

    if (err != ESP_OK || ssid[0] == '\0')
        return BOARD_UNKNOWN;

    for (int i = BOARD_UNKNOWN + 1; i < BOARD_TYPE_MAX; i++) {
        const char *brd_ssid = board_configs[i].default_wifi_ssid;
        if (brd_ssid && strcmp(ssid, brd_ssid) == 0) {
            ESP_LOGI(TAG, "  WiFi SSID '%s' -> %s", ssid, board_configs[i].name);
            return (board_type_t)i;
        }
    }

    ESP_LOGD(TAG, "  WiFi SSID '%s' not recognized", ssid);
    return BOARD_UNKNOWN;
}

// ---------------------------------------------------------------------------
// Auto-detection orchestrator
// ---------------------------------------------------------------------------

static board_type_t auto_detect_board(void)
{
    ESP_LOGI(TAG, "Auto-detecting board type...");

    for (int i = BOARD_UNKNOWN + 1; i < BOARD_TYPE_MAX; i++) {
        const board_config_t *cfg = &board_configs[i];
        ESP_LOGI(TAG, "  I2C probe: %s (SDA=%d, SCL=%d, addr=0x%02X)",
                 cfg->name, cfg->sda_pin, cfg->scl_pin, cfg->rtc_addr);

        if (i2c_probe_rtc(cfg->sda_pin, cfg->scl_pin, cfg->rtc_addr)) {
            ESP_LOGI(TAG, "  -> RTC found! Board identified as %s", cfg->name);
            return (board_type_t)i;
        }
    }

    ESP_LOGW(TAG, "  I2C probe inconclusive, trying W5500 SPI...");

    for (int i = BOARD_UNKNOWN + 1; i < BOARD_TYPE_MAX; i++) {
        const board_config_t *cfg = &board_configs[i];
        ESP_LOGI(TAG, "  SPI probe: %s (MISO=%d, MOSI=%d, SCK=%d, CS=%d)",
                 cfg->name, cfg->w5500_miso, cfg->w5500_mosi,
                 cfg->w5500_sck, cfg->w5500_cs);

        if (spi_probe_w5500(cfg)) {
            ESP_LOGI(TAG, "  -> W5500 found! Board identified as %s", cfg->name);
            return (board_type_t)i;
        }
    }

    ESP_LOGW(TAG, "  Hardware probes inconclusive, trying WiFi SSID...");

    board_type_t type = detect_by_wifi_ssid();
    if (type != BOARD_UNKNOWN) return type;

    ESP_LOGE(TAG, "  Auto-detection failed: no method could identify board");
    return BOARD_UNKNOWN;
}

// ---------------------------------------------------------------------------
// NVS helpers
// ---------------------------------------------------------------------------

static esp_err_t nvs_read_board_type(board_type_t *out)
{
    nvs_handle_t handle;
    esp_err_t err = nvs_open(NVS_NAMESPACE, NVS_READONLY, &handle);
    if (err != ESP_OK) return err;

    uint8_t val;
    err = nvs_get_u8(handle, NVS_KEY_BOARD_TYPE, &val);
    nvs_close(handle);

    if (err == ESP_OK) {
        if (val > BOARD_UNKNOWN && val < BOARD_TYPE_MAX) {
            *out = (board_type_t)val;
        } else {
            err = ESP_ERR_INVALID_ARG;
        }
    }
    return err;
}

static esp_err_t nvs_write_board_type(board_type_t type)
{
    nvs_handle_t handle;
    esp_err_t err = nvs_open(NVS_NAMESPACE, NVS_READWRITE, &handle);
    if (err != ESP_OK) return err;

    err = nvs_set_u8(handle, NVS_KEY_BOARD_TYPE, (uint8_t)type);
    if (err == ESP_OK) {
        err = nvs_commit(handle);
    }
    nvs_close(handle);
    return err;
}

// ---------------------------------------------------------------------------
// Chip ID generation (reversed MAC -> base64)
// ---------------------------------------------------------------------------

static void compute_chip_id(void)
{
    uint8_t mac[6];
    esp_err_t ret = esp_read_mac(mac, ESP_MAC_WIFI_STA);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "esp_read_mac failed: %s, using zeros", esp_err_to_name(ret));
        memset(mac, 0, sizeof(mac));
    }

    char mac_str[13];
    snprintf(mac_str, sizeof(mac_str), "%02X%02X%02X%02X%02X%02X",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

    int len = (int)strlen(mac_str);
    char reversed[13];
    for (int i = 0; i < len; i++)
        reversed[i] = mac_str[len - 1 - i];
    reversed[len] = '\0';

    size_t olen = 0;
    int b64_ret = mbedtls_base64_encode((unsigned char *)s_chip_id, sizeof(s_chip_id),
                                         &olen, (unsigned char *)reversed, len);
    if (b64_ret != 0) {
        ESP_LOGW(TAG, "base64_encode failed (%d), using MAC hex as chip ID", b64_ret);
        strncpy(s_chip_id, mac_str, sizeof(s_chip_id) - 1);
        s_chip_id[sizeof(s_chip_id) - 1] = '\0';
    } else {
        s_chip_id[olen] = '\0';
    }

    ESP_LOGI(TAG, "Chip-ID: %s (MAC: %s)", s_chip_id, mac_str);
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

esp_err_t board_config_init(void)
{
    compute_chip_id();

#ifdef BOARD_TYPE_OVERRIDE
    board_type_t type = (board_type_t)(BOARD_TYPE_OVERRIDE);
    if (type <= BOARD_UNKNOWN || type >= BOARD_TYPE_MAX) {
        ESP_LOGE(TAG, "Invalid BOARD_TYPE_OVERRIDE: %d", type);
        return ESP_FAIL;
    }
    active_config = &board_configs[type];
    ESP_LOGI(TAG, "Board type from build override: %s", active_config->name);
    return ESP_OK;
#else

    board_type_t type = BOARD_UNKNOWN;
    esp_err_t err = nvs_read_board_type(&type);
    if (err == ESP_OK) {
        active_config = &board_configs[type];
        ESP_LOGI(TAG, "Board type from NVS: %s", active_config->name);
        return ESP_OK;
    }

    ESP_LOGI(TAG, "No board type in NVS, starting auto-detection...");

    type = auto_detect_board();
    if (type == BOARD_UNKNOWN) {
        ESP_LOGE(TAG, "Board detection failed! Cannot determine hardware variant.");
        return ESP_FAIL;
    }

    err = nvs_write_board_type(type);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "Failed to save board type to NVS: %s", esp_err_to_name(err));
    } else {
        ESP_LOGI(TAG, "Board type saved to NVS: %s", board_configs[type].name);
    }

    active_config = &board_configs[type];
    return ESP_OK;
#endif
}

const board_config_t *board_config_get(void)
{
    return active_config;
}

esp_err_t board_config_set_type(board_type_t type)
{
    if (type <= BOARD_UNKNOWN || type >= BOARD_TYPE_MAX) {
        ESP_LOGE(TAG, "Invalid board type: %d", type);
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t err = nvs_write_board_type(type);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to write board type to NVS: %s", esp_err_to_name(err));
        return err;
    }

    active_config = &board_configs[type];
    ESP_LOGI(TAG, "Board type manually set to: %s (reboot to apply)", active_config->name);
    return ESP_OK;
}

const char *board_config_get_chip_id(void)
{
    return s_chip_id;
}

esp_err_t board_config_get_internal_temp(float *out_celsius)
{
    if (!out_celsius) return ESP_ERR_INVALID_ARG;

    if (!s_temp_sensor) {
        temperature_sensor_config_t cfg = TEMPERATURE_SENSOR_CONFIG_DEFAULT(-10, 80);
        esp_err_t err = temperature_sensor_install(&cfg, &s_temp_sensor);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "Internal temp sensor install failed");
            return err;
        }
        err = temperature_sensor_enable(s_temp_sensor);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "Internal temp sensor enable failed");
            temperature_sensor_uninstall(s_temp_sensor);
            s_temp_sensor = NULL;
            return err;
        }
    }

    return temperature_sensor_get_celsius(s_temp_sensor, out_celsius);
}
