#pragma once
#ifndef __BOARD_CONFIG_H__
#define __BOARD_CONFIG_H__

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

typedef enum {
    BOARD_UNKNOWN = 0,
    BOARD_EVIDEN_V1,
    BOARD_DIGITALPETRO_V1,
    BOARD_TYPE_MAX
} board_type_t;

typedef struct {
    const char  *name;

    // I2C
    int sda_pin;
    int scl_pin;
    uint8_t rtc_addr;

    // RS485
    int rs485_tx_pin;
    int rs485_rx_pin;
    int rs485_en_pin;       // -1 = auto RX/TX (no manual DE control)
    int rs485_uart_port;    // UART_NUM_1 or UART_NUM_2

    // LoRa
    int lora_tx_pin;
    int lora_rx_pin;
    int lora_m0;            // -1 = not present
    int lora_m1;            // -1 = not present

    // SD Card (SPI)
    int sd_spi_host;
    int sd_miso_pin;
    int sd_mosi_pin;
    int sd_sclk_pin;
    int sd_cs_pin;

    // W5500 Ethernet (SPI)
    int w5500_spi_host;
    int w5500_miso;
    int w5500_mosi;
    int w5500_sck;
    int w5500_cs;
    int w5500_rst;

    // Default WiFi (fallback when no creds found in SD/NVS/LFS)
    const char *default_wifi_ssid;
    const char *default_wifi_pass;
} board_config_t;

// Call once at start of app_main(). Returns ESP_OK or ESP_FAIL.
esp_err_t board_config_init(void);

// Get the active board config. Only valid after board_config_init() succeeds.
const board_config_t *board_config_get(void);

// Manually set board type (writes to NVS). For provisioning/debug.
esp_err_t board_config_set_type(board_type_t type);

// Get unique chip ID string (base64 of reversed MAC hex).
const char *board_config_get_chip_id(void);

// Read ESP32-S3 internal temperature sensor (lazy-init).
esp_err_t board_config_get_internal_temp(float *out_celsius);

#endif // __BOARD_CONFIG_H__
