#include "storage.h"
#include "project_config.h"
#include "nvs_flash.h"
#include "esp_littlefs.h"
#include "esp_vfs_fat.h"
#include "driver/sdspi_host.h"
#include "driver/spi_common.h"
#include "sdmmc_cmd.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdatomic.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "storage";

#define LFS_PARTITION           "spiffs"
#define STORAGE_MAX_FILE_SIZE   (32 * 1024)  /* 32 KB max for config files */

static sdmmc_card_t *s_card = NULL;
static _Atomic bool s_sd_mounted = false;
static int s_sd_spi_host = -1;
static bool s_spi_bus_inited = false;

/* SPI clock frequencies to try, highest first (kHz) */
static const int sd_freq_khz[] = {20000, 10000, 4000, 1000};
#define SD_FREQ_COUNT  (sizeof(sd_freq_khz) / sizeof(sd_freq_khz[0]))

/* ── NVS ──────────────────────────────────────────────────────────────── */

esp_err_t storage_init_nvs(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS partition truncated, erasing...");
        nvs_flash_erase();
        ret = nvs_flash_init();
    }
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "NVS init failed: %s", esp_err_to_name(ret));
    }
    return ret;
}

/* ── LittleFS ─────────────────────────────────────────────────────────── */

esp_err_t storage_init_lfs(void)
{
    esp_vfs_littlefs_conf_t lfs_cfg = {
        .base_path = LFS_BASE_PATH,
        .partition_label = LFS_PARTITION,
        .format_if_mount_failed = false,
        .dont_mount = false,
    };

    esp_err_t ret = esp_vfs_littlefs_register(&lfs_cfg);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "LittleFS mount failed, formatting and retrying...");
        esp_littlefs_format(LFS_PARTITION);
        lfs_cfg.format_if_mount_failed = true;
        ret = esp_vfs_littlefs_register(&lfs_cfg);
    }

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "LittleFS mount failed after format: %s", esp_err_to_name(ret));
        return ret;
    }

    size_t total = 0, used = 0;
    esp_littlefs_info(LFS_PARTITION, &total, &used);
    ESP_LOGI(TAG, "LittleFS mounted at %s (total=%zu used=%zu)", LFS_BASE_PATH, total, used);
    return ESP_OK;
}

/* ── SD card ──────────────────────────────────────────────────────────── */

esp_err_t storage_init_sd(const board_config_t *board)
{
    if (!board) return ESP_ERR_INVALID_ARG;
    if (s_sd_mounted) return ESP_OK;

    s_sd_spi_host = board->sd_spi_host;

    if (!s_spi_bus_inited) {
        spi_bus_config_t bus_cfg = {
            .mosi_io_num   = board->sd_mosi_pin,
            .miso_io_num   = board->sd_miso_pin,
            .sclk_io_num   = board->sd_sclk_pin,
            .quadwp_io_num = -1,
            .quadhd_io_num = -1,
            .max_transfer_sz = 4096,
        };

        esp_err_t ret = spi_bus_initialize(s_sd_spi_host, &bus_cfg, SPI_DMA_CH_AUTO);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "SD SPI bus init failed: %s", esp_err_to_name(ret));
            return ret;
        }
        s_spi_bus_inited = true;
    }

    sdspi_device_config_t slot_cfg = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_cfg.gpio_cs = board->sd_cs_pin;
    slot_cfg.host_id = s_sd_spi_host;

    esp_vfs_fat_sdmmc_mount_config_t mount_cfg = {
        .format_if_mount_failed = false,
        .max_files = 5,
        .allocation_unit_size = 0,
    };

    esp_err_t ret = ESP_FAIL;
    for (int i = 0; i < SD_FREQ_COUNT; i++) {
        sdmmc_host_t host = SDSPI_HOST_DEFAULT();
        host.slot         = s_sd_spi_host;
        host.max_freq_khz = sd_freq_khz[i];

        ret = esp_vfs_fat_sdspi_mount(SD_MOUNT_POINT, &host, &slot_cfg,
                                       &mount_cfg, &s_card);
        if (ret == ESP_OK) {
            s_sd_mounted = true;
            ESP_LOGI(TAG, "SD card mounted at %s (%d kHz)",
                     SD_MOUNT_POINT, sd_freq_khz[i]);
            sdmmc_card_print_info(stdout, s_card);
            return ESP_OK;
        }

        ESP_LOGW(TAG, "SD mount failed at %d kHz: %s",
                 sd_freq_khz[i], esp_err_to_name(ret));

        if (i < SD_FREQ_COUNT - 1)
            vTaskDelay(pdMS_TO_TICKS(100));
    }

    ESP_LOGE(TAG, "SD card mount failed at all frequencies");
    spi_bus_free(s_sd_spi_host);
    s_spi_bus_inited = false;
    return ret;
}

bool storage_sd_is_mounted(void)
{
    return s_sd_mounted;
}

void storage_deinit_sd(void)
{
    if (s_sd_mounted) {
        esp_vfs_fat_sdcard_unmount(SD_MOUNT_POINT, s_card);
        spi_bus_free(s_sd_spi_host);
        s_spi_bus_inited = false;
        s_card = NULL;
        s_sd_mounted = false;
    }
}

/* ── Helpers ───────────────────────────────────────────────────────────── */

static bool is_sd_path(const char *path)
{
    return (strncmp(path, SD_MOUNT_POINT, strlen(SD_MOUNT_POINT)) == 0);
}

static void mark_sd_removed(const char *path)
{
    /* Only mark SD removed on actual I/O errors, not file-not-found */
    if (s_sd_mounted && is_sd_path(path) && errno != ENOENT) {
        ESP_LOGW(TAG, "SD I/O failed (errno=%d), marking SD as removed: %s", errno, path);
        s_sd_mounted = false;
    }
}

/* ── File I/O ─────────────────────────────────────────────────────────── */

char *storage_read_file(const char *path)
{
    FILE *f = fopen(path, "r");
    if (!f) {
        mark_sd_removed(path);
        return NULL;
    }

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (sz <= 0) { fclose(f); return NULL; }
    if (sz > STORAGE_MAX_FILE_SIZE) {
        ESP_LOGW(TAG, "File too large (%ld bytes, max %d): %s",
                 sz, STORAGE_MAX_FILE_SIZE, path);
        fclose(f);
        return NULL;
    }

    char *buf = malloc(sz + 1);
    if (!buf) { fclose(f); return NULL; }

    size_t rd = fread(buf, 1, sz, f);
    fclose(f);
    buf[rd] = '\0';
    return buf;
}

esp_err_t storage_write_file(const char *path, const char *data)
{
    if (!path || !data) return ESP_ERR_INVALID_ARG;
    FILE *f = fopen(path, "w");
    if (!f) {
        ESP_LOGW(TAG, "Cannot write %s", path);
        mark_sd_removed(path);
        return ESP_FAIL;
    }
    int ret = fputs(data, f);
    fclose(f);
    if (ret == EOF) {
        ESP_LOGW(TAG, "fputs failed for %s", path);
        mark_sd_removed(path);
        return ESP_FAIL;
    }
    return ESP_OK;
}

/* ── SD health check ──────────────────────────────────────────────── */

#define SD_HEALTH_PATH  SD_MOUNT_POINT "/.health_check"
#define SD_HEALTH_DATA  "{\"test\":\"sd_health_check\"}"

bool storage_sd_health_check(uint32_t *write_ms, uint32_t *read_ms)
{
    if (write_ms) *write_ms = 0;
    if (read_ms)  *read_ms  = 0;

    if (!s_sd_mounted) return false;

    /* Write test */
    int64_t t0 = esp_timer_get_time();
    FILE *f = fopen(SD_HEALTH_PATH, "w");
    if (!f) return false;
    fputs(SD_HEALTH_DATA, f);
    fclose(f);
    int64_t t1 = esp_timer_get_time();
    if (write_ms) *write_ms = (uint32_t)((t1 - t0) / 1000);

    /* Read test */
    t0 = esp_timer_get_time();
    f = fopen(SD_HEALTH_PATH, "r");
    if (!f) return false;
    char buf[64];
    size_t rd = fread(buf, 1, sizeof(buf), f);
    fclose(f);
    if (rd == 0) {
        s_sd_mounted = false;
        return false;
    }
    t1 = esp_timer_get_time();
    if (read_ms) *read_ms = (uint32_t)((t1 - t0) / 1000);

    /* Cleanup */
    remove(SD_HEALTH_PATH);

    return true;
}

/* ── LittleFS operations ──────────────────────────────────────────────── */

esp_err_t storage_clear_lfs(void)
{
    return esp_littlefs_format(LFS_PARTITION);
}

esp_err_t storage_lfs_info(size_t *total, size_t *used)
{
    return esp_littlefs_info(LFS_PARTITION, total, used);
}

/* ── SD config operations ─────────────────────────────────────────────── */

int storage_clear_sd_configs(void)
{
    if (!s_sd_mounted) return 0;
    int deleted = 0;
    if (remove(CONFIG_PATH_SD) == 0) deleted++;
    if (remove(MQTT_CONFIG_PATH_SD) == 0) deleted++;
    return deleted;
}
