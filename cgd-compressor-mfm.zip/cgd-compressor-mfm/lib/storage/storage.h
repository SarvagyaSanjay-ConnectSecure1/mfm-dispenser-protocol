#pragma once
#ifndef __STORAGE_H__
#define __STORAGE_H__

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"
#include "board_config.h"

/**
 * Initialize NVS flash (erase + reinit on corrupt).
 */
esp_err_t storage_init_nvs(void);

/**
 * Mount LittleFS on partition "spiffs".
 * On failure: formats and retries once.
 */
esp_err_t storage_init_lfs(void);

/**
 * Mount SD card via SPI.
 * Returns ESP_OK or error (caller can retry later).
 */
esp_err_t storage_init_sd(const board_config_t *board);

/**
 * Check if SD card is mounted.
 */
bool storage_sd_is_mounted(void);

/**
 * Unmount SD card.
 */
void storage_deinit_sd(void);

/**
 * Read entire file into malloc'd buffer (null-terminated).
 * Caller must free() the returned pointer.
 * Returns NULL on failure.
 */
char *storage_read_file(const char *path);

/**
 * Write string data to file.
 */
esp_err_t storage_write_file(const char *path, const char *data);

/**
 * SD card health check: write + read a small test file, measure timings.
 * Returns true if SD is mounted and test passes.
 * write_ms / read_ms are set to measured times (0 if not mounted).
 */
bool storage_sd_health_check(uint32_t *write_ms, uint32_t *read_ms);

/**
 * Format LittleFS partition.
 */
esp_err_t storage_clear_lfs(void);

/**
 * Get LittleFS usage info.
 */
esp_err_t storage_lfs_info(size_t *total, size_t *used);

/**
 * Delete config files from SD card (config.json, mqtt_config.json).
 * Returns number of files successfully deleted.
 */
int storage_clear_sd_configs(void);

#endif
