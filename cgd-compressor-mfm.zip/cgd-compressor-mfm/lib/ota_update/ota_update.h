#pragma once
#ifndef __OTA_UPDATE_H__
#define __OTA_UPDATE_H__

#include <stdbool.h>
#include "esp_err.h"

typedef struct {
    char bin_url[256];
    char checksum_url[256];
    char target_ver[16];
} ota_params_t;

/**
 * Check if OTA is needed: target_ver present, URLs valid, and target > current.
 */
bool ota_check_needed(const char *current_ver, const char *target_ver,
                      const char *bin_url, const char *checksum_url);

/**
 * Perform OTA update (blocking):
 *   1. GET checksum_url -> parse {"checksum":"<md5hex>"}
 *   2. GET bin_url -> stream to OTA partition via esp_ota_ops
 *   3. Compute MD5, compare
 *   4. On match: set boot partition, esp_restart()
 *   5. On failure: retry up to OTA_MAX_RETRIES
 *
 * Returns ESP_FAIL if all retries exhausted. On success, device restarts.
 */
esp_err_t ota_perform(const ota_params_t *params);

/**
 * Launch OTA in a one-shot FreeRTOS task.
 * Copies params internally — caller's struct can go out of scope.
 */
esp_err_t ota_launch_async(const ota_params_t *params);

/**
 * High-level OTA entry point: validates inputs, optionally checks version,
 * and launches async OTA.
 * @param version  NULL or empty to force OTA (skip version check).
 * Returns ESP_ERR_INVALID_ARG if URLs missing,
 *         ESP_ERR_INVALID_VERSION if version provided but not newer.
 */
esp_err_t ota_start(const char *bin_url, const char *checksum_url,
                    const char *version);

#endif
