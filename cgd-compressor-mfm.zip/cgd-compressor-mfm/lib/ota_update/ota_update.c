#include "ota_update.h"
#include "project_config.h"
#include "esp_ota_ops.h"
#include "esp_http_client.h"
#include "esp_crt_bundle.h"
#include "esp_log.h"
#include "cJSON.h"
#include "esp_rom_md5.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdatomic.h>
#include <string.h>
#include <stdlib.h>

static const char *TAG = "ota";
static _Atomic bool s_ota_in_progress = false;

/* ── Version comparison ────────────────────────────────────────────────── */

static int compare_versions(const char *a, const char *b)
{
    int a_major = 0, a_minor = 0, a_patch = 0;
    int b_major = 0, b_minor = 0, b_patch = 0;

    if (sscanf(a, "%d.%d.%d", &a_major, &a_minor, &a_patch) < 1) return 0;
    if (sscanf(b, "%d.%d.%d", &b_major, &b_minor, &b_patch) < 1) return 0;

    if (a_major != b_major) return a_major - b_major;
    if (a_minor != b_minor) return a_minor - b_minor;
    return a_patch - b_patch;
}

bool ota_check_needed(const char *current_ver, const char *target_ver,
                      const char *bin_url, const char *checksum_url)
{
    if (!current_ver || current_ver[0] == '\0') return false;
    if (!target_ver || target_ver[0] == '\0') return false;
    if (!bin_url || bin_url[0] == '\0') return false;
    if (!checksum_url || checksum_url[0] == '\0') return false;

    int result = compare_versions(current_ver, target_ver);
    ESP_LOGI(TAG, "Version check: current=%s target=%s result=%d",
             current_ver, target_ver, result);
    return (result < 0);
}

/* ── Fetch expected MD5 from server ────────────────────────────────────── */

static esp_err_t fetch_expected_md5(const char *url,
                                     char *md5_out, size_t md5_sz)
{
    char *resp_buf = malloc(512);
    if (!resp_buf) return ESP_ERR_NO_MEM;
    int resp_len = 0;

    esp_http_client_config_t cfg = {
        .url = url,
        .method = HTTP_METHOD_GET,
        .timeout_ms = 15000,
        .crt_bundle_attach = esp_crt_bundle_attach,
    };

    esp_http_client_handle_t client = esp_http_client_init(&cfg);
    if (!client) {
        free(resp_buf);
        return ESP_ERR_NO_MEM;
    }

    esp_err_t err = esp_http_client_open(client, 0);
    if (err != ESP_OK) {
        esp_http_client_cleanup(client);
        free(resp_buf);
        return err;
    }

    int hdr_len = esp_http_client_fetch_headers(client);
    int status = esp_http_client_get_status_code(client);
    if (hdr_len < 0 || status < 200 || status >= 300) {
        ESP_LOGW(TAG, "Checksum fetch failed (HTTP %d)", status);
        esp_http_client_close(client);
        esp_http_client_cleanup(client);
        free(resp_buf);
        return ESP_FAIL;
    }

    resp_len = esp_http_client_read(client, resp_buf, 511);
    esp_http_client_close(client);
    esp_http_client_cleanup(client);

    if (resp_len <= 0) {
        free(resp_buf);
        return ESP_FAIL;
    }
    resp_buf[resp_len] = '\0';

    /* Parse {"checksum":"<md5hex>"} */
    cJSON *root = cJSON_Parse(resp_buf);
    free(resp_buf);
    if (!root) return ESP_FAIL;

    cJSON *cs = cJSON_GetObjectItem(root, "checksum");
    if (!cs || !cJSON_IsString(cs) || strlen(cs->valuestring) != 32) {
        cJSON_Delete(root);
        return ESP_FAIL;
    }

    strncpy(md5_out, cs->valuestring, md5_sz - 1);
    md5_out[md5_sz - 1] = '\0';
    cJSON_Delete(root);

    ESP_LOGI(TAG, "Expected MD5: %s", md5_out);
    return ESP_OK;
}

/* ── OTA download + flash ──────────────────────────────────────────────── */

esp_err_t ota_perform(const ota_params_t *params)
{
    if (!params || !params->bin_url[0] || !params->checksum_url[0]) {
        ESP_LOGE(TAG, "OTA URLs not configured");
        return ESP_ERR_INVALID_STATE;
    }

    for (int attempt = 0; attempt < OTA_MAX_RETRIES; attempt++) {
        ESP_LOGI(TAG, "OTA attempt %d/%d", attempt + 1, OTA_MAX_RETRIES);

        /* Step 1: Fetch expected MD5 */
        char expected_md5[33] = {0};
        if (fetch_expected_md5(params->checksum_url,
                               expected_md5, sizeof(expected_md5)) != ESP_OK) {
            ESP_LOGW(TAG, "Failed to fetch MD5 checksum");
            vTaskDelay(pdMS_TO_TICKS(5000));
            continue;
        }

        /* Step 2: Find OTA partition */
        const esp_partition_t *update_part = esp_ota_get_next_update_partition(NULL);
        if (!update_part) {
            ESP_LOGE(TAG, "No OTA partition found");
            return ESP_FAIL;
        }

        esp_ota_handle_t ota_handle;
        esp_err_t err = esp_ota_begin(update_part, OTA_SIZE_UNKNOWN, &ota_handle);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "esp_ota_begin failed: %s", esp_err_to_name(err));
            vTaskDelay(pdMS_TO_TICKS(5000));
            continue;
        }

        /* Step 3: Stream firmware */
        md5_context_t md5_ctx;
        esp_rom_md5_init(&md5_ctx);

        esp_http_client_config_t http_cfg = {
            .url = params->bin_url,
            .method = HTTP_METHOD_GET,
            .timeout_ms = OTA_TIMEOUT_MS,
            .crt_bundle_attach = esp_crt_bundle_attach,
        };

        esp_http_client_handle_t client = esp_http_client_init(&http_cfg);
        if (!client) {
            ESP_LOGW(TAG, "HTTP client init failed");
            esp_ota_abort(ota_handle);
            vTaskDelay(pdMS_TO_TICKS(5000));
            continue;
        }
        err = esp_http_client_open(client, 0);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "HTTP open failed: %s", esp_err_to_name(err));
            esp_ota_abort(ota_handle);
            esp_http_client_cleanup(client);
            vTaskDelay(pdMS_TO_TICKS(5000));
            continue;
        }

        int content_length = esp_http_client_fetch_headers(client);
        int http_status = esp_http_client_get_status_code(client);
        if (http_status < 200 || http_status >= 300) {
            ESP_LOGW(TAG, "Firmware download HTTP %d", http_status);
            esp_http_client_close(client);
            esp_http_client_cleanup(client);
            esp_ota_abort(ota_handle);
            vTaskDelay(pdMS_TO_TICKS(5000));
            continue;
        }
        ESP_LOGI(TAG, "Firmware size: %d bytes (HTTP %d)", content_length, http_status);

        char buf[1024];
        int total = 0;
        bool ok = true;
        int read_len;
        TickType_t last_log = xTaskGetTickCount();

        while ((read_len = esp_http_client_read(client, buf, sizeof(buf))) > 0) {
            esp_rom_md5_update(&md5_ctx, buf, read_len);
            err = esp_ota_write(ota_handle, buf, read_len);
            if (err != ESP_OK) {
                ESP_LOGE(TAG, "esp_ota_write failed: %s", esp_err_to_name(err));
                ok = false;
                break;
            }
            total += read_len;

            /* Log progress every 5 seconds */
            if ((xTaskGetTickCount() - last_log) >= pdMS_TO_TICKS(5000)) {
                float pct = content_length > 0 ?
                    (total * 100.0f) / content_length : 0;
                ESP_LOGI(TAG, "OTA progress: %.1f%% (%d bytes)", pct, total);
                last_log = xTaskGetTickCount();
            }
        }

        esp_http_client_close(client);
        esp_http_client_cleanup(client);

        if (!ok || total == 0) {
            ESP_LOGW(TAG, "OTA download incomplete (total=%d)", total);
            esp_ota_abort(ota_handle);
            vTaskDelay(pdMS_TO_TICKS(5000));
            continue;
        }

        /* Step 4: Verify MD5 */
        unsigned char digest[16];
        esp_rom_md5_final(digest, &md5_ctx);

        char computed_md5[33];
        for (int i = 0; i < 16; i++)
            snprintf(&computed_md5[i * 2], 3, "%02x", digest[i]);

        if (strcasecmp(computed_md5, expected_md5) != 0) {
            ESP_LOGE(TAG, "MD5 mismatch: expected=%s got=%s", expected_md5, computed_md5);
            esp_ota_abort(ota_handle);
            vTaskDelay(pdMS_TO_TICKS(5000));
            continue;
        }

        ESP_LOGI(TAG, "MD5 verified OK");

        /* Step 5: Finalize */
        err = esp_ota_end(ota_handle);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "esp_ota_end failed: %s", esp_err_to_name(err));
            continue;
        }

        err = esp_ota_set_boot_partition(update_part);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to set boot partition: %s", esp_err_to_name(err));
            continue;
        }

        ESP_LOGI(TAG, "OTA success! Rebooting to v%s ...", params->target_ver);
        vTaskDelay(pdMS_TO_TICKS(1000));
        esp_restart();
        /* does not return */
    }

    ESP_LOGE(TAG, "OTA failed after %d attempts", OTA_MAX_RETRIES);
    return ESP_FAIL;
}

/* ── Async OTA task ───────────────────────────────────────────────────── */

static void ota_task(void *arg)
{
    ota_params_t *params = (ota_params_t *)arg;
    ota_perform(params);
    free(params);
    s_ota_in_progress = false;
    ESP_LOGW(TAG, "OTA task finished (no update applied)");
    vTaskDelete(NULL);
}

esp_err_t ota_launch_async(const ota_params_t *params)
{
    if (!params) return ESP_ERR_INVALID_ARG;

    /* Prevent double-launch */
    bool expected = false;
    if (!atomic_compare_exchange_strong(&s_ota_in_progress, &expected, true)) {
        ESP_LOGW(TAG, "OTA already in progress, skipping");
        return ESP_ERR_INVALID_STATE;
    }

    ota_params_t *copy = malloc(sizeof(ota_params_t));
    if (!copy) {
        s_ota_in_progress = false;
        return ESP_ERR_NO_MEM;
    }
    memcpy(copy, params, sizeof(ota_params_t));

    BaseType_t ret = xTaskCreate(ota_task, "ota", 8192, copy, 5, NULL);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create OTA task");
        free(copy);
        s_ota_in_progress = false;
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}

esp_err_t ota_start(const char *bin_url, const char *checksum_url,
                    const char *version)
{
    if (!bin_url || !bin_url[0] || !checksum_url || !checksum_url[0]) {
        return ESP_ERR_INVALID_ARG;
    }

    bool has_version = (version && version[0]);
    if (has_version) {
        if (!ota_check_needed(FW_VERSION, version, bin_url, checksum_url)) {
            ESP_LOGI(TAG, "OTA skipped: version %s not newer than %s", version, FW_VERSION);
            return ESP_ERR_INVALID_VERSION;
        }
    } else {
        ESP_LOGI(TAG, "Forced OTA (no version check)");
    }

    ota_params_t p = {0};
    strncpy(p.bin_url, bin_url, sizeof(p.bin_url) - 1);
    strncpy(p.checksum_url, checksum_url, sizeof(p.checksum_url) - 1);
    if (has_version)
        strncpy(p.target_ver, version, sizeof(p.target_ver) - 1);

    return ota_launch_async(&p);
}
