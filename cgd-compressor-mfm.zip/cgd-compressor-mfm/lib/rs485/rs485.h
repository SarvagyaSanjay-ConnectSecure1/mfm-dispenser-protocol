#pragma once
#ifndef __RS485_H__
#define __RS485_H__

#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
#include "board_config.h"

/**
 * Initialize RS485 UART transport.
 * Configures UART with given serial parameters and RS485 half-duplex mode.
 */
esp_err_t rs485_init(const board_config_t *board, int uart_port,
                     uint32_t baud, uint8_t data_bits, uint8_t parity, uint8_t stop_bits);

/**
 * Send a raw frame and wait for a response.
 * - Flushes RX buffer
 * - Sends request
 * - Two-phase receive: first byte with full timeout, then drain with inter-char gap
 * - Returns raw bytes (no CRC/protocol validation)
 */
esp_err_t rs485_transact(const uint8_t *request, size_t req_len,
                         uint8_t *response, size_t resp_buf_len,
                         size_t *resp_len, uint32_t timeout_ms);

/**
 * Flush the RX buffer.
 */
void rs485_flush(void);

/**
 * Deinit RS485 (deletes UART driver).
 */
void rs485_deinit(void);

#endif
