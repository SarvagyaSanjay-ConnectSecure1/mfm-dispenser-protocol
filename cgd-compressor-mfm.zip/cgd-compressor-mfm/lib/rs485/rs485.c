#include "rs485.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "rs485";

#define UART_BUF_SIZE   512
#define INTER_CHAR_MS   20      /* inter-character gap for two-phase receive */

static int s_uart_port = UART_NUM_1;

esp_err_t rs485_init(const board_config_t *board, int uart_port,
                     uint32_t baud, uint8_t data_bits, uint8_t parity, uint8_t stop_bits)
{
    if (!board) return ESP_ERR_INVALID_ARG;

    s_uart_port = uart_port;

    uart_word_length_t word_len = (data_bits == 7) ?
        UART_DATA_7_BITS : UART_DATA_8_BITS;

    uart_parity_t uart_parity;
    switch (parity) {
    case 'E': uart_parity = UART_PARITY_EVEN; break;
    case 'O': uart_parity = UART_PARITY_ODD;  break;
    default:  uart_parity = UART_PARITY_DISABLE; break;
    }

    uart_stop_bits_t uart_stop = (stop_bits == 2) ?
        UART_STOP_BITS_2 : UART_STOP_BITS_1;

    uart_config_t uart_cfg = {
        .baud_rate  = (int)baud,
        .data_bits  = word_len,
        .parity     = uart_parity,
        .stop_bits  = uart_stop,
        .flow_ctrl  = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    esp_err_t ret = uart_driver_install(s_uart_port, UART_BUF_SIZE, UART_BUF_SIZE, 0, NULL, 0);
    if (ret != ESP_OK) return ret;

    ret = uart_param_config(s_uart_port, &uart_cfg);
    if (ret != ESP_OK) {
        uart_driver_delete(s_uart_port);
        return ret;
    }

    /* RS485 DE pin handling */
    if (board->rs485_en_pin >= 0) {
        ret = uart_set_pin(s_uart_port, board->rs485_tx_pin, board->rs485_rx_pin,
                           board->rs485_en_pin, UART_PIN_NO_CHANGE);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "uart_set_pin failed: %s", esp_err_to_name(ret));
            uart_driver_delete(s_uart_port);
            return ret;
        }
        ret = uart_set_mode(s_uart_port, UART_MODE_RS485_HALF_DUPLEX);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "uart_set_mode failed: %s", esp_err_to_name(ret));
            uart_driver_delete(s_uart_port);
            return ret;
        }
    } else {
        ret = uart_set_pin(s_uart_port, board->rs485_tx_pin, board->rs485_rx_pin,
                           UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "uart_set_pin failed: %s", esp_err_to_name(ret));
            uart_driver_delete(s_uart_port);
            return ret;
        }
    }

    ESP_LOGI(TAG, "RS485 init OK (TX=%d RX=%d DE=%d baud=%lu %d%c%d)",
             board->rs485_tx_pin, board->rs485_rx_pin, board->rs485_en_pin,
             baud, data_bits, (char)parity, stop_bits);
    return ESP_OK;
}

esp_err_t rs485_transact(const uint8_t *request, size_t req_len,
                         uint8_t *response, size_t resp_buf_len,
                         size_t *resp_len, uint32_t timeout_ms)
{
    /* Flush RX */
    uart_flush_input(s_uart_port);

    /* Send request */
    int written = uart_write_bytes(s_uart_port, request, req_len);
    if (written != (int)req_len) {
        ESP_LOGE(TAG, "RS485 write failed");
        return ESP_FAIL;
    }

    /* Wait for TX FIFO to drain before switching to RX */
    esp_err_t ret = uart_wait_tx_done(s_uart_port, pdMS_TO_TICKS(100));
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "uart_wait_tx_done failed: %s", esp_err_to_name(ret));
    }

    /* Two-phase receive:
     * Phase 1: wait for first byte with full timeout
     * Phase 2: drain remaining bytes with short inter-character timeout
     */
    int rxd = uart_read_bytes(s_uart_port, response, 1, pdMS_TO_TICKS(timeout_ms));
    if (rxd <= 0) {
        ESP_LOGW(TAG, "RS485 timeout (no response)");
        return ESP_ERR_TIMEOUT;
    }

    size_t total = 1;
    while (total < resp_buf_len) {
        int n = uart_read_bytes(s_uart_port, response + total,
                                resp_buf_len - total, pdMS_TO_TICKS(INTER_CHAR_MS));
        if (n <= 0) break;
        total += n;
    }

    *resp_len = total;
    return ESP_OK;
}

void rs485_flush(void)
{
    uart_flush_input(s_uart_port);
}

void rs485_deinit(void)
{
    uart_driver_delete(s_uart_port);
}
