# Dispenser Protocol Support Library

This directory contains protocol specifications and implementations for various dispenser manufacturers supported by the CGD Compressor MFM system.

## Directory Structure

```
dispenser_protocols/
├── gasorex_sr_energy/              # Gasorex SR Energy dispenser system
│   ├── PROTOCOL.md                  # Detailed protocol specification
│   ├── register_map.csv             # Register address mapping (tabular)
│   ├── sample_config_*.json         # Example iot_config.json files
│   ├── gasorex_protocol_handler.h   # C header for protocol parsing
│   ├── gasorex_protocol_handler.c   # C implementation of parser
│   └── CMakeLists.txt               # Build configuration
│
├── company_b_protocol/              # (To be added)
├── company_c_protocol/              # (To be added)
├── company_d_protocol/              # (To be added)
│
└── CMakeLists.txt                   # Root build file
```

## Quick Start

### For Gasorex SR Energy

1. **Read the specification:**
   - See [PROTOCOL.md](gasorex_sr_energy/PROTOCOL.md) for complete technical details
   - Review [register_map.csv](gasorex_sr_energy/register_map.csv) for register layout

2. **Configure your device:**
   - Copy one of the sample JSON configs to your SD card as `iot_config.json`:
     - `sample_config_single_unit.json` - Read both Side A and Side B together (recommended)
     - `sample_config_separate_sides.json` - Side A only (for separate device instance)
     - `sample_config_side_b.json` - Side B only (for separate device instance)

3. **Update configuration values:**
   - Set `ro_code` to your pump identifier
   - Set `c_id` to a unique device ID
   - Adjust `post_interval` if needed (default 30 seconds)
   - Ensure RS-485 connection parameters match your GSR-CU-23 controller:
     - Baud: 9600 (configurable, check controller manual)
     - Parity: Even (standard for Gasorex)
     - Data bits: 8
     - Stop bits: 1

4. **Boot the ESP32:**
   - Device will load config from SD card or Azure Device Twin
   - Modbus adapter will initialize with configured parameters
   - Polling begins automatically

### Cloud-Side Data Parsing

The ESP32 sends raw Modbus register data as hex strings in telemetry JSON. Use the protocol handler functions (or equivalent cloud logic) to parse:

**Example Azure Function (JavaScript):**

```javascript
const gasorex = require('./gasorex_protocol_handler');

function parseGasorexTelemetry(regData) {
  // regData = [
  //   { addr: 1, len: 14, data: "hex_string_for_side_a" },
  //   { addr: 16, len: 15, data: "hex_string_for_side_b" }
  // ]

  const sideAHex = regData[0].data;
  const sideBHex = regData[1].data;

  const sideABuf = Buffer.from(sideAHex, 'hex');
  const sideBBuf = Buffer.from(sideBHex, 'hex');

  // Parse using gasorex_parse_telemetry equivalent
  const telemetry = {
    timestamp: new Date().toISOString(),
    side_a: {
      amount_rs: parseFloat32(sideABuf, 0),
      quantity_kg: parseFloat32(sideABuf, 4),
      e_totalizer_rs: parseFloat32(sideABuf, 8),
      fm_totalizer_kg: parseFloat32(sideABuf, 12),
      pt1_pressure_bar: sideABuf.readUInt16BE(16) * 0.1,
      pt2_pressure_bar: sideABuf.readUInt16BE(18) * 0.1,
      flowrate_kg_min: parseFloat32(sideABuf, 20),
      error_status: sideABuf.readUInt16BE(24),
      e_stop_active: sideABuf.readUInt16BE(26) !== 0,
      temperature_c: (sideABuf.readInt16BE(28) * 0.1)
    },
    side_b: {
      // Similar structure for Side B from sideBBuf
    }
  };

  return telemetry;
}

function parseFloat32(buf, offset) {
  const high = buf.readUInt32BE(offset);
  return buf.buffer.readFloatBE ? 
    buf.readFloatBE(offset) : 
    new Float32Array(new Uint8Array(buf.slice(offset, offset + 4)).buffer)[0];
}
```

## Protocol Specifications Summary

### Gasorex SR Energy (GSR-CU-23)

| Aspect | Details |
|--------|---------|
| **Communication** | RS-485 Modbus RTU |
| **Slave Address** | Configurable (default 1) |
| **Baud Rate** | 9600 bps (typical) |
| **Parity** | Even |
| **Sides** | 2 (Side A + Side B) |
| **Key Metrics** | Amount (Rs), Quantity (Kg), Flowrate (kg/min), Pressure (bar), Temperature (°C) |
| **Registers** | 34 total (Sides A/B + Pricing) |
| **Data Types** | 32-bit floats (split across register pairs), 16-bit integers |
| **Error Handling** | Modbus CRC-16, error status flags, emergency stop control |

## Integration Notes

### Adding a Protocol Handler to the Firmware

If you want to use the optional protocol handler instead of raw telemetry:

1. **Include the header in your main file:**
   ```c
   #include "gasorex_protocol_handler.h"
   ```

2. **After reading registers via modbus_adapter, parse them:**
   ```c
   // raw_bufs[0] = side A data (regs 1-14)
   // raw_bufs[1] = side B data (regs 16-30)
   
   gasorex_telemetry_t telemetry;
   if (gasorex_parse_telemetry((const uint8_t **)raw_bufs, lens, 2, &telemetry)) {
       // Send parsed JSON instead of raw hex
       // BuildTelemetryJSON(&telemetry, ...);
   }
   ```

3. **Optional: Call emergency stop control:**
   ```c
   uint8_t frame[8];
   size_t frame_len = gasorex_build_emergency_stop_frame(
       1,      // slave_addr
       'A',    // side (A or B)
       true,   // set_stop (true = set, false = reset)
       frame,
       sizeof(frame)
   );
   modbus_adapter_write(frame, frame_len);
   ```

### Why Use the Protocol Handler?

✅ **Pros:**
- Automatic float parsing (no cloud-side conversion needed)
- Structured data (easier to log, alarm on)
- Error flag decoding (safety monitoring)
- Emergency stop command builder (for control)

❌ **Cons:**
- Adds ~2 KB firmware size
- Minimal performance impact (one-time parse per poll cycle)

## Troubleshooting

### No Data in Telemetry
- Check RS-485 physical connection (A/B wires, termination)
- Verify baud rate and parity match GSR-CU-23 settings
- Check slave address (usually 1, but verify with Gasorex config)
- Review ESP logs for "CRC errors" or "timeout"

### Incorrect Register Values
- Verify big-endian byte order in parsing (first byte = MSB)
- Check that 32-bit floats are combined correctly: `(high << 16) | low`
- Review scaling factors (pressure: ×0.1, flowrate: ×0.001, etc.)

### Emergency Stop Not Working
- Ensure register 14 (Side A) or 29 (Side B) is writable (FC03)
- Verify CRC is calculated correctly before sending command
- Check Gasorex controller manual for emergency stop behavior

## Future Extensions

When adding the second, third, and fourth dispenser protocols:

1. Follow the same structure as `gasorex_sr_energy/`
2. Create `PROTOCOL.md` with detailed register spec
3. Create `register_map.csv` for easy reference
4. Provide sample JSON configs for different configurations
5. Implement protocol handler (optional) with company-specific parsing
6. Document differences from Gasorex (e.g., different slave addressing, function codes)

### Template for New Protocol:

```
lib/dispenser_protocols/
└── company_x_model_y/
    ├── PROTOCOL.md               # Specification
    ├── register_map.csv          # Register layout
    ├── sample_config_*.json      # Configuration examples
    ├── company_x_handler.h       # Protocol parser header (optional)
    ├── company_x_handler.c       # Protocol parser implementation (optional)
    ├── CMakeLists.txt            # Build config (if implementing handler)
    └── README.md                 # Quick start guide (if different from template)
```

## References

- [PROTOCOL.md - Gasorex SR Energy Complete Spec](gasorex_sr_energy/PROTOCOL.md)
- [register_map.csv - Gasorex All Registers](gasorex_sr_energy/register_map.csv)
- Modbus RTU Standard: IEC 61158-2
- RS-485 Standard: EIA/TIA-485-A
