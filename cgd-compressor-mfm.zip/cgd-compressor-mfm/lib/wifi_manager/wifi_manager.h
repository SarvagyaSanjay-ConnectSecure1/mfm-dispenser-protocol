#pragma once
#ifndef __WIFI_MANAGER_H__
#define __WIFI_MANAGER_H__

#include <stdbool.h>
#include "esp_err.h"

esp_err_t wifi_manager_init(const char *ssid, const char *password);
bool      wifi_manager_is_connected(void);

#endif
