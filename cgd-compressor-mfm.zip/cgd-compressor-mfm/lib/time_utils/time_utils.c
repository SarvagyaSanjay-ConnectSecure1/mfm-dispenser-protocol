#include "time_utils.h"
#include "driver/i2c_master.h"
#include "esp_sntp.h"
#include "esp_log.h"
#include <sys/time.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <time.h>
#include "project_config.h"

static const char *TAG = "time_utils";

/* Portable UTC mktime — ESP-IDF newlib does not expose timegm() */
static time_t utc_mktime(struct tm *tm)
{
    static const int mon_days[] = {0,31,59,90,120,151,181,212,243,273,304,334};
    int year = tm->tm_year + 1900;
    int mon  = tm->tm_mon;  /* 0-11 */
    if (mon < 0 || mon > 11) return (time_t)-1;

    long days = (year - 1970) * 365L
              + (year - 1969) / 4
              - (year - 1901) / 100
              + (year - 1601) / 400;
    days += mon_days[mon];
    /* leap day for current year if past February */
    if (mon > 1 && ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0))
        days++;
    days += tm->tm_mday - 1;

    return (time_t)(days * 86400L + tm->tm_hour * 3600 + tm->tm_min * 60 + tm->tm_sec);
}

/* ====================================================================== */
/*  RTC driver (DS3231 over I2C)                                          */
/* ====================================================================== */

#define RTC_WRITE_RETRIES  2
#define RTC_RETRY_DELAY_MS 50
#define RTC_DRIFT_THRESH_S 2

static i2c_master_bus_handle_t s_i2c_bus = NULL;
static i2c_master_dev_handle_t s_i2c_dev = NULL;
static bool s_rtc_ok = false;
static _Atomic bool s_clock_seeded = false;  /* true once system clock has been set from any source */

static uint8_t bcd_to_dec(uint8_t bcd) { return (bcd >> 4) * 10 + (bcd & 0x0F); }
static uint8_t dec_to_bcd(uint8_t dec) { return ((dec / 10) << 4) | (dec % 10); }

static esp_err_t rtc_init(const board_config_t *board)
{
    i2c_master_bus_config_t bus_cfg = {
        .i2c_port = I2C_NUM_0,
        .sda_io_num = board->sda_pin,
        .scl_io_num = board->scl_pin,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    esp_err_t ret = i2c_new_master_bus(&bus_cfg, &s_i2c_bus);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C bus init failed: %s", esp_err_to_name(ret));
        return ret;
    }

    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = board->rtc_addr,
        .scl_speed_hz = 100000,
    };
    ret = i2c_master_bus_add_device(s_i2c_bus, &dev_cfg, &s_i2c_dev);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "I2C RTC device add failed: %s", esp_err_to_name(ret));
        i2c_del_master_bus(s_i2c_bus);
        s_i2c_bus = NULL;
        return ret;
    }

    ESP_LOGI(TAG, "RTC init OK (SDA=%d SCL=%d addr=0x%02X)",
             board->sda_pin, board->scl_pin, board->rtc_addr);
    return ESP_OK;
}

static esp_err_t rtc_get_time(struct tm *t)
{
    if (!s_i2c_dev) return ESP_ERR_INVALID_STATE;

    uint8_t reg = 0x00;
    uint8_t data[7];
    esp_err_t ret = i2c_master_transmit_receive(s_i2c_dev, &reg, 1, data, 7, 100);
    if (ret != ESP_OK) return ret;

    t->tm_sec  = bcd_to_dec(data[0] & 0x7F);
    t->tm_min  = bcd_to_dec(data[1] & 0x7F);
    t->tm_hour = bcd_to_dec(data[2] & 0x3F);
    t->tm_wday = bcd_to_dec(data[3] & 0x07) - 1;
    t->tm_mday = bcd_to_dec(data[4] & 0x3F);
    t->tm_mon  = bcd_to_dec(data[5] & 0x1F) - 1;
    t->tm_year = bcd_to_dec(data[6]) + 100;

    return ESP_OK;
}

static esp_err_t rtc_set_time(const struct tm *t)
{
    if (!s_i2c_dev) return ESP_ERR_INVALID_STATE;

    uint8_t buf[8];
    buf[0] = 0x00;
    buf[1] = dec_to_bcd(t->tm_sec);
    buf[2] = dec_to_bcd(t->tm_min);
    buf[3] = dec_to_bcd(t->tm_hour);
    buf[4] = dec_to_bcd(t->tm_wday + 1);
    buf[5] = dec_to_bcd(t->tm_mday);
    buf[6] = dec_to_bcd(t->tm_mon + 1);
    buf[7] = dec_to_bcd(t->tm_year - 100);

    esp_err_t ret = ESP_FAIL;
    for (int attempt = 0; attempt <= RTC_WRITE_RETRIES; attempt++) {
        ret = i2c_master_transmit(s_i2c_dev, buf, 8, 100);
        if (ret == ESP_OK) return ESP_OK;

        if (attempt < RTC_WRITE_RETRIES) {
            ESP_LOGW(TAG, "RTC write attempt %d failed: %s, retrying",
                     attempt + 1, esp_err_to_name(ret));
            vTaskDelay(pdMS_TO_TICKS(RTC_RETRY_DELAY_MS));
        }
    }

    ESP_LOGE(TAG, "RTC write failed after %d retries: %s",
             RTC_WRITE_RETRIES, esp_err_to_name(ret));
    return ret;
}

/* ====================================================================== */
/*  Sync helpers                                                          */
/* ====================================================================== */

static void sync_from_rtc(void)
{
    struct tm t = {0};
    if (rtc_get_time(&t) == ESP_OK) {
        time_t epoch = utc_mktime(&t);
        if (epoch > 1700000000) { /* sanity: after ~2023 */
            struct timeval tv = { .tv_sec = epoch, .tv_usec = 0 };
            settimeofday(&tv, NULL);
            s_clock_seeded = true;
            ESP_LOGI(TAG, "System clock set from RTC: %lld", (long long)epoch);
        }
    }
}

static void sntp_sync_cb(struct timeval *tv)
{
    ESP_LOGI(TAG, "SNTP synced: %lld", (long long)tv->tv_sec);
    s_clock_seeded = true;

    if (!s_rtc_ok) return;

    struct tm t;
    gmtime_r(&tv->tv_sec, &t);

    if (rtc_set_time(&t) != ESP_OK) {
        ESP_LOGW(TAG, "RTC update failed, will retry next SNTP sync");
        return;
    }

    ESP_LOGI(TAG, "RTC updated from SNTP");

    /* Verify RTC write succeeded by reading back */
    struct tm rtc_tm = {0};
    if (rtc_get_time(&rtc_tm) == ESP_OK) {
        time_t rtc_epoch = utc_mktime(&rtc_tm);
        int drift = abs((int)(tv->tv_sec - rtc_epoch));
        if (drift > RTC_DRIFT_THRESH_S) {
            ESP_LOGW(TAG, "RTC drift after write: %d seconds, retrying", drift);
            rtc_set_time(&t);
        }
    }
}

/* ====================================================================== */
/*  Public API                                                            */
/* ====================================================================== */

esp_err_t time_utils_init(const board_config_t *board)
{
    esp_err_t ret = rtc_init(board);
    s_rtc_ok = (ret == ESP_OK);

    if (s_rtc_ok) {
        sync_from_rtc();
    } else {
        ESP_LOGW(TAG, "RTC init failed — timestamps may be wrong");
    }

    return ESP_OK; /* non-fatal: SNTP can still work */
}

esp_err_t time_utils_start_sntp(void)
{
    if (esp_sntp_enabled()) return ESP_OK;

    esp_sntp_setoperatingmode(SNTP_OPMODE_POLL);
    esp_sntp_setservername(0, NTP_SERVER_1);
    esp_sntp_setservername(1, NTP_SERVER_2);
    esp_sntp_set_sync_interval(NTP_SYNC_INTERVAL * 1000);
    esp_sntp_set_time_sync_notification_cb(sntp_sync_cb);
    esp_sntp_init();

    ESP_LOGI(TAG, "SNTP started (%s, %s)", NTP_SERVER_1, NTP_SERVER_2);
    return ESP_OK;
}

time_t time_utils_now(void)
{
    static bool s_reseed_attempted = false;

    time_t now;
    time(&now);

    /* Emergency one-time re-seed: if system clock is still unset and we
       haven't successfully seeded yet, try the DS3231 once more to set
       the system clock.  After this, only SNTP can update time.
       s_reseed_attempted ensures we never retry more than once even if
       the DS3231 itself returns bad data (epoch < 1700000000). */
    if (now < 1700000000 && !s_clock_seeded && !s_reseed_attempted && s_rtc_ok) {
        s_reseed_attempted = true;
        ESP_LOGW(TAG, "System clock unset, emergency re-seed from DS3231");
        sync_from_rtc();
        time(&now);
    }

    return now;
}

esp_err_t time_utils_get_tm(struct tm *out)
{
    time_t now = time_utils_now();
    gmtime_r(&now, out);
    return ESP_OK;
}

bool time_utils_rtc_ok(void)
{
    return s_rtc_ok;
}

esp_err_t time_utils_rtc_temperature(float *out)
{
    if (!out) return ESP_ERR_INVALID_ARG;
    if (!s_i2c_dev) return ESP_ERR_INVALID_STATE;

    uint8_t reg = 0x11;
    uint8_t data[2];
    esp_err_t ret = i2c_master_transmit_receive(s_i2c_dev, &reg, 1, data, 2, 100);
    if (ret != ESP_OK) return ret;

    int8_t int_part = (int8_t)data[0];
    uint8_t frac_bits = (data[1] >> 6) & 0x03;
    *out = (float)int_part + (float)frac_bits * 0.25f;

    return ESP_OK;
}
