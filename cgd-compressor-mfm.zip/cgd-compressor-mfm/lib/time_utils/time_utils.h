#pragma once
#ifndef TIME_UTILS_H
#define TIME_UTILS_H

#include <stdbool.h>
#include <time.h>
#include "esp_err.h"
#include "board_config.h"

/**
 * Initialize RTC and sync system time from it.
 */
esp_err_t time_utils_init(const board_config_t *board);

/**
 * Start SNTP sync (call after WiFi is connected).
 * Periodically syncs system time and updates RTC.
 */
esp_err_t time_utils_start_sntp(void);

/**
 * Get current time as epoch seconds.
 * Falls back to RTC if system time looks unset.
 */
time_t time_utils_now(void);

/**
 * Get current time as struct tm.
 */
esp_err_t time_utils_get_tm(struct tm *out);

/**
 * Check if RTC initialized successfully.
 */
bool time_utils_rtc_ok(void);

/**
 * Read DS3231 on-chip temperature sensor.
 * Returns ESP_ERR_INVALID_STATE if RTC not initialized.
 */
esp_err_t time_utils_rtc_temperature(float *out);

#endif
