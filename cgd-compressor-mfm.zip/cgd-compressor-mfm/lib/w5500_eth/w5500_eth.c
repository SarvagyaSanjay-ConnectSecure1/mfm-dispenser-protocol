#include "w5500_eth.h"
#include "esp_eth.h"
#include "esp_eth_driver.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdatomic.h>

static const char *TAG = "w5500_eth";

#define W5500_SPI_FREQ  20000000

static _Atomic bool s_connected = false;
static esp_eth_handle_t s_eth_handle = NULL;
static esp_eth_netif_glue_handle_t s_glue_handle = NULL;

static void eth_event_handler(void *arg, esp_event_base_t base,
                              int32_t event_id, void *event_data)
{
    switch (event_id) {
    case ETHERNET_EVENT_CONNECTED:
        ESP_LOGI(TAG, "Ethernet link up");
        s_connected = true;
        break;
    case ETHERNET_EVENT_DISCONNECTED:
        ESP_LOGW(TAG, "Ethernet link down");
        s_connected = false;
        break;
    default:
        break;
    }
}

esp_err_t w5500_eth_init(const board_config_t *board,
                          esp_ip4_addr_t ip, esp_ip4_addr_t gw, esp_ip4_addr_t mask)
{
    if (!board) return ESP_ERR_INVALID_ARG;

    /* Reset W5500 if reset pin is available */
    if (board->w5500_rst >= 0) {
        gpio_config_t io_cfg = {
            .pin_bit_mask = (1ULL << board->w5500_rst),
            .mode = GPIO_MODE_OUTPUT,
        };
        gpio_config(&io_cfg);
        gpio_set_level(board->w5500_rst, 0);
        vTaskDelay(pdMS_TO_TICKS(100));
        gpio_set_level(board->w5500_rst, 1);
        vTaskDelay(pdMS_TO_TICKS(100));
    }

    /* SPI bus */
    spi_bus_config_t bus_cfg = {
        .mosi_io_num = board->w5500_mosi,
        .miso_io_num = board->w5500_miso,
        .sclk_io_num = board->w5500_sck,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 4096,
    };
    esp_err_t ret = spi_bus_initialize(board->w5500_spi_host, &bus_cfg, SPI_DMA_CH_AUTO);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "SPI bus init failed: %s", esp_err_to_name(ret));
        return ret;
    }

    /* SPI device for W5500 */
    spi_device_interface_config_t spi_devcfg = {
        .mode = 0,
        .clock_speed_hz = W5500_SPI_FREQ,
        .spics_io_num = board->w5500_cs,
        .queue_size = 20,
    };

    /* W5500 MAC + PHY */
    eth_w5500_config_t w5500_cfg = ETH_W5500_DEFAULT_CONFIG(board->w5500_spi_host, &spi_devcfg);

    eth_mac_config_t mac_cfg = ETH_MAC_DEFAULT_CONFIG();
    esp_eth_mac_t *mac = esp_eth_mac_new_w5500(&w5500_cfg, &mac_cfg);
    if (!mac) {
        ESP_LOGE(TAG, "Failed to create W5500 MAC");
        spi_bus_free(board->w5500_spi_host);
        return ESP_FAIL;
    }

    eth_phy_config_t phy_cfg = ETH_PHY_DEFAULT_CONFIG();
    phy_cfg.autonego_timeout_ms = 0; // W5500 doesn't support auto-negotiation
    phy_cfg.reset_gpio_num = -1;     // reset handled above
    esp_eth_phy_t *phy = esp_eth_phy_new_w5500(&phy_cfg);
    if (!phy) {
        ESP_LOGE(TAG, "Failed to create W5500 PHY");
        mac->del(mac);
        spi_bus_free(board->w5500_spi_host);
        return ESP_FAIL;
    }

    esp_eth_config_t eth_cfg = ETH_DEFAULT_CONFIG(mac, phy);
    ret = esp_eth_driver_install(&eth_cfg, &s_eth_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Ethernet driver install failed: %s", esp_err_to_name(ret));
        phy->del(phy);
        mac->del(mac);
        spi_bus_free(board->w5500_spi_host);
        return ret;
    }

    /* Set MAC address from Ethernet base MAC */
    uint8_t mac_addr[6];
    esp_read_mac(mac_addr, ESP_MAC_ETH);
    esp_eth_ioctl(s_eth_handle, ETH_CMD_S_MAC_ADDR, mac_addr);

    /* Create netif with static IP */
    esp_netif_inherent_config_t netif_base = ESP_NETIF_INHERENT_DEFAULT_ETH();
    esp_netif_config_t netif_cfg = {
        .base = &netif_base,
        .stack = ESP_NETIF_NETSTACK_DEFAULT_ETH,
    };
    esp_netif_t *eth_netif = esp_netif_new(&netif_cfg);
    if (!eth_netif) {
        ESP_LOGE(TAG, "Failed to create eth netif");
        esp_eth_driver_uninstall(s_eth_handle);
        s_eth_handle = NULL;
        spi_bus_free(board->w5500_spi_host);
        return ESP_FAIL;
    }

    s_glue_handle = esp_eth_new_netif_glue(s_eth_handle);
    esp_netif_attach(eth_netif, s_glue_handle);

    /* Stop DHCP client and set static IP */
    esp_netif_dhcpc_stop(eth_netif);
    esp_netif_ip_info_t ip_info = {
        .ip = ip,
        .gw = gw,
        .netmask = mask,
    };
    ret = esp_netif_set_ip_info(eth_netif, &ip_info);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Failed to set static IP: %s", esp_err_to_name(ret));
    }

    /* Register event handler */
    ret = esp_event_handler_register(ETH_EVENT, ESP_EVENT_ANY_ID, &eth_event_handler, NULL);
    if (ret != ESP_OK) {
        ESP_LOGW(TAG, "Failed to register eth event handler: %s", esp_err_to_name(ret));
    }

    /* Start Ethernet */
    ret = esp_eth_start(s_eth_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Ethernet start failed: %s", esp_err_to_name(ret));
        return ret;
    }

    ESP_LOGI(TAG, "W5500 Ethernet started (IP: " IPSTR ")", IP2STR(&ip));
    return ESP_OK;
}

bool w5500_eth_is_connected(void)
{
    return s_connected;
}
