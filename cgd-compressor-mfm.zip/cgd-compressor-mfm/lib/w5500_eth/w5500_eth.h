#pragma once
#ifndef __W5500_ETH_H__
#define __W5500_ETH_H__

#include <stdbool.h>
#include "esp_err.h"
#include "esp_netif.h"
#include "board_config.h"

esp_err_t w5500_eth_init(const board_config_t *board,
                          esp_ip4_addr_t ip, esp_ip4_addr_t gw, esp_ip4_addr_t mask);
bool w5500_eth_is_connected(void);

#endif
