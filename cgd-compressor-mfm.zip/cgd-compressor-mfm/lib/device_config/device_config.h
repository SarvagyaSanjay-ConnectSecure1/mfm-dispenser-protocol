#pragma once
#ifndef __DEVICE_CONFIG_H__
#define __DEVICE_CONFIG_H__

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
#include "esp_netif.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "board_config.h"

typedef struct {
    uint8_t  func_code;   // FC01/02/03/04
    uint16_t offset;      // zero-based Modbus offset
    uint16_t length;      // register/coil count
    uint16_t raw_addr;    // original datasheet address
} reg_entry_t;

typedef struct {
    bool          is_rtu;
    char          ro_code[32];
    int           c_id;
    uint8_t       slave_addr;
    uint32_t      baud;
    uint8_t       data_bits;     // 7 or 8
    uint8_t       parity;        // 'N', 'E', 'O'
    uint8_t       stop_bits;     // 1 or 2
    esp_ip4_addr_t server_ip;
    uint16_t      server_port;
    uint32_t      post_interval;    // seconds
    uint32_t      status_interval;  // online status interval (seconds)
    esp_ip4_addr_t eth_ip;
    esp_ip4_addr_t eth_gw;
    esp_ip4_addr_t eth_mask;
    reg_entry_t   *regs;         // dynamically allocated
    int           reg_count;     // number of register entries

    // Device identity
    char          c_make[32];         // Compressor make/model

    // OTA
    char          next_ota_ver[16];   // Target OTA version
    char          main_url[256];      // Firmware binary URL
    char          checksum_url[256];  // MD5 checksum JSON URL
} device_config_t;

typedef struct {
    char ssid[64];
    char password[64];
} wifi_creds_t;

typedef struct {
    char hostname[128];
    char device_id[128];
    char shared_access_key[128];
} mqtt_config_t;

/* Load config: SD -> LittleFS */
esp_err_t device_config_load(void);

/* Get current config (NULL if not loaded) */
const device_config_t *device_config_get(void);

/* Parse JSON and save to both SD and LittleFS (thread-safe) */
esp_err_t device_config_apply_json(const char *json);

/* Thread-safe config access: lock before reading regs, unlock after */
void device_config_lock(void);
void device_config_unlock(void);

/* Register a task to be notified (via xTaskNotify) when Modbus config changes */
void device_config_set_modbus_notify_task(TaskHandle_t task);

/* Load WiFi creds: SD -> NVS(my-app) -> LittleFS -> board defaults */
esp_err_t wifi_creds_load(wifi_creds_t *out, const board_config_t *board);

/* Save WiFi creds to all three stores */
esp_err_t wifi_creds_save(const wifi_creds_t *creds);

/* Load MQTT config (hostname, DeviceId, SharedAccessKey): SD -> LittleFS */
esp_err_t mqtt_config_load(mqtt_config_t *out);

#endif
