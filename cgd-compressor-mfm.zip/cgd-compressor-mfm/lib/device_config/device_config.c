#include "device_config.h"
#include "storage.h"
#include "project_config.h"
#include "cJSON.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "dev_cfg";

static device_config_t s_config;
static bool s_loaded = false;
static SemaphoreHandle_t s_mutex = NULL;
static _Atomic TaskHandle_t s_modbus_notify_task = NULL;
static uint32_t s_modbus_fp = 0;

/* ── address resolution ────────────────────────────────────────────────── */

static void resolve_address(uint16_t raw, reg_entry_t *e)
{
    e->raw_addr = raw;
    if (raw >= 40001 && raw <= 49999) {
        e->func_code = 3;
        e->offset = raw - 40001;
    } else if (raw >= 30001 && raw <= 39999) {
        e->func_code = 4;
        e->offset = raw - 30001;
    } else if (raw >= 10001 && raw <= 19999) {
        e->func_code = 2;
        e->offset = raw - 10001;
    } else if (raw >= 1 && raw <= 9999) {
        e->func_code = 1;
        e->offset = raw - 1;
    } else {
        ESP_LOGW(TAG, "Unknown address %u, defaulting to FC03", raw);
        e->func_code = 3;
        e->offset = raw;
    }
}

/* ── Parse regs array: [addr, len, addr, len, ...] ─────────────────────── */

static void parse_regs_array(cJSON *arr)
{
    if (s_config.regs) {
        free(s_config.regs);
        s_config.regs = NULL;
        s_config.reg_count = 0;
    }

    if (!arr || !cJSON_IsArray(arr)) return;

    int arr_sz = cJSON_GetArraySize(arr);
    int pair_count = arr_sz / 2;
    if (pair_count <= 0) return;

    s_config.regs = malloc(pair_count * sizeof(reg_entry_t));
    if (!s_config.regs) return;

    s_config.reg_count = pair_count;
    for (int i = 0; i < pair_count; i++) {
        cJSON *addr_item = cJSON_GetArrayItem(arr, i * 2);
        cJSON *len_item  = cJSON_GetArrayItem(arr, i * 2 + 1);
        if (!addr_item || !len_item ||
            !cJSON_IsNumber(addr_item) || !cJSON_IsNumber(len_item)) {
            ESP_LOGW(TAG, "Invalid reg entry at index %d", i);
            s_config.reg_count = i;
            break;
        }
        uint16_t addr = (uint16_t)addr_item->valueint;
        uint16_t len  = (uint16_t)len_item->valueint;
        resolve_address(addr, &s_config.regs[i]);
        s_config.regs[i].length = len;
    }
}

/* ── JSON parsing ──────────────────────────────────────────────────────── */

static esp_err_t parse_config_json(const char *json)
{
    cJSON *root = cJSON_Parse(json);
    if (!root) {
        ESP_LOGE(TAG, "JSON parse error");
        return ESP_FAIL;
    }

    if (s_config.regs) {
        free(s_config.regs);
        s_config.regs = NULL;
        s_config.reg_count = 0;
    }

    cJSON *item;

    /* ── Determine RTU vs TCP from mbus_RTU / mbus_TCP objects ────────── */
    cJSON *mbus_rtu = cJSON_GetObjectItem(root, "mbus_RTU");
    cJSON *mbus_tcp = cJSON_GetObjectItem(root, "mbus_TCP");

    if (mbus_rtu && cJSON_IsObject(mbus_rtu)) {
        s_config.is_rtu = true;

        item = cJSON_GetObjectItem(mbus_rtu, "slave");
        s_config.slave_addr = item ? (uint8_t)item->valueint : MODBUS_DEFAULT_SLAVE_ID;

        item = cJSON_GetObjectItem(mbus_rtu, "baud");
        s_config.baud = item ? (uint32_t)item->valueint : RS485_BAUD;

        item = cJSON_GetObjectItem(mbus_rtu, "dataBits");
        s_config.data_bits = item ? (uint8_t)item->valueint : 8;

        item = cJSON_GetObjectItem(mbus_rtu, "parity");
        if (item && cJSON_IsString(item) && item->valuestring[0])
            s_config.parity = (uint8_t)item->valuestring[0];
        else
            s_config.parity = 'N';

        item = cJSON_GetObjectItem(mbus_rtu, "stopBits");
        s_config.stop_bits = item ? (uint8_t)item->valueint : 1;

    } else if (mbus_tcp && cJSON_IsObject(mbus_tcp)) {
        s_config.is_rtu = false;

        item = cJSON_GetObjectItem(mbus_tcp, "slave");
        s_config.slave_addr = item ? (uint8_t)item->valueint : MODBUS_DEFAULT_SLAVE_ID;

        item = cJSON_GetObjectItem(mbus_tcp, "target_ip");
        if (item && cJSON_IsString(item))
            esp_netif_str_to_ip4(item->valuestring, &s_config.server_ip);
        else
            s_config.server_ip.addr = 0;

        item = cJSON_GetObjectItem(mbus_tcp, "target_port");
        s_config.server_port = item ? (uint16_t)item->valueint : 502;

        item = cJSON_GetObjectItem(mbus_tcp, "local_ip");
        if (item && cJSON_IsString(item))
            esp_netif_str_to_ip4(item->valuestring, &s_config.eth_ip);
        else
            esp_netif_str_to_ip4(ETH_DEFAULT_IP, &s_config.eth_ip);

        item = cJSON_GetObjectItem(mbus_tcp, "gateway");
        if (item && cJSON_IsString(item))
            esp_netif_str_to_ip4(item->valuestring, &s_config.eth_gw);
        else
            esp_netif_str_to_ip4(ETH_DEFAULT_GATEWAY, &s_config.eth_gw);

        item = cJSON_GetObjectItem(mbus_tcp, "netmask");
        if (item && cJSON_IsString(item))
            esp_netif_str_to_ip4(item->valuestring, &s_config.eth_mask);
        else
            esp_netif_str_to_ip4(ETH_DEFAULT_SUBNET, &s_config.eth_mask);

    } else {
        /* Neither present — default to RTU */
        ESP_LOGW(TAG, "No mbus_RTU or mbus_TCP in config, defaulting to RTU");
        s_config.is_rtu = true;
        s_config.slave_addr = MODBUS_DEFAULT_SLAVE_ID;
        s_config.baud = RS485_BAUD;
        s_config.data_bits = 8;
        s_config.parity = 'N';
        s_config.stop_bits = 1;
    }

    /* ── Flat keys ────────────────────────────────────────────────────── */

    item = cJSON_GetObjectItem(root, "ro_code");
    if (item && cJSON_IsString(item)) {
        strncpy(s_config.ro_code, item->valuestring, sizeof(s_config.ro_code) - 1);
        s_config.ro_code[sizeof(s_config.ro_code) - 1] = '\0';
    } else {
        s_config.ro_code[0] = '\0';
    }

    item = cJSON_GetObjectItem(root, "c_id");
    s_config.c_id = item ? item->valueint : 0;

    item = cJSON_GetObjectItem(root, "c_make");
    if (item && cJSON_IsString(item)) {
        strncpy(s_config.c_make, item->valuestring, sizeof(s_config.c_make) - 1);
        s_config.c_make[sizeof(s_config.c_make) - 1] = '\0';
    } else {
        s_config.c_make[0] = '\0';
    }

    item = cJSON_GetObjectItem(root, "post_interval");
    s_config.post_interval = item ? (uint32_t)item->valueint : DEFAULT_POST_INTERVAL;

    item = cJSON_GetObjectItem(root, "status_interval");
    s_config.status_interval = item ? (uint32_t)item->valueint : DEFAULT_STATUS_INTERVAL;

    /* ── OTA object ───────────────────────────────────────────────────── */

    cJSON *ota = cJSON_GetObjectItem(root, "ota");
    if (ota && cJSON_IsObject(ota)) {
        item = cJSON_GetObjectItem(ota, "ver");
        if (item && cJSON_IsString(item)) {
            strncpy(s_config.next_ota_ver, item->valuestring, sizeof(s_config.next_ota_ver) - 1);
            s_config.next_ota_ver[sizeof(s_config.next_ota_ver) - 1] = '\0';
        } else {
            s_config.next_ota_ver[0] = '\0';
        }

        item = cJSON_GetObjectItem(ota, "bin_url");
        if (item && cJSON_IsString(item)) {
            strncpy(s_config.main_url, item->valuestring, sizeof(s_config.main_url) - 1);
            s_config.main_url[sizeof(s_config.main_url) - 1] = '\0';
        } else {
            s_config.main_url[0] = '\0';
        }

        item = cJSON_GetObjectItem(ota, "checksum_url");
        if (item && cJSON_IsString(item)) {
            strncpy(s_config.checksum_url, item->valuestring, sizeof(s_config.checksum_url) - 1);
            s_config.checksum_url[sizeof(s_config.checksum_url) - 1] = '\0';
        } else {
            s_config.checksum_url[0] = '\0';
        }
    } else {
        s_config.next_ota_ver[0] = '\0';
        s_config.main_url[0] = '\0';
        s_config.checksum_url[0] = '\0';
    }

    /* ── Regs array: "m" key ──────────────────────────────────────────── */

    parse_regs_array(cJSON_GetObjectItem(root, "m"));

    cJSON_Delete(root);

    ESP_LOGI(TAG, "Config parsed: %s slave=%d regs=%d interval=%lus ro=%s c_id=%d",
             s_config.is_rtu ? "RTU" : "TCP",
             s_config.slave_addr, s_config.reg_count,
             s_config.post_interval, s_config.ro_code, s_config.c_id);

    s_loaded = true;
    return ESP_OK;
}

/* ── WiFi creds parsing ────────────────────────────────────────────────── */

static esp_err_t parse_wifi_json(const char *json, wifi_creds_t *out)
{
    cJSON *root = cJSON_Parse(json);
    if (!root) return ESP_FAIL;

    cJSON *ssid = cJSON_GetObjectItem(root, "ssid");
    cJSON *pass = cJSON_GetObjectItem(root, "password");

    if (!ssid || !cJSON_IsString(ssid) || !ssid->valuestring[0]) {
        cJSON_Delete(root);
        return ESP_FAIL;
    }

    strncpy(out->ssid, ssid->valuestring, sizeof(out->ssid) - 1);
    out->ssid[sizeof(out->ssid) - 1] = '\0';

    if (pass && cJSON_IsString(pass))
        strncpy(out->password, pass->valuestring, sizeof(out->password) - 1);
    else
        out->password[0] = '\0';
    out->password[sizeof(out->password) - 1] = '\0';

    cJSON_Delete(root);
    return ESP_OK;
}

/* ── Modbus config fingerprint (zero-allocation change detection) ──────── */

static uint32_t modbus_fingerprint(const device_config_t *cfg)
{
    uint32_t h = 0x811c9dc5; /* FNV-1a offset basis */
    #define MIX(val) do { h ^= (uint32_t)(val); h *= 0x01000193; } while (0)

    MIX(cfg->is_rtu);
    MIX(cfg->slave_addr);
    MIX(cfg->reg_count);
    MIX(cfg->post_interval);

    if (cfg->is_rtu) {
        MIX(cfg->baud);
        MIX(cfg->data_bits);
        MIX(cfg->parity);
        MIX(cfg->stop_bits);
    } else {
        MIX(cfg->server_ip.addr);
        MIX(cfg->server_port);
        MIX(cfg->eth_ip.addr);
        MIX(cfg->eth_gw.addr);
        MIX(cfg->eth_mask.addr);
    }

    for (int i = 0; i < cfg->reg_count && cfg->regs; i++) {
        MIX(cfg->regs[i].raw_addr);
        MIX(cfg->regs[i].length);
    }

    #undef MIX
    return h;
}

/* ── Public API ────────────────────────────────────────────────────────── */

esp_err_t device_config_load(void)
{
    if (!s_mutex) {
        s_mutex = xSemaphoreCreateMutex();
        if (!s_mutex) return ESP_ERR_NO_MEM;
    }

    char *json = NULL;

    json = storage_read_file(CONFIG_PATH_SD);
    if (json) {
        ESP_LOGI(TAG, "Config loaded from SD");
        xSemaphoreTake(s_mutex, portMAX_DELAY);
        esp_err_t ret = parse_config_json(json);
        if (ret == ESP_OK)
            s_modbus_fp = modbus_fingerprint(&s_config);
        xSemaphoreGive(s_mutex);
        if (ret == ESP_OK)
            storage_write_file(CONFIG_PATH_LFS, json);
        free(json);
        return ret;
    }

    json = storage_read_file(CONFIG_PATH_LFS);
    if (json) {
        ESP_LOGI(TAG, "Config loaded from LittleFS");
        xSemaphoreTake(s_mutex, portMAX_DELAY);
        esp_err_t ret = parse_config_json(json);
        if (ret == ESP_OK)
            s_modbus_fp = modbus_fingerprint(&s_config);
        xSemaphoreGive(s_mutex);
        free(json);
        return ret;
    }

    ESP_LOGW(TAG, "No config found on SD or LittleFS");
    return ESP_ERR_NOT_FOUND;
}

const device_config_t *device_config_get(void)
{
    return s_loaded ? &s_config : NULL;
}

esp_err_t device_config_apply_json(const char *json)
{
    if (!json) return ESP_ERR_INVALID_ARG;
    if (!s_mutex) return ESP_ERR_INVALID_STATE;

    xSemaphoreTake(s_mutex, portMAX_DELAY);

    esp_err_t ret = parse_config_json(json);

    /* Compare new fingerprint with stored — only notify on real change */
    bool changed = false;
    if (ret == ESP_OK) {
        uint32_t new_fp = modbus_fingerprint(&s_config);
        changed = (s_modbus_fp != new_fp);
        s_modbus_fp = new_fp;
    }

    xSemaphoreGive(s_mutex);

    if (ret != ESP_OK) return ret;

    storage_write_file(CONFIG_PATH_SD, json);
    storage_write_file(CONFIG_PATH_LFS, json);

    if (changed && s_modbus_notify_task) {
        ESP_LOGI(TAG, "Modbus config changed, notifying poller");
        xTaskNotify(s_modbus_notify_task, 0, eSetValueWithOverwrite);
    }

    return ESP_OK;
}

void device_config_lock(void)
{
    if (s_mutex) xSemaphoreTake(s_mutex, portMAX_DELAY);
}

void device_config_unlock(void)
{
    if (s_mutex) xSemaphoreGive(s_mutex);
}

void device_config_set_modbus_notify_task(TaskHandle_t task)
{
    s_modbus_notify_task = task;
}

esp_err_t wifi_creds_load(wifi_creds_t *out, const board_config_t *board)
{
    if (!out) return ESP_ERR_INVALID_ARG;
    memset(out, 0, sizeof(*out));

    char *json = storage_read_file(WIFI_PATH_SD);
    if (json) {
        esp_err_t ret = parse_wifi_json(json, out);
        free(json);
        if (ret == ESP_OK) {
            ESP_LOGI(TAG, "WiFi creds loaded from SD");
            return ESP_OK;
        }
    }

    nvs_handle_t nvs;
    if (nvs_open(NVS_NAMESPACE, NVS_READONLY, &nvs) == ESP_OK) {
        size_t ssid_len = sizeof(out->ssid);
        size_t pass_len = sizeof(out->password);
        esp_err_t r1 = nvs_get_str(nvs, NVS_KEY_WIFI_SSID, out->ssid, &ssid_len);
        esp_err_t r2 = nvs_get_str(nvs, NVS_KEY_WIFI_PASS, out->password, &pass_len);
        nvs_close(nvs);
        if (r1 == ESP_OK && out->ssid[0]) {
            if (r2 != ESP_OK) out->password[0] = '\0';
            ESP_LOGI(TAG, "WiFi creds loaded from NVS");
            return ESP_OK;
        }
    }

    json = storage_read_file(WIFI_PATH_LFS);
    if (json) {
        esp_err_t ret = parse_wifi_json(json, out);
        free(json);
        if (ret == ESP_OK) {
            ESP_LOGI(TAG, "WiFi creds loaded from LittleFS");
            return ESP_OK;
        }
    }

    if (board && board->default_wifi_ssid && board->default_wifi_ssid[0]) {
        strncpy(out->ssid, board->default_wifi_ssid, sizeof(out->ssid) - 1);
        if (board->default_wifi_pass)
            strncpy(out->password, board->default_wifi_pass, sizeof(out->password) - 1);
        ESP_LOGI(TAG, "WiFi creds using board defaults ('%s')", out->ssid);
        return ESP_OK;
    }

    ESP_LOGW(TAG, "No WiFi credentials found");
    return ESP_ERR_NOT_FOUND;
}

esp_err_t wifi_creds_save(const wifi_creds_t *creds)
{
    if (!creds || !creds->ssid[0]) return ESP_ERR_INVALID_ARG;

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "ssid", creds->ssid);
    cJSON_AddStringToObject(root, "password", creds->password);
    char *json = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (!json) return ESP_ERR_NO_MEM;

    storage_write_file(WIFI_PATH_SD, json);
    storage_write_file(WIFI_PATH_LFS, json);
    free(json);

    nvs_handle_t nvs;
    esp_err_t ret = nvs_open(NVS_NAMESPACE, NVS_READWRITE, &nvs);
    if (ret == ESP_OK) {
        nvs_set_str(nvs, NVS_KEY_WIFI_SSID, creds->ssid);
        nvs_set_str(nvs, NVS_KEY_WIFI_PASS, creds->password);
        nvs_commit(nvs);
        nvs_close(nvs);
    }

    ESP_LOGI(TAG, "WiFi creds saved to all stores");
    return ESP_OK;
}

/* ── MQTT config ───────────────────────────────────────────────────────── */

esp_err_t mqtt_config_load(mqtt_config_t *out)
{
    if (!out) return ESP_ERR_INVALID_ARG;
    memset(out, 0, sizeof(*out));

    const char *paths[] = { MQTT_CONFIG_PATH_SD, MQTT_CONFIG_PATH_LFS };

    for (int i = 0; i < 2; i++) {
        char *json = storage_read_file(paths[i]);
        if (!json) continue;

        cJSON *root = cJSON_Parse(json);
        free(json);
        if (!root) continue;

        cJSON *h = cJSON_GetObjectItem(root, "hostname");
        cJSON *d = cJSON_GetObjectItem(root, "DeviceId");
        cJSON *k = cJSON_GetObjectItem(root, "SharedAccessKey");

        if (h && d && k && cJSON_IsString(h) && cJSON_IsString(d) && cJSON_IsString(k)) {
            strncpy(out->hostname, h->valuestring, sizeof(out->hostname) - 1);
            strncpy(out->device_id, d->valuestring, sizeof(out->device_id) - 1);
            strncpy(out->shared_access_key, k->valuestring, sizeof(out->shared_access_key) - 1);
            cJSON_Delete(root);

            ESP_LOGI(TAG, "MQTT config loaded from %s (host=%s dev=%s)",
                     paths[i], out->hostname, out->device_id);
            return ESP_OK;
        }
        cJSON_Delete(root);
    }

    ESP_LOGE(TAG, "mqtt_config.json not found on SD or LittleFS");
    return ESP_ERR_NOT_FOUND;
}
