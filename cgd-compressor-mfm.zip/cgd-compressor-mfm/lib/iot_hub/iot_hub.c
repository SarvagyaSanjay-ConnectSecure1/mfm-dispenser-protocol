#include "iot_hub.h"
#include "device_config.h"
#include "board_config.h"
#include "storage.h"
#include "time_utils.h"
#include "ota_update.h"
#include "project_config.h"
#include "esp_crt_bundle.h"
#include "esp_log.h"
#include "mqtt_client.h"
#include "cJSON.h"
#include "mbedtls/base64.h"
#include "mbedtls/md.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_wifi.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "esp_system.h"
#include <stdatomic.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static const char *TAG = "iot_hub";

/* ── MQTT config ───────────────────────────────────────────────────────── */

static mqtt_config_t s_mqtt_cfg;
static char s_sas_token[768] = {0};
static char s_username[320] = {0};
static char s_uri[256] = {0};
static esp_mqtt_client_handle_t s_mqtt_client = NULL;
static _Atomic bool s_connected = false;
static _Atomic int s_rid = 0;
static _Atomic bool s_initialized = false;

/* Streaming reassembly */
static char *s_reassembly_buf = NULL;
static int   s_reassembly_len = 0;
static int   s_reassembly_total = 0;
static char *s_reassembly_topic = NULL; /* cached topic for multipart */

/* ── URL encoding ──────────────────────────────────────────────────────── */

static void url_encode(const char *src, char *dst, size_t dst_sz)
{
    if (dst_sz == 0) return;
    size_t pos = 0;
    for (const char *p = src; *p && pos + 3 < dst_sz; p++) {
        if ((*p >= 'A' && *p <= 'Z') || (*p >= 'a' && *p <= 'z') ||
            (*p >= '0' && *p <= '9') || *p == '-' || *p == '_' || *p == '.' || *p == '~') {
            dst[pos++] = *p;
        } else {
            int written = snprintf(dst + pos, dst_sz - pos, "%%%02X", (unsigned char)*p);
            if (written < 0 || (size_t)written >= dst_sz - pos) break;
            pos += (size_t)written;
        }
    }
    dst[pos] = '\0';
}

/* ── SAS token generation ──────────────────────────────────────────────── */

static esp_err_t generate_sas_token(void)
{
    char resource[384];
    snprintf(resource, sizeof(resource), "%s/devices/%s",
             s_mqtt_cfg.hostname, s_mqtt_cfg.device_id);

    char encoded_resource[512];
    url_encode(resource, encoded_resource, sizeof(encoded_resource));

    time_t now = time_utils_now();
    time_t expiry = now + MQTT_SAS_TOKEN_EXPIRY_SECS;

    char to_sign[600];
    snprintf(to_sign, sizeof(to_sign), "%s\n%lld", encoded_resource, (long long)expiry);

    unsigned char decoded_key[64];
    size_t decoded_key_len = 0;
    int ret = mbedtls_base64_decode(decoded_key, sizeof(decoded_key), &decoded_key_len,
                                     (const unsigned char *)s_mqtt_cfg.shared_access_key,
                                     strlen(s_mqtt_cfg.shared_access_key));
    if (ret != 0) {
        ESP_LOGE(TAG, "base64 decode of SharedAccessKey failed: %d", ret);
        return ESP_FAIL;
    }

    unsigned char hmac[32];
    ret = mbedtls_md_hmac(mbedtls_md_info_from_type(MBEDTLS_MD_SHA256),
                          decoded_key, decoded_key_len,
                          (const unsigned char *)to_sign, strlen(to_sign),
                          hmac);
    if (ret != 0) {
        ESP_LOGE(TAG, "HMAC-SHA256 failed: %d", ret);
        return ESP_FAIL;
    }

    char b64_sig[64];
    size_t b64_len = 0;
    mbedtls_base64_encode((unsigned char *)b64_sig, sizeof(b64_sig), &b64_len, hmac, 32);
    b64_sig[b64_len] = '\0';

    char encoded_sig[128];
    url_encode(b64_sig, encoded_sig, sizeof(encoded_sig));

    snprintf(s_sas_token, sizeof(s_sas_token),
             "SharedAccessSignature sr=%s&sig=%s&se=%lld",
             encoded_resource, encoded_sig, (long long)expiry);

    ESP_LOGI(TAG, "SAS token generated (expiry=%lld)", (long long)expiry);
    return ESP_OK;
}

static esp_mqtt_client_config_t build_mqtt_config(void)
{
    return (esp_mqtt_client_config_t){
        .broker.address.uri = s_uri,
        .broker.verification.crt_bundle_attach = esp_crt_bundle_attach,
        .credentials.client_id = s_mqtt_cfg.device_id,
        .credentials.username = s_username,
        .credentials.authentication.password = s_sas_token,
        .session.keepalive = MQTT_KEEPALIVE_SECS,
        .network.timeout_ms = 10000,
        .task.stack_size = MQTT_TASK_STACK_SIZE,
        .buffer.size = MQTT_BUFFER_IN_SIZE,
        .buffer.out_size = MQTT_BUFFER_OUT_SIZE,
    };
}

/* ── SAS renewal task ──────────────────────────────────────────────────── */

static void sas_renewal_task(void *arg)
{
    const uint32_t normal_wait_secs = MQTT_SAS_TOKEN_EXPIRY_SECS - MQTT_SAS_RENEW_BEFORE_SECS;
    const uint32_t retry_wait_secs = 30;

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(normal_wait_secs * 1000));

        for (int attempt = 0; attempt < 5; attempt++) {
            ESP_LOGI(TAG, "Renewing SAS token (attempt %d)...", attempt + 1);
            if (generate_sas_token() == ESP_OK && s_mqtt_client) {
                esp_mqtt_client_stop(s_mqtt_client);
                vTaskDelay(pdMS_TO_TICKS(MQTT_RECONNECT_WAIT_SECS * 1000));

                esp_mqtt_client_config_t cfg = build_mqtt_config();
                esp_mqtt_set_config(s_mqtt_client, &cfg);
                esp_mqtt_client_start(s_mqtt_client);
                ESP_LOGI(TAG, "MQTT reconnecting with new SAS token");
                break;
            }
            ESP_LOGW(TAG, "SAS renewal failed, retrying in %lus", (unsigned long)retry_wait_secs);
            vTaskDelay(pdMS_TO_TICKS(retry_wait_secs * 1000));
        }
    }
}

/* ── Strip $-prefixed keys from JSON ───────────────────────────────────── */

static void strip_dollar_keys(cJSON *obj)
{
    cJSON *child = obj->child;
    while (child) {
        cJSON *next = child->next;
        if (child->string && child->string[0] == '$') {
            cJSON_DeleteItemFromObject(obj, child->string);
        } else if (cJSON_IsObject(child)) {
            strip_dollar_keys(child);
        }
        child = next;
    }
}

/* ── Process desired properties ────────────────────────────────────────── */

static void process_desired_properties(const char *json, int len)
{
    char *buf = malloc(len + 1);
    if (!buf) return;
    memcpy(buf, json, len);
    buf[len] = '\0';

    /* Strip $-prefixed keys (Azure metadata) before processing */
    cJSON *root = cJSON_Parse(buf);
    if (root) {
        strip_dollar_keys(root);
        free(buf);
        buf = cJSON_PrintUnformatted(root);
        cJSON_Delete(root);
        if (!buf) return;
    }

    /* Apply config (handles both scalar config and regs/m array) */
    device_config_apply_json(buf);
    free(buf);

    /* Check OTA — snapshot fields under lock */
    device_config_lock();
    const device_config_t *cfg = device_config_get();
    if (cfg) {
        ota_start(cfg->main_url, cfg->checksum_url,
                  cfg->next_ota_ver);
    }
    device_config_unlock();

    ESP_LOGI(TAG, "Desired properties applied");
}

/* ── Handle twin GET response ─────────────────────────────────────────── */

static void handle_twin_get_response(const char *data, int data_len)
{
    char *buf = malloc(data_len + 1);
    if (!buf) return;
    memcpy(buf, data, data_len);
    buf[data_len] = '\0';

    cJSON *root = cJSON_Parse(buf);
    free(buf);
    if (!root) {
        ESP_LOGW(TAG, "Twin GET response parse failed");
        return;
    }

    cJSON *desired = cJSON_GetObjectItem(root, "desired");
    if (desired) {
        char *desired_str = cJSON_PrintUnformatted(desired);
        if (desired_str) {
            process_desired_properties(desired_str, strlen(desired_str));
            free(desired_str);
        }
    }
    cJSON_Delete(root);
}


/* ── Reassembly helpers ───────────────────────────────────────────────── */

static void reassembly_reset(void)
{
    free(s_reassembly_buf);
    s_reassembly_buf = NULL;
    s_reassembly_len = 0;
    s_reassembly_total = 0;
    free(s_reassembly_topic);
    s_reassembly_topic = NULL;
}

static char *reassembly_accumulate(const char *data, int data_len,
                                    int current_offset, int total_len)
{
    if (current_offset == 0) {
        reassembly_reset();
        s_reassembly_buf = malloc(total_len + 1);
        if (!s_reassembly_buf) return NULL;
        s_reassembly_total = total_len;
    }

    if (!s_reassembly_buf || current_offset + data_len > s_reassembly_total)
        return NULL;

    memcpy(s_reassembly_buf + current_offset, data, data_len);
    s_reassembly_len = current_offset + data_len;

    if (s_reassembly_len >= s_reassembly_total) {
        s_reassembly_buf[s_reassembly_total] = '\0';
        return s_reassembly_buf;
    }

    return NULL;
}

/* ── Direct method handling ────────────────────────────────────────────── */

static const char *TAG_DM = "dm";

static void publish_method_response(int status, int rid, const char *response)
{
    char topic[128];
    snprintf(topic, sizeof(topic), "$iothub/methods/res/%d/?$rid=%d", status, rid);
    esp_mqtt_client_publish(s_mqtt_client, topic, response, 0, 1, 0);
}

static uint32_t get_uptime_s(void)
{
    return (uint32_t)(esp_timer_get_time() / 1000000);
}

static void handle_direct_method(const char *name, const char *payload,
                                  int payload_len, int rid)
{
    char response[768];
    int status = 200;

    /* ── reboot ────────────────────────────────────────────────────────── */
    if (strcmp(name, "reboot") == 0) {
        snprintf(response, sizeof(response), "{\"status\":\"rebooting\"}");
        publish_method_response(200, rid, response);
        ESP_LOGW(TAG_DM, "Reboot requested via direct method");
        vTaskDelay(pdMS_TO_TICKS(300));
        esp_restart();

    /* ── status ────────────────────────────────────────────────────────── */
    } else if (strcmp(name, "status") == 0) {
        device_config_lock();
        const device_config_t *cfg = device_config_get();
        int reg_count = cfg ? cfg->reg_count : 0;
        char ro_code[32] = "";
        if (cfg && cfg->ro_code[0]) strncpy(ro_code, cfg->ro_code, sizeof(ro_code) - 1);
        device_config_unlock();
        size_t heap_free = esp_get_free_heap_size();
        size_t heap_min  = esp_get_minimum_free_heap_size();
        size_t heap_lrgst = heap_caps_get_largest_free_block(MALLOC_CAP_DEFAULT);
        int rssi = 0;
        esp_wifi_sta_get_rssi(&rssi);
        snprintf(response, sizeof(response),
                 "{\"fw_version\":\"%s\",\"uptime_s\":%lu,\"connected\":%s,"
                 "\"reg_count\":%d,\"ro_code\":\"%s\","
                 "\"heap_free\":%zu,\"heap_min_ever\":%zu,\"heap_largest\":%zu,"
                 "\"rssi\":%d,\"SD_status\":%s}",
                 FW_VERSION, (unsigned long)get_uptime_s(),
                 s_connected ? "true" : "false",
                 reg_count, ro_code,
                 heap_free, heap_min, heap_lrgst,
                 rssi, storage_sd_is_mounted() ? "true" : "false");

    /* ── clear_filesystem ──────────────────────────────────────────────── */
    } else if (strcmp(name, "clear_filesystem") == 0) {
        int deleted = storage_clear_sd_configs();
        esp_err_t err = storage_clear_lfs();
        if (err == ESP_OK) {
            snprintf(response, sizeof(response),
                     "{\"status\":\"cleared\",\"sd_files_deleted\":%d}", deleted);
            ESP_LOGW(TAG_DM, "clear_filesystem: SD configs deleted, LFS formatted");
        } else {
            status = 500;
            snprintf(response, sizeof(response),
                     "{\"error\":\"lfs_format_failed\",\"esp_err\":\"%s\","
                     "\"sd_files_deleted\":%d}", esp_err_to_name(err), deleted);
        }

    /* ── clear_sd ──────────────────────────────────────────────────────── */
    } else if (strcmp(name, "clear_sd") == 0) {
        if (!storage_sd_is_mounted()) {
            status = 500;
            snprintf(response, sizeof(response), "{\"error\":\"sd_not_mounted\"}");
        } else {
            int deleted = storage_clear_sd_configs();
            snprintf(response, sizeof(response),
                     "{\"status\":\"ok\",\"files_deleted\":%d}", deleted);
            ESP_LOGI(TAG_DM, "clear_sd: deleted %d files", deleted);
        }

    /* ── clear_littlefs ────────────────────────────────────────────────── */
    } else if (strcmp(name, "clear_littlefs") == 0) {
        esp_err_t err = storage_clear_lfs();
        if (err == ESP_OK) {
            snprintf(response, sizeof(response), "{\"status\":\"lfs_cleared\"}");
            ESP_LOGW(TAG_DM, "clear_littlefs: LFS formatted");
        } else {
            status = 500;
            snprintf(response, sizeof(response),
                     "{\"error\":\"lfs_format_failed\",\"esp_err\":\"%s\"}",
                     esp_err_to_name(err));
        }

    /* ── rtc_health ────────────────────────────────────────────────────── */
    } else if (strcmp(name, "rtc_health") == 0) {
        if (!time_utils_rtc_ok()) {
            status = 500;
            snprintf(response, sizeof(response), "{\"error\":\"rtc_not_initialized\"}");
        } else {
            struct tm t;
            time_utils_get_tm(&t);
            float rtc_temp = 0.0f;
            bool temp_ok = (time_utils_rtc_temperature(&rtc_temp) == ESP_OK);
            char time_str[64];
            snprintf(time_str, sizeof(time_str), "%04d-%02d-%02dT%02d:%02d:%02dZ",
                     t.tm_year + 1900, t.tm_mon + 1, t.tm_mday,
                     t.tm_hour, t.tm_min, t.tm_sec);
            if (temp_ok) {
                snprintf(response, sizeof(response),
                         "{\"status\":\"ok\",\"rtc_time\":\"%s\","
                         "\"rtc_temp_c\":%.2f,\"epoch\":%lld}",
                         time_str, rtc_temp, (long long)time_utils_now());
            } else {
                snprintf(response, sizeof(response),
                         "{\"status\":\"ok\",\"rtc_time\":\"%s\","
                         "\"rtc_temp_c\":null,\"epoch\":%lld}",
                         time_str, (long long)time_utils_now());
            }
        }

    /* ── sd_health ─────────────────────────────────────────────────────── */
    } else if (strcmp(name, "sd_health") == 0) {
        uint32_t write_ms = 0, read_ms = 0;
        bool ok = storage_sd_health_check(&write_ms, &read_ms);
        if (ok) {
            snprintf(response, sizeof(response),
                     "{\"status\":\"ok\",\"mounted\":true,"
                     "\"write_ms\":%lu,\"read_ms\":%lu}",
                     (unsigned long)write_ms, (unsigned long)read_ms);
        } else {
            status = 500;
            snprintf(response, sizeof(response),
                     "{\"status\":\"fail\",\"mounted\":%s}",
                     storage_sd_is_mounted() ? "true" : "false");
        }

    /* ── littlefs_health ───────────────────────────────────────────────── */
    } else if (strcmp(name, "littlefs_health") == 0) {
        size_t total = 0, used = 0;
        esp_err_t err = storage_lfs_info(&total, &used);
        if (err == ESP_OK) {
            int pct = (total > 0) ? (int)((used * 100) / total) : 0;
            snprintf(response, sizeof(response),
                     "{\"status\":\"ok\",\"total_bytes\":%zu,"
                     "\"used_bytes\":%zu,\"used_pct\":%d}",
                     total, used, pct);
        } else {
            status = 500;
            snprintf(response, sizeof(response),
                     "{\"error\":\"littlefs_info_failed\",\"esp_err\":\"%s\"}",
                     esp_err_to_name(err));
        }

    /* ── wifi_cred ─────────────────────────────────────────────────────── */
    } else if (strcmp(name, "wifi_cred") == 0) {
        cJSON *root = cJSON_ParseWithLength(payload, payload_len);
        if (!root) {
            status = 400;
            snprintf(response, sizeof(response), "{\"error\":\"invalid_json\"}");
        } else {
            cJSON *j_ssid = cJSON_GetObjectItem(root, "ssid");
            cJSON *j_pass = cJSON_GetObjectItem(root, "password");
            if (!cJSON_IsString(j_ssid) || !j_ssid->valuestring[0]) {
                status = 400;
                snprintf(response, sizeof(response), "{\"error\":\"ssid_required\"}");
            } else {
                wifi_creds_t creds = {0};
                strncpy(creds.ssid, j_ssid->valuestring, sizeof(creds.ssid) - 1);
                if (cJSON_IsString(j_pass))
                    strncpy(creds.password, j_pass->valuestring, sizeof(creds.password) - 1);
                esp_err_t err = wifi_creds_save(&creds);
                if (err != ESP_OK) {
                    status = 500;
                    snprintf(response, sizeof(response),
                             "{\"error\":\"save_failed\",\"esp_err\":\"%s\"}",
                             esp_err_to_name(err));
                } else {
                    snprintf(response, sizeof(response),
                             "{\"status\":\"saved\",\"ssid\":\"%s\"}", creds.ssid);
                    publish_method_response(200, rid, response);
                    ESP_LOGW(TAG_DM, "WiFi creds updated, rebooting");
                    cJSON_Delete(root);
                    vTaskDelay(pdMS_TO_TICKS(300));
                    esp_restart();
                    return; /* unreachable, prevents double cJSON_Delete */
                }
            }
            cJSON_Delete(root);
        }

    /* ── ota ───────────────────────────────────────────────────────────── */
    } else if (strcmp(name, "ota") == 0) {
        esp_err_t ota_err = ESP_ERR_INVALID_ARG;
        bool payload_parsed = false;
        char ver_buf[16] = {0};

        cJSON *root = cJSON_ParseWithLength(payload, payload_len);
        if (root) {
            cJSON *j_ver = cJSON_GetObjectItem(root, "version");
            cJSON *j_url = cJSON_GetObjectItem(root, "main_url");
            cJSON *j_chk = cJSON_GetObjectItem(root, "checksum_url");
            if (cJSON_IsString(j_url) && cJSON_IsString(j_chk)) {
                payload_parsed = true;
                const char *ver = cJSON_IsString(j_ver) ? j_ver->valuestring : NULL;
                ota_err = ota_start(j_url->valuestring, j_chk->valuestring, ver);
                if (ver)
                    strncpy(ver_buf, ver, sizeof(ver_buf) - 1);
            }
            cJSON_Delete(root);
        }

        /* Fallback: use device twin config */
        if (!payload_parsed) {
            device_config_lock();
            const device_config_t *cfg = device_config_get();
            if (cfg) {
                strncpy(ver_buf, cfg->next_ota_ver, sizeof(ver_buf) - 1);
                ota_err = ota_start(cfg->main_url, cfg->checksum_url,
                                    cfg->next_ota_ver);
            }
            device_config_unlock();
        }

        if (ota_err == ESP_OK) {
            snprintf(response, sizeof(response),
                     "{\"status\":\"ota_started\",\"target_ver\":\"%s\"}",
                     ver_buf[0] ? ver_buf : "forced");
            publish_method_response(200, rid, response);
            ESP_LOGI(TAG_DM, "Method 'ota' -> 200: %s", response);
            return;
        } else {
            snprintf(response, sizeof(response),
                     "{\"status\":\"no_update\",\"current_ver\":\"%s\"}", FW_VERSION);
        }

    /* ── sensor_info ───────────────────────────────────────────────────── */
    } else if (strcmp(name, "sensor_info") == 0) {
        float esp_temp = 0.0f;
        bool esp_temp_ok = (board_config_get_internal_temp(&esp_temp) == ESP_OK);
        float rtc_temp = 0.0f;
        bool rtc_temp_ok = (time_utils_rtc_ok() &&
                            time_utils_rtc_temperature(&rtc_temp) == ESP_OK);
        size_t heap_free = esp_get_free_heap_size();
        size_t heap_min  = esp_get_minimum_free_heap_size();
        size_t heap_lrgst = heap_caps_get_largest_free_block(MALLOC_CAP_DEFAULT);

        int pos = snprintf(response, sizeof(response),
                           "{\"chip_type\":\"ESP32-S3\",\"uptime_s\":%lu,"
                           "\"heap_free\":%zu,\"heap_min_ever\":%zu,\"heap_largest\":%zu",
                           (unsigned long)get_uptime_s(), heap_free, heap_min, heap_lrgst);
        if (esp_temp_ok)
            pos += snprintf(response + pos, sizeof(response) - pos,
                            ",\"esp32_temp_c\":%.1f", esp_temp);
        else
            pos += snprintf(response + pos, sizeof(response) - pos,
                            ",\"esp32_temp_c\":null");
        if (rtc_temp_ok)
            pos += snprintf(response + pos, sizeof(response) - pos,
                            ",\"rtc_temp_c\":%.2f", rtc_temp);
        else
            pos += snprintf(response + pos, sizeof(response) - pos,
                            ",\"rtc_temp_c\":null");
        snprintf(response + pos, sizeof(response) - pos,
                 ",\"rtc_ok\":%s,\"fw_version\":\"%s\"}",
                 time_utils_rtc_ok() ? "true" : "false", FW_VERSION);

    /* ── unknown ───────────────────────────────────────────────────────── */
    } else {
        status = 404;
        snprintf(response, sizeof(response), "{\"error\":\"unknown method\"}");
        ESP_LOGW(TAG_DM, "Unknown method: '%s'", name);
    }

    publish_method_response(status, rid, response);
    ESP_LOGI(TAG_DM, "Method '%s' -> %d: %s", name, status, response);
}

/* ── MQTT event handler ───────────────────────────────────────────────── */

static void mqtt_event_handler(void *handler_args, esp_event_base_t base,
                                int32_t event_id, void *event_data)
{
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;

    switch (event->event_id) {
    case MQTT_EVENT_CONNECTED:
        s_connected = true;
        ESP_LOGI(TAG, "MQTT connected to Azure IoT Hub");

        esp_mqtt_client_subscribe(s_mqtt_client, "$iothub/twin/res/#", 0);
        esp_mqtt_client_subscribe(s_mqtt_client, "$iothub/twin/PATCH/properties/desired/#", 0);
        esp_mqtt_client_subscribe(s_mqtt_client, "$iothub/methods/POST/#", 0);

        iot_hub_request_twin();
        break;

    case MQTT_EVENT_DISCONNECTED:
        s_connected = false;
        reassembly_reset();
        ESP_LOGW(TAG, "MQTT disconnected (auto-reconnect active)");
        break;

    case MQTT_EVENT_DATA: {
        bool is_continuation = (event->current_data_offset > 0);
        bool is_multipart = (event->total_data_len > event->data_len);

        /* Cache topic on first fragment (event->topic is NULL on continuations) */
        char *topic = NULL;
        if (!is_continuation && event->topic && event->topic_len > 0) {
            topic = malloc(event->topic_len + 1);
            if (!topic) break;
            memcpy(topic, event->topic, event->topic_len);
            topic[event->topic_len] = '\0';

            /* If starting a multipart message, save topic for later fragments */
            if (is_multipart) {
                free(s_reassembly_topic);
                s_reassembly_topic = strdup(topic);
            }
        } else if (is_continuation) {
            /* Use cached topic from first fragment */
            if (!s_reassembly_topic) {
                ESP_LOGW(TAG, "Multipart continuation with no cached topic, dropping");
                break;
            }
            topic = strdup(s_reassembly_topic);
            if (!topic) break;
        } else {
            break; /* No topic available */
        }

        char *complete_data = NULL;
        int complete_len = 0;

        if (is_multipart || is_continuation) {
            complete_data = reassembly_accumulate(event->data, event->data_len,
                                                   event->current_data_offset,
                                                   event->total_data_len);
            if (!complete_data) {
                free(topic);
                break;
            }
            complete_len = event->total_data_len;
        } else {
            complete_data = event->data;
            complete_len = event->data_len;
        }

        if (strncmp(topic, "$iothub/twin/res/", 17) == 0) {
            int status = atoi(topic + 17);
            if (status >= 200 && status < 300) {
                ESP_LOGI(TAG, "Twin GET response (%d, %d bytes)", status, complete_len);
                handle_twin_get_response(complete_data, complete_len);
            } else {
                ESP_LOGW(TAG, "Twin response status %d", status);
            }
        }
        else if (strstr(topic, "$iothub/twin/PATCH/properties/desired") != NULL) {
            ESP_LOGI(TAG, "Twin desired patch (%d bytes)", complete_len);
            process_desired_properties(complete_data, complete_len);
            iot_hub_report_property("{\"configApplied\":true}");
        }
        else if (strncmp(topic, "$iothub/methods/POST/", 21) == 0) {
            char method_name[64] = {0};
            int method_rid = 0;
            const char *name_start = topic + 21;
            const char *qmark = strchr(name_start, '/');
            if (!qmark) qmark = strchr(name_start, '?');

            if (qmark) {
                size_t name_len = qmark - name_start;
                if (name_len >= sizeof(method_name)) name_len = sizeof(method_name) - 1;
                memcpy(method_name, name_start, name_len);
                method_name[name_len] = '\0';

                const char *rid_str = strstr(topic, "$rid=");
                if (rid_str) method_rid = atoi(rid_str + 5);
            } else {
                strncpy(method_name, name_start, sizeof(method_name) - 1);
            }

            ESP_LOGI(TAG, "Direct method: '%s' rid=%d", method_name, method_rid);
            handle_direct_method(method_name, complete_data, complete_len, method_rid);
        }

        if (is_multipart || is_continuation) {
            reassembly_reset();
        }

        free(topic);
        break;
    }

    case MQTT_EVENT_ERROR:
        ESP_LOGE(TAG, "MQTT error type=%d", event->error_handle->error_type);
        if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
            ESP_LOGE(TAG, "  esp_tls err=0x%x tls_stack=0x%x transport_sock=%d",
                     event->error_handle->esp_tls_last_esp_err,
                     event->error_handle->esp_tls_stack_err,
                     event->error_handle->esp_transport_sock_errno);
        }
        break;

    default:
        break;
    }
}

/* ── Public API ────────────────────────────────────────────────────────── */

esp_err_t iot_hub_init(const mqtt_config_t *cfg)
{
    if (s_initialized) {
        ESP_LOGW(TAG, "iot_hub already initialized");
        return ESP_ERR_INVALID_STATE;
    }
    if (!cfg || !cfg->hostname[0] || !cfg->device_id[0] || !cfg->shared_access_key[0]) {
        ESP_LOGE(TAG, "Invalid MQTT config");
        return ESP_ERR_INVALID_ARG;
    }

    s_mqtt_cfg = *cfg;

    ESP_LOGI(TAG, "MQTT config: host=%s dev=%s", s_mqtt_cfg.hostname, s_mqtt_cfg.device_id);

    esp_err_t ret = generate_sas_token();
    if (ret != ESP_OK) return ret;

    snprintf(s_username, sizeof(s_username), "%s/%s/?api-version=%s",
             s_mqtt_cfg.hostname, s_mqtt_cfg.device_id, MQTT_API_VERSION);

    snprintf(s_uri, sizeof(s_uri), "mqtts://%s:8883", s_mqtt_cfg.hostname);

    esp_mqtt_client_config_t mqtt_cfg = build_mqtt_config();
    s_mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    if (!s_mqtt_client) {
        ESP_LOGE(TAG, "MQTT client init failed");
        return ESP_FAIL;
    }

    esp_mqtt_client_register_event(s_mqtt_client, ESP_EVENT_ANY_ID,
                                    mqtt_event_handler, NULL);

    ret = esp_mqtt_client_start(s_mqtt_client);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "MQTT client start failed: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Start SAS renewal task */
    xTaskCreate(sas_renewal_task, "sas_renew", 4096, NULL, 2, NULL);

    s_initialized = true;
    ESP_LOGI(TAG, "MQTT client started (host=%s dev=%s)", s_mqtt_cfg.hostname, s_mqtt_cfg.device_id);
    return ESP_OK;
}

esp_err_t iot_hub_send_telemetry(const char *json_payload)
{
    if (!s_connected || !s_mqtt_client || !json_payload)
        return ESP_ERR_INVALID_STATE;

    char topic[256];
    snprintf(topic, sizeof(topic), "devices/%s/messages/events/", s_mqtt_cfg.device_id);

    int msg_id = esp_mqtt_client_publish(s_mqtt_client, topic, json_payload, 0,
                                          MQTT_QOS, 0);
    if (msg_id < 0) {
        ESP_LOGW(TAG, "MQTT publish failed");
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "D2C published (msg_id=%d, %d bytes)", msg_id, (int)strlen(json_payload));
    return ESP_OK;
}

esp_err_t iot_hub_request_twin(void)
{
    if (!s_mqtt_client) return ESP_ERR_INVALID_STATE;

    int rid = ++s_rid;
    char topic[64];
    snprintf(topic, sizeof(topic), "$iothub/twin/GET/?$rid=%d", rid);

    int msg_id = esp_mqtt_client_publish(s_mqtt_client, topic, "", 0, 0, 0);
    ESP_LOGI(TAG, "Twin GET requested (rid=%d msg_id=%d)", rid, msg_id);
    return (msg_id >= 0) ? ESP_OK : ESP_FAIL;
}

esp_err_t iot_hub_report_property(const char *json)
{
    if (!s_connected || !s_mqtt_client || !json)
        return ESP_ERR_INVALID_STATE;

    int rid = ++s_rid;
    char topic[96];
    snprintf(topic, sizeof(topic), "$iothub/twin/PATCH/properties/reported/?$rid=%d", rid);

    int msg_id = esp_mqtt_client_publish(s_mqtt_client, topic, json, 0, 0, 0);
    ESP_LOGI(TAG, "Reported properties (rid=%d): %s", rid, json);
    return (msg_id >= 0) ? ESP_OK : ESP_FAIL;
}

bool iot_hub_is_connected(void)
{
    return s_connected;
}

/* ── Message builders ──────────────────────────────────────────────────── */

esp_err_t iot_hub_send_online_status(bool is_boot)
{
    time_t epoch = time_utils_now();
    device_config_lock();
    const device_config_t *cfg = device_config_get();
    char ro_code_snap[32] = "";
    int c_id_snap = 0;
    if (cfg) {
        strncpy(ro_code_snap, cfg->ro_code, sizeof(ro_code_snap) - 1);
        c_id_snap = cfg->c_id;
    }
    device_config_unlock();

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "msg_type", "online_status");
    cJSON_AddNumberToObject(root, "Timestamp", (double)epoch);
    cJSON_AddBoolToObject(root, "isBoot", is_boot);
    cJSON_AddStringToObject(root, "Version", FW_VERSION);
    cJSON_AddStringToObject(root, "chipId", board_config_get_chip_id());
    cJSON_AddStringToObject(root, "ro_code", ro_code_snap);
    cJSON_AddNumberToObject(root, "c_id", c_id_snap);

    /* WiFi RSSI */
    int rssi = 0;
    esp_wifi_sta_get_rssi(&rssi);
    cJSON_AddNumberToObject(root, "rssi", rssi);

    /* WiFi IP */
    esp_netif_t *sta = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
    if (sta) {
        esp_netif_ip_info_t ip_info;
        if (esp_netif_get_ip_info(sta, &ip_info) == ESP_OK) {
            char ip_str[16];
            snprintf(ip_str, sizeof(ip_str), IPSTR, IP2STR(&ip_info.ip));
            cJSON_AddStringToObject(root, "IP", ip_str);
        }
    }

    /* MAC address */
    uint8_t mac[6];
    if (esp_wifi_get_mac(WIFI_IF_STA, mac) == ESP_OK) {
        char mac_str[18];
        snprintf(mac_str, sizeof(mac_str), "%02X:%02X:%02X:%02X:%02X:%02X",
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
        cJSON_AddStringToObject(root, "macAddr", mac_str);
    }

    /* RTC status */
    cJSON_AddBoolToObject(root, "Rtc", time_utils_rtc_ok());

    /* Uptime */
    uint32_t uptime_s = (uint32_t)(esp_timer_get_time() / 1000000);
    cJSON_AddNumberToObject(root, "uptime_s", uptime_s);

    /* Heap telemetry */
    cJSON_AddNumberToObject(root, "heap_free", (double)esp_get_free_heap_size());
    cJSON_AddNumberToObject(root, "heap_min_ever", (double)esp_get_minimum_free_heap_size());
    cJSON_AddNumberToObject(root, "heap_largest", (double)heap_caps_get_largest_free_block(MALLOC_CAP_DEFAULT));

    /* Temperatures */
    float esp_temp = 0.0f;
    if (board_config_get_internal_temp(&esp_temp) == ESP_OK)
        cJSON_AddNumberToObject(root, "esp32_temp_c", esp_temp);
    else
        cJSON_AddNullToObject(root, "esp32_temp_c");

    float rtc_temp = 0.0f;
    if (time_utils_rtc_ok() && time_utils_rtc_temperature(&rtc_temp) == ESP_OK)
        cJSON_AddNumberToObject(root, "rtc_temp_c", rtc_temp);
    else
        cJSON_AddNullToObject(root, "rtc_temp_c");

    /* SD status */
    if (is_boot) {
        uint32_t sd_wt = 0, sd_rt = 0;
        bool sd_ok = storage_sd_health_check(&sd_wt, &sd_rt);
        cJSON_AddBoolToObject(root, "SD_status", sd_ok);
        if (sd_ok) {
            cJSON_AddNumberToObject(root, "SD_WT", sd_wt);
            cJSON_AddNumberToObject(root, "SD_RT", sd_rt);
        }
    } else {
        cJSON_AddBoolToObject(root, "SD_status", storage_sd_is_mounted());
    }

    char *json = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);

    if (!json) return ESP_ERR_NO_MEM;

    esp_err_t ret = iot_hub_send_telemetry(json);
    free(json);
    return ret;
}

esp_err_t iot_hub_report_device_properties(void)
{
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "fw_version", FW_VERSION);
    char *json = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);

    if (!json) return ESP_ERR_NO_MEM;

    esp_err_t ret = iot_hub_report_property(json);
    free(json);
    return ret;
}

esp_err_t iot_hub_send_reg_telemetry(const device_config_t *cfg,
                                      uint8_t **raw_bufs, size_t *lens)
{
    if (!cfg || cfg->reg_count == 0) return ESP_ERR_INVALID_ARG;

    time_t epoch = time_utils_now();

    /* Estimate buffer size */
    size_t est = 256;
    for (int i = 0; i < cfg->reg_count; i++)
        est += 16 + lens[i] * 2;

    char *buf = malloc(est);
    if (!buf) return ESP_ERR_NO_MEM;

    int pos = snprintf(buf, est,
        "{\"ro_code\":\"%s\",\"c_id\":%d,\"ts\":%lld,\"data\":{",
        cfg->ro_code, cfg->c_id, (long long)epoch);

    bool first = true;
    for (int i = 0; i < cfg->reg_count; i++) {
        if (pos + 2 >= (int)est) break;
        if (!first) buf[pos++] = ',';
        first = false;
        pos += snprintf(buf + pos, est - pos, "\"%u\":\"", cfg->regs[i].raw_addr);
        if (lens[i] > 0) {
            for (size_t b = 0; b < lens[i] && pos + 2 < (int)est; b++)
                pos += snprintf(buf + pos, est - pos, "%02X", raw_bufs[i][b]);
        }
        if (pos + 1 < (int)est) buf[pos++] = '"';
    }

    pos += snprintf(buf + pos, est - pos, "}}");

    esp_err_t ret = iot_hub_send_telemetry(buf);
    free(buf);
    return ret;
}
