#pragma once
#ifndef __IOT_HUB_H__
#define __IOT_HUB_H__

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
#include "device_config.h"

/**
 * Initialize Azure IoT Hub MQTT client.
 * Generates SAS token, connects via MQTTS.
 * Spawns a background SAS renewal task.
 */
esp_err_t iot_hub_init(const mqtt_config_t *cfg);

/**
 * Publish telemetry JSON as a D2C message.
 */
esp_err_t iot_hub_send_telemetry(const char *json_payload);

/**
 * Request full Device Twin from IoT Hub.
 */
esp_err_t iot_hub_request_twin(void);

/**
 * Publish reported properties to Device Twin.
 */
esp_err_t iot_hub_report_property(const char *json);

/**
 * Check if MQTT client is connected.
 */
bool iot_hub_is_connected(void);

/**
 * Build and send online status telemetry (health, heap, WiFi, SD).
 * is_boot=true on first call (includes SD write/read timing),
 * is_boot=false for periodic sends.
 */
esp_err_t iot_hub_send_online_status(bool is_boot);

/**
 * Build and report device properties to twin.
 */
esp_err_t iot_hub_report_device_properties(void);

/**
 * Build and send register telemetry.
 */
esp_err_t iot_hub_send_reg_telemetry(const device_config_t *cfg,
                                      uint8_t **raw_bufs, size_t *lens);

#endif
