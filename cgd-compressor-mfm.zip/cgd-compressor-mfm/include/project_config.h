#pragma once

// =============================================================================
// Firmware version
// =============================================================================
#define FW_VERSION          "2.1.6"

// =============================================================================
// Device / vendor identity
// =============================================================================
#define DEVICE_MANUFACTURER "ESPRESSIF"
#define DEVICE_MODEL        "MODBUS CONTROLLER"
#define SOFTWARE_VENDOR     "DigitalPetro Pvt. Ltd."
#define CLIENT              "BPCL GAS BU"

// =============================================================================
// NVS keys (shared across board_config, device_config, wifi_creds)
// =============================================================================
#define NVS_NAMESPACE       "my-app"
#define NVS_KEY_BOARD_TYPE  "board_type"
#define NVS_KEY_WIFI_SSID   "wifi_ssid"
#define NVS_KEY_WIFI_PASS   "wifi_password"

// =============================================================================
// RS485 / Modbus defaults
// =============================================================================
#define RS485_BAUD              9600
#define MODBUS_DEFAULT_SLAVE_ID 1
#define MODBUS_RTU_TIMEOUT_MS   100
#define MODBUS_TCP_TIMEOUT_MS   500

// =============================================================================
// W5500 Ethernet defaults
// =============================================================================
#define ETH_DEFAULT_IP      "192.168.0.38"
#define ETH_DEFAULT_GATEWAY "192.168.0.1"
#define ETH_DEFAULT_SUBNET  "255.255.255.0"

// =============================================================================
// LoRa defaults
// =============================================================================
#define LORA_DEFAULT_BAUD           9600

// =============================================================================
// NTP
// =============================================================================
#define NTP_SERVER_1  "time.google.com"
#define NTP_SERVER_2  "time.nist.gov"
#define NTP_SYNC_INTERVAL   3600

// =============================================================================
// Azure IoT Hub MQTT
// =============================================================================
#define MQTT_SAS_TOKEN_EXPIRY_SECS  3600        // 1 hour SAS token lifetime
#define MQTT_SAS_RENEW_BEFORE_SECS  300         // Renew 5 min before expiry
#define MQTT_RECONNECT_WAIT_SECS    10          // Wait between reconnect attempts
#define MQTT_KEEPALIVE_SECS         240         // 4 min keepalive
#define MQTT_TASK_STACK_SIZE        6144        // MQTT internal task stack
#define MQTT_QOS                    1           // QoS for D2C telemetry
#define MQTT_BUFFER_IN_SIZE         2048        // Incoming buffer (twin responses)
#define MQTT_BUFFER_OUT_SIZE        4096        // Outgoing buffer (telemetry + method responses)
#define MQTT_API_VERSION            "2021-04-12"

// =============================================================================
// Storage mountpoints
// =============================================================================
#define SD_MOUNT_POINT      "/sdcard"
#define LFS_BASE_PATH       "/lfs"

// =============================================================================
// Config file names (relative — used by file_sync, derive full paths below)
// =============================================================================
#define CONFIG_FILENAME         "iot_config.json"
#define MQTT_CONFIG_FILENAME    "mqtt_config.json"
#define WIFI_FILENAME           "wifi.txt"

#define CONFIG_PATH_SD          SD_MOUNT_POINT "/" CONFIG_FILENAME
#define CONFIG_PATH_LFS         LFS_BASE_PATH  "/" CONFIG_FILENAME
#define MQTT_CONFIG_PATH_SD     SD_MOUNT_POINT "/" MQTT_CONFIG_FILENAME
#define MQTT_CONFIG_PATH_LFS    LFS_BASE_PATH  "/" MQTT_CONFIG_FILENAME
#define WIFI_PATH_SD            SD_MOUNT_POINT "/" WIFI_FILENAME
#define WIFI_PATH_LFS           LFS_BASE_PATH  "/" WIFI_FILENAME
#define DEFAULT_POST_INTERVAL   120
#define DEFAULT_STATUS_INTERVAL 900             // 15 min online status

// =============================================================================
// OTA
// =============================================================================
#define OTA_MAX_RETRIES     5
#define OTA_TIMEOUT_MS      (15 * 60 * 1000)   // 15 minutes

// =============================================================================
// Telemetry / reliability
// =============================================================================
#define MQTT_FAIL_REBOOT_COUNT  10
#define PERIODIC_REBOOT_HOURS   12
