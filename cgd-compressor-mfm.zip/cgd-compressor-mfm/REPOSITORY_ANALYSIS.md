# CGD Compressor MFM - Repository Analysis & Dispenser Protocol Integration Guide

## PART 1: SYSTEM OVERVIEW & ARCHITECTURE

### 1.1 Project Purpose

This is an **ESP32-S3 based Modbus controller** designed to:
- **Read Modbus registers** from remote devices (compressors, dispensers, meters, etc.)
- **Aggregate telemetry data** and send it to Azure IoT Hub via MQTT
- **Support dynamic reconfiguration** via Azure Device Twin properties
- **Enable remote management** through Azure direct methods and OTA updates

**Note:** The project name "cgd-compressor-mfm" suggests it was originally built for compressors, but it's actually a **generic multi-device telemetry system** capable of reading from any Modbus-compliant device. There are **no dispenser-specific implementations** currently—this is a generic framework you'll need to extend.

---

### 1.2 Hardware Architecture

```
┌─────────────────────────────────────────────────┐
│           ESP32-S3 Microcontroller              │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌────────────────┐      ┌──────────────────┐  │
│  │  RS485 Driver  │──────│ UART (RTU mode)  │  │
│  │   (Hardware)   │      │                  │  │
│  └────────────────┘      └──────────────────┘  │
│         ↓                                       │
│    (Modbus RTU                                  │
│   over UART)                                   │
│                                                 │
│  ┌────────────────┐      ┌──────────────────┐  │
│  │  W5500 Chip    │──────│  Ethernet (TCP)  │  │
│  │  (Ethernet)    │      │                  │  │
│  └────────────────┘      └──────────────────┘  │
│         ↓                                       │
│    (Modbus TCP                                  │
│    over Ethernet)                               │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │  WiFi (Built-in ESP32-S3)               │   │
│  │  → Azure IoT Hub MQTT (telemetry)      │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│  ┌─────┐  ┌──────┐  ┌────────┐  ┌────────┐   │
│  │ SD  │  │ I2C  │  │ RTC    │  │LittleFS│   │
│  └─────┘  └──────┘  └────────┘  └────────┘   │
│                                                 │
└─────────────────────────────────────────────────┘

Remote Devices with Modbus:
[Compressor] [Dispenser] [Flow Meter] [Pump] ... (any Modbus slave)
     ↓              ↓           ↓         ↓
     └──────────────┴───────────┴─────────┘
           RS485 Network (or TCP)
                    ↑
            (Half-duplex UART)
```

---

### 1.3 System Boot & Initialization Flow

```
app_main()
    ↓
[1] Initialize Storage (NVS + LittleFS)
    ↓
[2] Board Detection
    └─→ Detect board type (EVIDEN_V1 or DIGITALPETRO_V1)
    └─→ Get pin configuration and chip ID
    ↓
[3] SD Card Initialization
    └─→ If fails, mark for retry in background task
    ↓
[4] File Synchronization
    └─→ Copy iot_config.json, mqtt_config.json, wifi.txt from SD → LittleFS
    ↓
[5] Network Stack Initialization
    └─→ Start esp_netif and event loop
    ↓
[6] WiFi Manager
    └─→ Load WiFi credentials (SD → NVS → LittleFS → defaults)
    ↓
[7] Time Synchronization
    └─→ Initialize RTC, sync with NTP servers
    ↓
[8] LOAD DEVICE CONFIGURATION (CRITICAL)
    └─→ Load iot_config.json
    └─→ Parse Modbus settings (RTU vs TCP, slave addr, baud, etc.)
    └─→ Parse register mappings (which regs to read)
    └─→ Parse posting intervals
    ↓
[9] Azure IoT Hub MQTT Initialization
    └─→ Load mqtt_config.json (hostname, device_id, shared_access_key)
    └─→ Generate SAS token
    └─→ Connect to Azure IoT Hub
    └─→ Subscribe to Device Twin updates and direct methods
    ↓
[10] W5500 Ethernet Initialization
    └─→ Always initialized (even if RTU mode selected)
    └─→ Allows runtime TCP/RTU switching
    ↓
[11] Modbus Adapter Initialization
    └─→ Configure based on loaded device config
    └─→ Start RS485 UART driver (if RTU) or prepare TCP (if TCP)
    ↓
[12] Wait for MQTT Connection (up to 15 seconds)
    ↓
[13] Report Device Properties to Device Twin
    ↓
[14] Check for OTA Updates
    ↓
[15] Create Background Tasks
    └─→ poller_task: Read Modbus registers in a loop
    └─→ background_task: Handle SD retries, periodic reboot checks, status telemetry
    └─→ sas_renewal_task: Refresh Azure SAS token every hour
    ↓
[RUNNING...]
```

---

### 1.4 Core Components & Their Roles

#### **A. Device Configuration (lib/device_config/)**

**Responsibility:** Load, parse, and manage device settings from JSON configuration files.

**Key Structure (`device_config_t`):**
```c
typedef struct {
    bool          is_rtu;              // true=RTU (RS485), false=TCP (Ethernet)
    char          ro_code[32];         // Read-out code (user identifier)
    int           c_id;                // Compressor/device ID
    uint8_t       slave_addr;          // Modbus slave address
    uint32_t      baud;                // UART baud rate (if RTU)
    uint8_t       data_bits;           // UART data bits
    uint8_t       parity;              // UART parity: 'N', 'E', 'O'
    uint8_t       stop_bits;           // UART stop bits
    esp_ip4_addr_t server_ip;          // TCP server IP (if TCP)
    uint16_t      server_port;         // TCP server port
    uint32_t      post_interval;       // Seconds between telemetry posts
    uint32_t      status_interval;     // Seconds between status updates
    esp_ip4_addr_t eth_ip,eth_gw,eth_mask;  // Ethernet config
    reg_entry_t   *regs;               // Array of registers to read
    int           reg_count;           // Number of register entries
    char          c_make[32];          // Device make/model (currently unused)
    // ... OTA fields ...
} device_config_t;
```

**Configuration File Format (`iot_config.json`):**
```json
{
  "ro_code": "PUMP_001",
  "c_id": 100,
  "c_make": "GENERIC_DEVICE",
  "post_interval": 60,
  "status_interval": 900,
  "mbus_RTU": {
    "slave": 1,
    "baud": 9600,
    "dataBits": 8,
    "parity": "N",
    "stopBits": 1
  },
  "m": [40001, 10, 40015, 5, 30200, 20],
  "ota": {
    "ver": "2.2.0",
    "bin_url": "https://...",
    "checksum_url": "https://..."
  }
}
```

**Key Features:**
- Thread-safe (uses mutex) for concurrent access by poller and config updater
- Supports dynamic configuration updates via Azure Device Twin
- Automatically notifies poller task when Modbus settings change
- Handles address resolution (Modbus addresses → function codes and offsets)

#### **B. Modbus Adapter (lib/modbus_adapter/)**

**Responsibility:** Provide unified read/write interface for both RTU and TCP Modbus protocols.

**Interface:**
```c
// Initialize with configuration and board pinout
esp_err_t modbus_adapter_init(const board_config_t *board, const modbus_config_t *cfg);

// Read registers (handles CRC for RTU, MBAP for TCP)
esp_err_t modbus_adapter_read(const reg_entry_t *entry, uint8_t *raw_bytes, size_t *out_len);

// Write a single register
esp_err_t modbus_adapter_write(uint16_t offset, uint16_t value);

// Clean shutdown
void modbus_adapter_deinit(void);
```

**Register Entry Structure:**
```c
typedef struct {
    uint8_t  func_code;   // 1=coils, 2=discrete inputs, 3=holdings, 4=input registers
    uint16_t offset;      // Zero-based address within coil/register space
    uint16_t length;      // Number of coils/registers to read
    uint16_t raw_addr;    // Original datasheet address (for logging)
} reg_entry_t;
```

**Modbus Address Resolution:**
- **Coils (FC1):** Addresses 1-9999 → offset = raw - 1
- **Discrete Inputs (FC2):** Addresses 10001-19999 → offset = raw - 10001
- **Input Registers (FC4):** Addresses 30001-39999 → offset = raw - 30001
- **Holding Registers (FC3):** Addresses 40001-49999 → offset = raw - 40001

**RTU vs TCP:**
| Aspect | RTU (RS485) | TCP (Ethernet) |
|--------|-----------|----------|
| **Transport** | UART half-duplex | Socket over LAN |
| **Framing** | 8, N/E/O, 1/2 (configurable) | Modbus/TCP header |
| **Error Detection** | CRC-16 | TCP checksums + LRC |
| **Timing** | ~100ms timeout | ~500ms timeout |
| **Multiple Devices** | Addressed by slave ID | Single connection per server:port |

#### **C. Poller Task (src/main.c - poller_task)**

**Responsibility:** Periodically read all configured registers and publish telemetry.

**Workflow:**
```
Loop:
  [1] Lock config, snapshot current settings
  [2] If setting changed:
      - Allocate buffers for each register
      - Reinitialize Modbus adapter with new settings
      - Release lock immediately
  [3] Read all registers in sequence:
      for i in 0..reg_count:
        modbus_adapter_read(regs[i], buffer[i], &length[i])
  [4] Build telemetry JSON from raw buffers
  [5] Publish to Azure IoT Hub via MQTT
  [6] Wait for next interval (or immediate wakeup if config changed)
```

**Key Points:**
- Minimizes lock duration (snapshot pattern)
- Robust to configuration changes mid-polling
- Logs warnings for individual register read failures
- Automatically reboots after 10 consecutive MQTT failures

#### **D. Azure IoT Hub MQTT (lib/iot_hub/)**

**Responsibility:** Connect to Azure IoT Hub, receive configuration updates, and publish telemetry.

**Key Features:**
1. **SAS Token Generation:** Creates HMAC-SHA256 signed tokens (1-hour lifetime, auto-renewed)
2. **Device Twin Sync:** 
   - Subscribes to desired properties patches
   - Receives full twin on connection
   - Updates apply immediately to device_config
3. **Direct Methods:** Supports remote commands:
   - `reboot`: Restart the device
   - `status`: Get device health
   - `ota`: Trigger firmware update
   - `wifi_cred`: Update WiFi credentials
   - `clear_sd`, `clear_littlefs`: Factory reset options
   - `sd_health`, `littlefs_health`: Storage diagnostics
   - `sensor_info`, `rtc_health`: Hardware health
4. **Telemetry Publishing:**
   - Register data: Raw bytes arranged as telegrams
   - Online status: Heap, WiFi signal, storage metrics
   - Device properties: Firmware version, chip ID, board type

**Telemetry Format:**
```json
{
  "timestamp": "2024-03-05T14:30:45Z",
  "reg_data": [
    {"addr": 40001, "len": 10, "data": "0102030405060708090A"},
    {"addr": 40015, "len": 5, "data": "000A000B000C"},
    ...
  ]
}
```

#### **E. RS485 Driver (lib/rs485/)**

**Responsibility:** Low-level UART configuration and half-duplex RS485 communication.

**Features:**
- Configurable baud, data bits, parity, stop bits
- Automatic RX/TX direction control (GPIO-based or UART auto)
- Per-transaction timeout handling
- CRC validation delegated to modbus_adapter

#### **F. Board Configuration (lib/board_config/)**

**Responsibility:** Detect and store hardware platform details.

**Board Types:**
- `BOARD_EVIDEN_V1`: Custom Eviden platform
- `BOARD_DIGITALPETRO_V1`: DigitalPetro reference design

**Pinout Storage:**
```c
typedef struct {
    int rs485_tx_pin, rs485_rx_pin, rs485_en_pin;
    int sd_miso_pin, sd_mosi_pin, sd_sclk_pin, sd_cs_pin;
    int w5500_miso, w5500_mosi, w5500_sck, w5500_cs, w5500_rst;
    int lora_tx_pin, lora_rx_pin;
    // ... etc
} board_config_t;
```

---

### 1.5 Data Flow Through the System

```
CONFIGURATION ENTRY POINTS:
├─ [1] Initial Load from SD Card (boot)
├─ [2] Azure Device Twin desired properties (runtime)
└─ [3] Pushed via Direct Method "status" / "ota"

                            ↓

                 device_config_apply_json()
                            ↓
              Parse into device_config_t struct
                            ↓
           Notify poller_task of config change
                            ↓

POLLING CYCLE (repeats every post_interval seconds):
                            ↓
              [Acquire config lock]
              [Snapshot config into local copy]
              [Release lock immediately]
                            ↓
    For each register entry:
        modbus_adapter_read(reg_i)
                ↓
         [RTU path]              [TCP path]
         │                       │
         ├─ Build Modbus         ├─ Build Modbus
         │  RTU request          │  TCP MBAP + PDU
         │                       │
         ├─ rs485_transact()     ├─ tcp_transact()
         │  (UART)               │  (socket)
         │                       │
         ├─ Validate CRC         ├─ Parse MBAP
         │                       │
         └─ Extract bytes        └─ Extract PDU bytes
                ↑                        ↑
                └────────┬──────────────┘
                         ↓
            [Received raw register bytes]
                         ↓
         iot_hub_send_reg_telemetry()
                         ↓
            Build JSON telegram and publish
                         ↓
          [Published to Azure IoT Hub]
                         ↓
         Update MQTT connection status
         Check for SAS token renewal
         Monitor heap / WiFi signal
```

---

### 1.6 Thread Architecture

| Thread | Priority | Stack | Responsibility |
|--------|----------|-------|-----------------|
| `poller_task` | 5 | 4096 | Read registers, publish telemetry |
| `background_task` | 3 | 4096 | SD retry, periodic reboot, status updates |
| `sas_renewal_task` | 2 | 4096 | Refresh Azure SAS token (1h lifecycle) |
| `mqtt_event_task` | (system) | (system) | Process MQTT events (MBEDTLS/LwIP) |
| `idle` / `watchdog` | (system) | (system) | System-level housekeeping |

All tasks are thread-safe via:
- **Mutexes:** device_config, modbus_adapter
- **Atomics:** Connection flags, counters
- **Task notification:** Wake poller on config change

---

## PART 2: ADDING DISPENSER PROTOCOLS

### 2.1 Understanding "Dispenser Protocol"

A **dispenser protocol** in this system context means:

1. **Protocol Definition:** The set of Modbus register addresses and function codes that a specific dispenser manufacturer uses to expose their data
2. **Communication Parameters:** Modbus slave address, baud rate (if RTU), TCP port (if TCP), etc.
3. **Data Mapping:** How raw Modbus register values map to business metrics (liters, RPM, temperature, etc.)
4. **Multi-Nozzle Support:** How different nozzles are represented (separate slave addresses, different registers, or register offsets)

### 2.2 Why Current Code Is Generic (And Why This Is Good)

The existing system **intentionally doesn't hardcode any device protocols** because:

- **Modularity:** The same firmware works with any Modbus-compliant device
- **Reconfigurability:** Change devices by uploading new JSON config (no firmware recompile)
- **Extensibility:** Add new dispenser types without firmware changes

**However**, different dispenser companies will have different register layouts:

| Company A | Company B | Company C | Company D |
|-----------|-----------|-----------|-----------|
| Slave 1: Nozzle 1 | Slave 1: All data | Slave 1-4: One nozzle each | Holding Regs: All |
| Slave 2: Nozzle 2 | Regs: 40001-40050 | Regs vary per slave | Input Regs: Spare |
| Holding Regs: 40001-40100 | | Different baud | Baud: 19200 |
| Baud: 9600 | | | Status: Custom parsing |

---

### 2.3 Step-by-Step Procedure for Adding 4 Dispenser Protocols

#### **Phase A: Research & Documentation**

**For each of the 4 companies, gather:**

1. **Communication Parameters:**
   - RTU (RS485) or TCP (Ethernet)?
   - If RTU: Baud rate, data bits, parity, stop bits
   - If TCP: Server IP, port
   - Modbus slave address(es) — does each nozzle have its own slave ID?

2. **Register Mapping:**
   - Compile the complete register list from manufacturer datasheets
   - Map Modbus address ranges to physical parameters:
     - Volume dispensed (liters)
     - Price (currency units)
     - Pump running status (on/off)
     - Temperature, pressure, fault codes, etc.
   - Function codes: Which addresses are coils (FC1), discrete inputs (FC2), input registers (FC4), holding registers (FC3)?

3. **Data Interpretation Rules:**
   - Are values in raw ADC counts, fixed-point (int16 as Q1.15), or floating-point?
   - Byte order: Big-endian or little-endian?
   - Are there scaling factors? (e.g., register value × 0.1 = actual liters)
   - Timezone considerations for timestamps?

4. **Example Register Maps:**

```markdown
### Company A Dispenser Protocol

**Communication:**
- Mode: RTU (RS485)
- Baud: 9600, 8 data bits, No parity, 1 stop bit
- Nozzule Support: 2 nozzles per pump, each on separate slave address
  - Nozzle 1: Slave address 101
  - Nozzle 2: Slave address 102

**Register Layout:**

| Register | FC | Name | Type | Scale | Notes |
|----------|----|----|------|-------|-------|
| 40001 | 3 | Volume Instance | UInt32 | 0.001 L | 32-bit, store as 2×16-bit |
| 40003 | 3 | Unit Price | UInt16 | 0.01 $/L | Price per liter |
| 40004 | 3 | Pump Status | UInt16 | - | Bit 0: pumping, Bit 1: alarm |
| 40005 | 3 | Temperature | Int16 | 1 °C | Signed |
| 40006 | 3 | Pressure | UInt16 | 0.1 kPa | |
| ...etc | | | | | |

**Configuration JSON:**
\`\`\`json
{
  "ro_code": "COMPANY_A_PUMP",
  "c_id": 101,
  "c_make": "Company_A_Dispenser",
  "post_interval": 30,
  "status_interval": 900,
  "mbus_RTU": {
    "slave": 101,
    "baud": 9600,
    "dataBits": 8,
    "parity": "N",
    "stopBits": 1
  },
  "m": [40001, 6, 40010, 10]
}
```

---

#### **Phase B: Create Protocol Definition Files**

Create a **protocol documentation directory** in your repository:

```
lib/dispenser_protocols/
├── README.md                          (overview of all 4 protocols)
├── company_a/
│   ├── PROTOCOL.md                    (detailed spec)
│   ├── register_map.csv               (register layout table)
│   └── sample_config.json             (example iot_config.json)
├── company_b/
│   ├── PROTOCOL.md
│   ├── register_map.csv
│   └── sample_config.json
├── company_c/
│   ├── PROTOCOL.md
│   ├── register_map.csv
│   └── sample_config.json
└── company_d/
    ├── PROTOCOL.md
    ├── register_map.csv
    └── sample_config.json
```

**Example: PROTOCOL.md for Company A**

```markdown
# Company A Dispenser Protocol

## Overview
- **Manufacturer:** Company A GmbH
- **Model:** Pump-3000 Series
- **Communication:** Modbus RTU over RS485
- **Nozzles:** 2 per unit (dual dispensing)

## Physical Layout
```
     [Pump Base Unit]
            ↓
      [Modbus Controller]
            ↓
     ┌─────┴──────┐
     ↓            ↓
  [Nozzle1]   [Nozzle2]
  Slave 101   Slave 102
```

## Communication Parameters
- **Mode:** RTU (RS485)
- **Baud:** 9600 bps
- **Data Bits:** 8
- **Parity:** None
- **Stop Bits:** 1
- **Timeout:** 100 ms typical, 500 ms max

## Register Mapping

### Nozzle Data (Slave 101 = Nozzle 1, Slave 102 = Nozzle 2)

| Address | FC | Type | Name | Scale | Unit | Notes |
|---------|----|----|------|-------|------|-------|
| 40001 | 3 | U32 | Volume | 0.001 | L | Dispensed volume instance |
| 40003 | 3 | U16 | Price | 0.01 | $/L | Unit price |
| 40004 | 3 | U16 | Status | - | - | Pumping, fault, error flags |
| 40005 | 3 | I16 | Temperature | 1 | °C | Sensor temp |
| 40006 | 3 | U16 | Pressure | 0.1 | kPa | Outlet pressure |

### Global Unit Params (Slave 101 only)

| 40010 | 3 | U16 | Nozzle Count | - | - | 1 or 2 |
| 40011 | 3 | U32 | Cumulative Volume | 0.001 | L | Total since reset |

## Configuration Example

```json
{
  "ro_code": "PUMP_UNIT_001",
  "c_id": 1001,
  "c_make": "Company_A_3000",
  "post_interval": 30,
  "mbus_RTU": {
    "slave": 101,
    "baud": 9600,
    "dataBits": 8,
    "parity": "N",
    "stopBits": 1
  },
  "m": [40001, 8, 40010, 2]
}
```

## Multi-Nozzle Setup

To read both nozzles, **create two separate device configurations** (one per nozzle):

**Device 1 (Nozzle 1):**
```json
{
  "ro_code": "PUMP_001_NOZZLE_1",
  "c_id": 1001,
  "mbus_RTU": {"slave": 101, ...}
}
```

**Device 2 (Nozzle 2):**
```json
{
  "ro_code": "PUMP_001_NOZZLE_2",
  "c_id": 1002,
  "mbus_RTU": {"slave": 102, ...}
}
```

## Data Interpretation Guide

### Volume (Register 40001)
- Raw Modbus registers: 2×16-bit (big-endian)
- Value 1234 → 1234 × 0.001 = 1.234 liters

### Temperature (Register 40005)
- **Signed 16-bit** (two's complement)
- Range: -32768 to +32767
- Value 250 → 250 × 1 = 250°C (warning: unrealistic)
- Value -100 → -100°C (warning: sensor failure?)

### Status Flags (Register 40004)
```
Bit 0: Pumping (1=active, 0=idle)
Bit 1: Fault (1=error state)
Bit 2: Low pressure (1=warning)
Bit 3: High temp (1=warning)
Bits 4-15: Reserved
```

## Known Issues / Quirks
- Cumulative volume resets on firmware update
- Temperature reading lags 2-3 seconds after pump stop
- Communicates only every 100 ms (max polling rate: 10 Hz)
```

---

#### **Phase C: Implement Protocol Handler (Optional)**

If your protocols differ significantly in **data interpretation**, you may want to create a **protocol handler module**. However, for most Modbus systems, the current generic approach is sufficient.

**Only create protocol handlers IF:**
- You need custom parsing beyond raw Modbus reads (e.g., bit-field extraction)
- You need protocol-specific logic (state machines, alarm handling)
- You want hardware-specific pre-processing

**Example: Optional Protocol Handler Structure**

```c
// lib/dispenser_protocols/protocol_handler.h
#pragma once

typedef enum {
    DISPENSER_COMPANY_A,
    DISPENSER_COMPANY_B,
    DISPENSER_COMPANY_C,
    DISPENSER_COMPANY_D,
} dispenser_protocol_t;

typedef struct {
    // Raw Modbus data
    uint8_t *raw_regs[10];
    size_t raw_lens[10];
    
    // Parsed business metrics
    float volume_liters;
    float price_per_liter;
    uint16_t status_flags;
    int16_t temperature_c;
    float pressure_kpa;
} dispenser_telemetry_t;

// Parse raw register data into business metrics
esp_err_t dispenser_protocol_parse(
    dispenser_protocol_t protocol,
    const uint8_t **raw_bufs,
    const size_t *raw_lens,
    dispenser_telemetry_t *out_telemetry
);
```

**However, I recommend AGAINST adding this complexity initially—keep using raw JSON telegrams, as the cloud backend can interpret them.**

---

#### **Phase D: Configure Each Dispenser in Azure IoT Hub**

The beauty of this system is that **dispenser configuration is data-driven**, not firmware-driven.

**For each of 4 companies, create a Device Twin in Azure IoT Hub:**

**Option 1: Individual Pump Per Device (Recommended)**
```
Device Twin "pump_company_a_unit_001"
  ↓
  desired properties:
    {
      "ro_code": "PUMP_A_001",
      "c_id": 1001,
      "c_make": "Company_A_3000",
      "mbus_RTU": {
        "slave": 101,
        "baud": 9600,
        "dataBits": 8,
        "parity": "N",
        "stopBits": 1
      },
      "m": [40001, 8, 40010, 2],
      "post_interval": 30
    }
```

Device automatically receives config, Modbus adapter reinitializes, polling picks up new register list.

**Option 2: Centralized Configuration Management**

Use a **configuration management app** in Azure that pushes different configs to different devices based on their `c_make` field.

**Example Azure Logic App:**

```
Trigger: New dispenser deployed
  ↓
Use QR code / RFID to identify Company & Model
  ↓
Lookup protocol spec from database
  ↓
Push matching config to Device Twin
  ↓
Device auto-reconfigures
```

---

#### **Phase E: Testing Each Protocol**

For each of the 4 dispenser companies:

1. **Bench Test (Without Hardware):**
   ```
   - Load protocol spec
   - Create iot_config.json with register addresses
   - Review Modbus register ranges for conflicts
   - Validate address resolution (do addresses match FC codes?)
   ```

2. **Hardware Test (With Real Dispenser):**
   ```
   - Connect ESP32 to dispenser via RS485
   - Load config to SD card
   - Boot device, monitor ESP logs
   - Verify Modbus read succeeds (no CRC errors, no timeouts)
   - Verify telemetry JSON is published to Azure
   - Inspect raw register data in IoT Hub
   - Manually validate one register read with MultiMaster or similar tool
   ```

3. **Cloud Test:**
   ```
   - Extract sample telemetry from IoT Hub
   - Verify all expected registers are present
   - Write cloud-side parsing logic to convert raw bytes → business metrics
   - Test for 24+ hours monitoring for anomalies
   ```

---

### 2.4 Multi-Nozzle Handling Strategies

Different companies handle multiple nozzles differently. Here are common patterns and how to configure them:

#### **Pattern A: Each Nozzle = Separate Slave Address**

```
Pump Unit (physical)
  ├─ Nozzle 1 → Modbus Slave 101
  └─ Nozzle 2 → Modbus Slave 102
```

**Handling:**
Create **two separate device configurations** (two Device Twins in Azure):

```json
{
  "ro_code": "PUMP_001_NOZZLE_1",
  "mbus_RTU": { "slave": 101, ... },
  "m": [40001, 10]
}
```

```json
{
  "ro_code": "PUMP_001_NOZZLE_2",
  "mbus_RTU": { "slave": 102, ... },
  "m": [40001, 10]
}
```

Each ESP32 device (or same device with dual serial ports) reads both and sends as separate telegrams.

#### **Pattern B: All Nozzles on Same Slave, Different Registers**

```
Pump Unit
  ├─ Nozzle 1 data → Registers 40001-40010
  └─ Nozzle 2 data → Registers 40011-40020
```

**Handling:**
Single config reads multiple register ranges:

```json
{
  "ro_code": "PUMP_001",
  "mbus_RTU": { "slave": 1, ... },
  "m": [40001, 10, 40011, 10]
}
```

Telemetry will include both ranges; cloud backend can split them by index.

#### **Pattern C: Nozzle as Sub-Parameter**

Some dispensers encode nozzle selection as a **sub-register or bit-field**.

**Handling:**
Read the status register containing nozzle info, add custom parsing logic (optional protocol handler):

```c
// Example
uint16_t status = raw_bytes[4];  // Register 40004
uint8_t nozzle_id = status & 0x0F;  // Bits 0-3
uint8_t pumping = (status >> 8) & 1;  // Bit 8
```

---

### 2.5 Configuration Template for Each Company

Create a standardized template file for each dispenser company:

**File: `lib/dispenser_protocols/company_a/sample_config.json`**

```json
{
  "# Comment: Company A Dispenser Configuration": "",
  "# Nozzle mapping: Each nozzle must be a separate device instance": "",
  "# because they use Slave addresses 101 (Nozzle 1) and 102 (Nozzle 2)": "",

  "ro_code": "COMPANY_A_PUMP_{{ PUMP_ID }}_NOZZLE_{{ NOZZLE_NUM }}",
  "c_id": 1000,
  "c_make": "Company_A_Pump_3000",
  "post_interval": 30,
  "status_interval": 900,

  "# RTU Configuration for Company A": "",
  "mbus_RTU": {
    "slave": 101,
    "baud": 9600,
    "dataBits": 8,
    "parity": "N",
    "stopBits": 1
  },

  "# Register mapping (Modbus address ranges to read)": "",
  "# Nozzle registers: 40001-40010": "",
  "# Unit-level registers: 40011-40015": "",
  "m": [
    40001, 10,
    40011,  5
  ],

  "# OTA (Firmware updates)": "",
  "ota": {
    "ver": "2.1.6",
    "bin_url": "https://your-cloud/firmware/company_a/2.1.6/app.bin",
    "checksum_url": "https://your-cloud/firmware/company_a/2.1.6/checksums.json"
  }
}
```

For **Nozzle 2**, just change `"slave": 102` and update `ro_code` to reference `NOZZLE_2`.

---

### 2.6 Cloud-Side Data Interpretation

The ESP32 sends **raw telemetry** to Azure IoT Hub. The **cloud backend** must interpret it using the protocol specs.

**Azure Stream Analytics / Azure Functions Example:**

```javascript
// processDispensersData.js
function parseCompanyADispenser(regData) {
  // regData = [
  //   { addr: 40001, len: 10, data: "hex_string" },
  //   { addr: 40011, len: 5, data: "hex_string" }
  // ]

  const nozzleRegs = regData.find(r => r.addr === 40001);
  const unitRegs = regData.find(r => r.addr === 40011);

  if (!nozzleRegs || !unitRegs) return null;

  // Parse hex strings to binary
  const nozzle_bytes = Buffer.from(nozzleRegs.data, 'hex');
  const unit_bytes = Buffer.from(unitRegs.data, 'hex');

  // Byte 0-1: Volume (U32 big-endian, split across 2×16-bit)
  const volume_raw = (nozzle_bytes[0] << 24) | (nozzle_bytes[1] << 16) |
                     (nozzle_bytes[2] << 8) | nozzle_bytes[3];
  const volume_liters = volume_raw * 0.001;

  // Byte 4-5: Unit Price (U16 big-endian)
  const price_raw = (nozzle_bytes[4] << 8) | nozzle_bytes[5];
  const price_per_liter = price_raw * 0.01;

  // Byte 6-7: Status (U16)
  const status_raw = (nozzle_bytes[6] << 8) | nozzle_bytes[7];
  const pumping = (status_raw & 0x0001) ? true : false;
  const fault = (status_raw & 0x0002) ? true : false;
  const low_pressure = (status_raw & 0x0004) ? true : false;
  const high_temp = (status_raw & 0x0008) ? true : false;

  // Byte 8-9: Temperature (I16 big-endian, signed)
  const temp_raw = nozzle_bytes[8] << 8 | nozzle_bytes[9];
  const temp_signed = (temp_raw & 0x8000) ? 
    -(((~temp_raw & 0xFFFF) + 1) & 0xFFFF) : temp_raw;
  const temperature_c = temp_signed * 1;

  // Build JSON output
  return {
    timestamp: new Date().toISOString(),
    nozzle_volume_liters: volume_liters,
    unit_price_per_liter: price_per_liter,
    dispensing: pumping,
    fault_active: fault,
    low_pressure_warning: low_pressure,
    high_temp_warning: high_temp,
    temperature_celsius: temperature_c
  };
}

// Output to Azure SQL or Cosmos DB
module.exports = function (context, iotHubMessage) {
  const parsed = parseCompanyADispenser(iotHubMessage.reg_data);
  context.bindings.outputTable = parsed;
  context.done();
};
```

---

### 2.7 Minimal Code Changes Required

**The good news:** You likely need **minimal firmware changes** if you:

1. ✅ Use the existing Modbus framework
2. ✅ Configure each dispenser via JSON (load to Device Twin)
3. ✅ Implement data parsing on the cloud backend (Azure Functions)

**Potential firmware additions IF needed:**

- **Custom parsing module** (if Modbus alone isn't sufficient)
- **Enum for dispenser types** (for logging/diagnostics)
- **Unit testing** for each protocol (optional)

```c
// lib/dispenser_protocols/dispenser_types.h (optional)
#pragma once

typedef enum {
    DISPENSER_TYPE_UNKNOWN = 0,
    DISPENSER_TYPE_COMPANY_A = 1,
    DISPENSER_TYPE_COMPANY_B = 2,
    DISPENSER_TYPE_COMPANY_C = 3,
    DISPENSER_TYPE_COMPANY_D = 4,
} dispenser_type_t;

// Helper to detect type from c_make field
dispenser_type_t dispenser_detect_type(const char *c_make) {
    if (strstr(c_make, "Company_A")) return DISPENSER_TYPE_COMPANY_A;
    if (strstr(c_make, "Company_B")) return DISPENSER_TYPE_COMPANY_B;
    // ... etc
    return DISPENSER_TYPE_UNKNOWN;
}
```

But **this is optional**—the system works fine without it.

---

## PART 3: QUICK REFERENCE

### Key Files to Modify for Protocol Support

| File | Change Type | Purpose |
|------|------------|---------|
| docs/protocol_specs/ | **Create** | Document each company's protocol |
| samples/iot_config_*.json | **Create** | Template configs for each |
| lib/dispenser_protocols/ | **Create (optional)** | Protocol handlers if needed |
| src/main.c | ⚠️ Likely unchanged | Generic system works as-is |
| lib/device_config/ | ⚠️ Likely unchanged | Already handles JSON config |
| lib/modbus_adapter/ | ✅ No change | Generic RTU/TCP works for all |

### Register Address Cheat Sheet

```
Modbus Address → Function Code → Offset (for lib/modbus_adapter)

Coil Outputs (binary read/write):
1-9999 → FC1 Read Coils → offset = addr - 1

Discrete Inputs (binary read-only):
10001-19999 → FC2 Read Discrete Inputs → offset = addr - 10001

Input Registers (16-bit read-only):
30001-39999 → FC4 Read Input Regs → offset = addr - 30001

Holding Registers (16-bit read/write):
40001-49999 → FC3 Read Holding Regs → offset = addr - 40001

Example:
  "m": [40001, 10, 30100, 5]
  ↓
  Read from Dispenser:
  - Holding Register 40001-40010 (10 registers = 20 bytes)
  - Input Register 30100-30104 (5 registers = 10 bytes)
  ↓
  Total telemetry: 30 bytes
```

### Debugging Checklist

When testing a new dispenser protocol:

- [ ] Verify slave address (correct for chosen nozzle?)
- [ ] Check RS485 pin direction (TX/RX/Enable configured for your board?)
- [ ] Confirm baud rate matches dispenser datasheet
- [ ] Test with external Modbus reader (MultiMaster) first
- [ ] Review ESP logs for CRC errors (may indicate wrong baud/parity)
- [ ] Validate hex address ranges (are you reading from correct FC zone?)
- [ ] Check telemetry JSON for expected byte counts
- [ ] Inspect raw hex bytes in Azure IoT Hub
- [ ] Verify 32-bit values are split correctly across register pairs

---

## CONCLUSION

To add dispenser protocols:

1. **Research & Document** each company's Modbus register layout
2. **Create Protocol Specs** (PROTOCOL.md + register_map.csv) in `lib/dispenser_protocols/`
3. **Write Sample JSON Configs** for each company (load to Device Twin)
4. **Implement Cloud-Side Parsing** (Azure Functions to convert raw bytes → business metrics)
5. **Test with Real Hardware** (bench test + integration test)
6. **No firmware changes needed** if you leverage JSON-driven configuration

The existing system is already **completely protocol-agnostic**—it's a generic Modbus poller that works with anything Modbus-compliant. You're just adding the **configuration blueprints** for each dispenser company.
